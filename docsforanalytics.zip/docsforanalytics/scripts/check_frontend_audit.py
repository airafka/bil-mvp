#!/usr/bin/env python3
"""Read-only coverage/provenance check; semantic conclusions remain a manual review."""
from pathlib import Path
import json
import re
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[3]
DATA = ROOT / 'docs/docsforanalytics/traceability/frontend-commit-reviews.json'


def git(*args):
    return subprocess.check_output(['git', '-C', str(ROOT), *args], text=True).strip()


def main():
    data = json.loads(DATA.read_text())
    expected = set(git('log', data['head'], '--since-as-filter=' + data['since'],
                       '--no-merges', '--format=%H').splitlines())
    reviews = data['commits']
    actual = [item['commit'] for item in reviews]
    problems = []
    if len(actual) != len(set(actual)):
        problems.append('Duplicate commit records')
    if set(actual) != expected:
        problems.append(f'Commit coverage mismatch: missing={expected-set(actual)}, extra={set(actual)-expected}')
    if git('rev-parse', 'HEAD') != data['head']:
        problems.append('HEAD changed: the recorded review is a historical snapshot')
    head_files = {}
    for line in git('ls-tree', '-r', data['head']).splitlines():
        spec, path = line.split('\t', 1)
        head_files[path] = spec.split()[2]
    checked_files = 0
    checked_docs = set()
    for item in reviews:
        commit = item['commit']
        if item.get('reviewStatus') != 'REVIEWED' or not item.get('conclusion', '').strip():
            problems.append(f'{commit}: missing manual conclusion/status')
        if 'Состав изменений' in item.get('conclusion', ''):
            problems.append(f'{commit}: inventory placeholder remains')
        if item.get('kind') not in {'UI', 'TECH', 'HISTORICAL', 'REVERT', 'REVERTED'}:
            problems.append(f'{commit}: invalid kind')
        actual_files = []
        for line in git('diff-tree', '-r', '--raw', '--no-commit-id', '--no-abbrev', '-M', commit).splitlines():
            spec, *paths = line.split('\t')
            parts = spec.split()
            actual_files.append((paths[-1], paths[0], parts[-1], parts[2], parts[3]))
        recorded = [(f['path'], f['previousPath'], f['change'], f['beforeBlob'], f['afterBlob']) for f in item['files']]
        if recorded != actual_files:
            problems.append(f'{commit}: changed-file coverage/blob mismatch')
        for f in item['files']:
            checked_files += 1
            if f['headBlob'] != head_files.get(f['path']) or f['headPathPresent'] != (f['path'] in head_files):
                problems.append(f'{commit}: stale HEAD evidence for {f["path"]}')
        if not item.get('documentation'):
            problems.append(f'{commit}: no documentation mapping')
        for target in item.get('documentation', []):
            checked_docs.add(target)
            path, _, anchor = target.partition('#')
            file = ROOT / path
            if not file.is_file():
                problems.append(f'{commit}: missing document {path}')
            elif anchor:
                content = file.read_text()
                ids = set(re.findall(r'<a\s+id="([^"]+)"', content))
                headings = set(re.findall(r'^#+\s+(.+)$', content, re.M))
                if anchor not in ids and anchor not in headings:
                    problems.append(f'{commit}: missing explicit section {target}')
    print(f'Commits: {len(reviews)}/{len(expected)}; file changes: {checked_files}; documentation sections: {len(checked_docs)}')
    for problem in problems:
        print('ERROR:', problem)
    print('PASS' if not problems else 'FAIL')
    return bool(problems)


if __name__ == '__main__':
    sys.exit(main())
