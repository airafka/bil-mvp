/**
 * ALIS Documentation Chatbot Server
 * Node.js + Express + LM Studio API integration
 */

const express = require('express');
const http = require('http');
const fs = require('fs');
const path = require('path');
const axios = require('axios').default;

const app = express();
const server = http.createServer(app);

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(express.static(path.join(__dirname)));

// CORS middleware для доступа из браузера
server.on('request', (req, res) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  
  if (req.method === 'OPTIONS') {
    res.writeHead(204, {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization'
    });
    res.end();
    return;
  }
});

// Конфигурация
const CHATBOT_PORT = 8000;
const DOCS_ROOT = '/Users/ilnur/Documents/alis/backend/docs/docsforanalytics';
const LM_API_BASE = 'http://10.16.69.45:1235/v1'; // Твой IP
const LM_API_KEY = ''; // Ваше API key, если нужно
const CHAT_MODEL = 'mistral-nemo:latest';

console.log('\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
console.log('🚀 ALIS Documentation Chatbot Server');
console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
console.log('');
console.log('📂 Документация:', DOCS_ROOT);
console.log('🔗 LM Studio API:', LM_API_BASE);
console.log('📡 Порт:', CHATBOT_PORT);
console.log('🤖 Модель:', CHAT_MODEL);
console.log('');

// Лоадер документации
async function loadDocumentation() {
  const kb = [];
  const docStructure = {};
  
  const docPaths = [
    'README.md',
    'api/README.md',
    'business/README.md',
    'business/evidence-model.md',
    'business/glossary.md',
    'business/roles.md',
    'business-rules/README.md',
    'ui/README.md',
    'entities/README.md',
    'database/README.md',
    'dto/README.md',
    'integrations/README.md',
    'scenarios/README.md',
    'traceability/README.md',
    'templates/business-object.md',
    'templates/business-process.md',
    'templates/dto.md',
    'templates/entity.md',
    'templates/business-rule.md'
  ];
  
  for (const docPath of docPaths) {
    const filePath = path.join(DOCS_ROOT, docPath);
    if (fs.existsSync(filePath)) {
      const content = fs.readFileSync(filePath, 'utf-8');
      kb.push({
        filename: docPath,
        filepath: filePath,
        content: content.substring(0, 10000), // Ограничение для контекста
        size: content.length,
        type: getType(docPath)
      });
      
      // Структура документации
      const parts = docPath.split('/');
      const lastPart = parts[parts.length - 1];
      docStructure[lastPart] = (docStructure[lastPart] || 0) + 1;
    }
  }
  
  // Добавляем все остальные файлы
  const allDocsDir = path.join(DOCS_ROOT);
  if (fs.existsSync(allDocsDir)) {
    const files = fs.readdirSync(allDocsDir);
    for (const file of files) {
      const filePath = path.join(allDocsDir, file);
      if (fs.statSync(filePath).isFile() && !docPaths.includes(file)) {
        const content = fs.readFileSync(filePath, 'utf-8');
        kb.push({
          filename: file,
          filepath: filePath,
          content: content.substring(0, 5000),
          size: content.length,
          type: getType(file)
        });
      }
    }
  }
  
  console.log('📄 Загружено документов:', kb.length);
  console.log('📊 Структура:', Object.entries(docStructure));
  
  return kb;
}

function getType(filename) {
  if (filename.endsWith('.md')) return 'doc';
  if (filename.includes('sql')) return 'sql';
  if (filename.includes('api')) return 'api';
  if (filename.includes('ui')) return 'ui';
  if (filename.includes('entity')) return 'entity';
  return 'unknown';
}

// Загружаем KB
console.log('⏳ Загрузка документации...');
config = {
  knowledgeBase: await loadDocumentation(),
  lmApiBase: LM_API_BASE,
  lmApiKey: LM_API_KEY,
  chatModel: CHAT_MODEL
};

console.log('✅ Готово!');
console.log('');

// Система подсчета токенов
const COST_PER_1K_TOKENS = {
  'mistral-nemo:latest': 0.25,
  'llama3.1': 0.30,
  'gpt-4o-mini': 0.15,
  'gpt-4o': 0.30
};

let totalCost = 0;
let totalTokens = 0;

// Чат эндпоинт
async function processMessage(messages) {
  const kbContext = config.knowledgeBase
    .map(k => `### Файл: ${k.filename}\n${k.content}\n---\n`)
    .slice(0, 50) // Берем 50 лучших документов
    .join('\n');
  
  const systemPrompt = `Ты - умный ассистент для работы с документацией ALIS (Alabuga Logistics Information System).

## О системе
ALIS - информационная система для управления логистикой.
- Архитектура: CRUD API над PostgreSQL
- Авторизация: Keycloak (OAuth2/JWT)
- Слои: db-layer (сущности) / wms-layer (бизнес) / web-layer (API)

## Твоя задача
Анализируй загруженные документы и отвечай на вопросы пользователя:
1. Будь конкретен и приводи источники
2. Указывай уровень достоверности (AS_IS/TO_BE/PROPOSAL)
3. Если не знаешь - честно скажи

## Структура документации
- **business/** - бизнес-объекты, процессы, роли, словарь
- **business-rules/** - бизнес-правила, статусы, ошибки
- **ui/** - экраны интерфейса
- **entities/** - JPA сущности (таблицы)
- **database/** - SQL модель
- **api/** - REST API endpoints
- **integrations/** - интеграции (1С, Datareon, ЭТРАН)
- **scenarios/** - сквозные сценарии
- **traceability/** - трассировка требований

## Как отвечать
- Кратко в начале, подробно потом
- Приводи примеры: "Смотри файл ${filename}, строки ${line}"
- Указывай источник: "Из docs/${filename}"
- Не выдумывай, только из документов

## Шаблон
1. Краткий ответ
2. Подробное объяснение
3. Ссылки на файлы
4. Источники (файл:строки)
5. Вопросы по ТЗ (если есть)

${systemPrompt}`;

  const userMessage = messages.find(m => m.role === 'user');
  
  const prompt = {
    model: config.chatModel,
    messages: [
      { role: 'system', content: systemPrompt },
      { role: 'user', content: userMessage ? userMessage.content : "Спросите что-то о системе ALIS" }
    ],
    temperature: 0.7,
    max_tokens: 2000
  };
  
  // Вызов LM Studio API
  const response = await axios.post(
    config.lmApiBase + '/v1/chat/completions',
    prompt,
    {
      headers: {
        'Authorization': `Bearer ${config.lmApiKey}`,
        'Content-Type': 'application/json'
      }
    }
  );
  
  if (response.status !== 200) {
    throw new Error(`API error: ${response.status} ${response.statusText}`);
  }
  
  const aiResponse = response.data.choices[0].message;
  
  // Формируем источники из контекста
  let sources = [];
  const mentions = findMentions(aiResponse.content, kb);
  mentions.forEach(m => {
    sources.push(`📄 ${m}`);
  });
  
  // Подсчет токенов (очень грубый)
  const outputTokens = aiResponse.content.length;
  totalTokens += outputTokens;
  const modelCost = COST_PER_1K_TOKENS[config.chatModel] || 0.25;
  totalCost += (outputTokens / 1000) * modelCost;
  
  return {
    role: 'assistant',
    content: aiResponse.content,
    sources: sources,
    cost: totalCost.toFixed(2) + ' ₽',
    tokens: totalTokens,
    timestamp: new Date().toISOString()
  };
}

function findMentions(text, knowledgeBase) {
  const mentions = [];
  for (const doc of knowledgeBase) {
    if (text.includes(`Файл: ${doc.filename}`) || text.includes(doc.filename)) {
      // Ищем строки
      const lines = text.match(/(\d{3}-\d+)/g) || [];
      lines.forEach(line => {
        mentions.push(`${doc.filename}:${line}`);
      });
    }
  }
  return Array.from(new Set(mentions));
}

// Эндпоинт чата
app.post('/api/chat', async (req, res) => {
  const { messages } = req.body;
  
  try {
    const result = await processMessage(messages);
    
    res.json({
      messages: result
    });
    
  } catch (error) {
    console.error('Chat error:', error);
    
    res.json({
      messages: [{
        role: 'assistant',
        content: `❌ Ошибка: ${error.message}`,
        timestamp: new Date().toISOString(),
        error: true
      }]
    });
  }
});

// Запуск
const PORT = CHATBOT_PORT;
server.listen(PORT, '0.0.0.0', () => {
  console.log('');
  console.log(`🌐 Сервер запущен на http://localhost:${PORT}`);
  console.log('');
  console.log(`💡 Быстрый старт:`);
  console.log(`   1. Откройте http://localhost:${PORT}`);
  console.log(`   2. Задайте вопросы о документации`);
  console.log(`   3. Наслаждайтесь! 🎉`);
  console.log('');
});