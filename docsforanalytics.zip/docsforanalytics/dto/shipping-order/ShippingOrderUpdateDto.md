# `ShippingOrderUpdateDto`

> Сверено по DTO/controller/mapper/service на `3d3899d5d`, 12.11.2026. [Декларации и ограничения полей](../catalog/shippingorder/ShippingOrderUpdateDto.md); runtime не запускался.

Связано: [правила редактирования](../../business-rules/shipping-orders.md#создание-и-редактирование), [статусы](../../business-rules/order-statuses.md), [сущность](../../entities/catalog/entities/shippingorder/ShippingOrder.md).

Изменяет существующую заявку на вывоз.

- **Endpoint:** `PUT /shippingorder/{id}`
- **Permission:** `SHIPPING_ORDER`, level `WRITE`
- **Response:** [ShippingOrderDto](ShippingOrderDto.md)
- **Java:** `web-layer/src/main/java/ru/korusconsulting/alis/dto/shippingorder/ShippingOrderUpdateDto.java`

## Полный состав полей

| JSON-поле | JSON-тип | Обязательность | Назначение / ограничение |
|---|---|---:|---|
| `id` | UUID string | обязательно | Фактический ID изменяемой заявки |
| `orderStatus` | string enum | обязательно | В обычном update не присваивается; изменение через lifecycle |
| `client` | object `{id}` | обязательно | Клиент; в модели связь неизменяема после создания |
| `contract` | object `{id}` | обязательно | Договор |
| `terminalArea` | object `{id,code,name}` | обязательно | В модели связь неизменяема |
| `transportType` | string enum | обязательно | В модели поле неизменяемо |
| `plannedShippingDateTime` | ISO-8601 string | нет | Плановое время |
| `currency` | object `{id}` | нет | Валюта |
| `contact` | object `{name,phone,email}` | нет | Представитель |
| `comment` | string | нет | Комментарий |
| `deliveryType` | string enum | нет | В DTO есть, prepareModelToUpdate не переносит; проверяется существующая комбинация |
| `needTransport` | boolean | нет | В DTO есть, prepareModelToUpdate не переносит |
| `consignee` | object `{id}` | условно | Грузополучатель |
| `consigneeAddress` | string | нет | Входное значение не используется; сервер берёт trimToNull адреса выбранного consignee, NULL consignee очищает оба поля |
| `fillingType` | string enum | нет | В DTO есть, prepareModelToUpdate не переносит |

Изменение разрешено в `DRAFT`; в `ON_REVIEW` требуется дополнительное право. `{id}` из URL не объявлен аргументом метода контроллера, поэтому текущая реализация использует только `body.id`.

## Пример

```json
{
  "id": "aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa",
  "orderStatus": "DRAFT",
  "client": {"id": "11111111-1111-1111-1111-111111111111"},
  "contract": {"id": "22222222-2222-2222-2222-222222222222"},
  "terminalArea": {"id": "33333333-3333-3333-3333-333333333333", "code": "WAREHOUSE", "name": "Склад"},
  "transportType": "VEHICLE",
  "plannedShippingDateTime": "2026-09-12T13:00:00Z",
  "currency": {"id": "44444444-4444-4444-4444-444444444444"},
  "deliveryType": "BY_CARGO",
  "needTransport": false,
  "consignee": {"id": "55555555-5555-5555-5555-555555555555"},
  "consigneeAddress": "Санкт-Петербург",
  "fillingType": "ALL",
  "comment": "Изменённый адрес"
}
```

Поле route отсутствует во входном DTO; создание/очистка связи рейса выполняется операциями Route, не обычным create/update заявки.
