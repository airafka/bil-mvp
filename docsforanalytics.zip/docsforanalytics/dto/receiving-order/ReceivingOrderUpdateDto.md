# `ReceivingOrderUpdateDto`

> Сверено по DTO/controller/mapper/service на `3d3899d5d`, 12.11.2026. [Декларации и ограничения полей](../catalog/receivingorder/ReceivingOrderUpdateDto.md); runtime не запускался.

Связано: [правила редактирования](../../business-rules/receiving-orders.md#создание-и-редактирование), [статусы](../../business-rules/order-statuses.md), [сущность](../../entities/catalog/entities/receivingorder/ReceivingOrder.md).

Изменяет существующую заявку на поставку.

- **Endpoint:** `PUT /receivingorder/{id}`
- **Permission:** `RECEIVING_ORDER`, level `WRITE`
- **Response:** [ReceivingOrderDto](ReceivingOrderDto.md)
- **Java:** `web-layer/src/main/java/ru/korusconsulting/alis/dto/receivingorder/ReceivingOrderUpdateDto.java`

## Полный состав полей

| JSON-поле | JSON-тип | Обязательность | Назначение / ограничение |
|---|---|---:|---|
| `id` | UUID string | обязательно | ID изменяемой заявки; фактически используется сервисом |
| `client` | object `{id}` | обязательно | Клиент; колонка модели помечена `updatable=false` |
| `defaultContainerOwner` | object `{id}` | нет | При create — client по умолчанию; при update непустая отличающаяся ссылка меняет default и владельцев прямых/Waybill КТК; NULL не очищает |
| `contract` | object `{id}` | обязательно | Новый/текущий договор |
| `terminalArea` | object `{id}` | обязательно | @Valid IdDto; mapper загружает площадку по UUID, code/name во входном DTO отсутствуют |
| `transportType` | string enum | обязательно | Колонка модели помечена `updatable=false` |
| `planReceivingDateTime` | ISO-8601 string | нет | Плановая дата |
| `storagePeriod` | number | нет | Значение ≥ 0 |
| `orderStatus` | string enum | обязательно | В обычном update не присваивается existingModel; lifecycle — отдельные действия |
| `currency` | object `{id}` | нет по DTO | Сервис разыменовывает `currency.id`; `null` требует отдельной проверки сценария |
| `contact` | object `{name,phone,email}` | нет | Если `null`, текущий contact явно не очищается в `prepareModelToUpdate` |
| `comment` | string | нет | Заменяет комментарий, включая `null` |
| `deliveryType` | string enum | условно | Проверяется комбинация площадки/транспорта |
| `needTransport` | boolean | нет | Присутствует в DTO, но prepareModelToUpdate его не переносит |
| `shipper` | object `{id}` | условно | Можно заменить/очистить грузоотправителя |
| `carrier` | object `{id}` | нет | Deprecated, игнорируется |
| `payerId` | object `{id}` | нет | Новый плательщик; NULL не очищает |
| `waybill` | string | нет | Заменяет/очищает номер накладной |

payerId: @Valid IdDto теперь есть в update DTO. Непустая отличающаяся ссылка загружается через PayerDaoService и присваивается; NULL/отсутствие сохраняют прежнего плательщика. departureStationId/destinationStationId отсутствуют, станции этим endpoint не меняются.

## Предусловия и контрактный риск

Изменение разрешено в `DRAFT`; в `ON_REVIEW` требуется дополнительное право. В других статусах возвращается ошибка доступа. `{id}` из URL не объявлен аргументом метода контроллера: текущая реализация выбирает заявку по `body.id` и не проверяет равенство ID.

## Пример

```json
{
  "id": "aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa",
  "client": {"id": "11111111-1111-1111-1111-111111111111"},
  "contract": {"id": "22222222-2222-2222-2222-222222222222"},
  "terminalArea": {"id": "33333333-3333-3333-3333-333333333333"},
  "transportType": "VEHICLE",
  "planReceivingDateTime": "2026-09-12T09:00:00Z",
  "storagePeriod": 5,
  "orderStatus": "DRAFT",
  "currency": {"id": "44444444-4444-4444-4444-444444444444"},
  "deliveryType": "BY_GOOD",
  "needTransport": true,
  "comment": "Обновлённое время поставки"
}
```

Поле route отсутствует во входном DTO; создание/очистка связи рейса выполняется операциями Route, не обычным create/update заявки.
