# `ReceivingOrderBaseDto`

> Сверено по DTO/controller/mapper/service на `3d3899d5d`, 12.11.2026. [Декларации и ограничения полей](../catalog/receivingorder/ReceivingOrderBaseDto.md); runtime не запускался.

Связано: [типы поставок](../../business-rules/order-types.md#4-вид-поставки-receivingorderdeliverytype), [правила поставки](../../business-rules/receiving-orders.md), [сущность](../../entities/catalog/entities/receivingorder/ReceivingOrder.md).

Абстрактная базовая часть request DTO поставки. Используется в `ReceivingOrderCreationDto` и `ReceivingOrderUpdateDto`, самостоятельно по API не передаётся.

- **Направление:** request
- **Java:** `web-layer/src/main/java/ru/korusconsulting/alis/dto/receivingorder/ReceivingOrderBaseDto.java`
- **Модель:** `ReceivingOrder`

## Поля

| JSON-поле | Java / JSON-тип | Обязательность | Поле модели | Правила и смысл |
|---|---|---:|---|---|
| `client` | `IdDto` / object | обязательно | `client` | Объект `{id}`; вложенный `id` также обязателен |
| `defaultContainerOwner` | `IdDto` / object | нет | `defaultContainerOwner` | При create fallback на client; при непустом отличающемся update обновляет владельцев дочерних КТК |
| `contract` | `IdDto` / object | обязательно | `contract` | Объект `{id}`; вложенный `id` также обязателен |
| `terminalArea` | `IdDto` / object | обязательно | `terminalArea` | Только `{id}` с @Valid; mapper загружает площадку по UUID, code берётся из БД |
| `transportType` | enum / string | обязательно | `transportType` | Из кода подтверждены `VEHICLE`, `RAILWAY` |
| `planReceivingDateTime` | `Instant` / string | нет | `planReceivingDateTime` | На review/accept отсутствие даёт `ReceivingOrder.MissingPlannedReceivingDateTime` |
| `storagePeriod` | `BigDecimal` / number | нет | `storagePeriod` | `@PositiveOrZero`: значение ≥ 0 |
| `orderStatus` | enum / string | обязательно | `orderStatus` | `DRAFT`, `ON_REVIEW`, `ACCEPTED`, `IN_PROGRESS`, `DONE`, `REJECTED`; при create заменяется на `DRAFT` |
| `currency` | `IdDto` / object | нет | `currency` | Если объект передан, его `id` обязателен; валюта нужна перед review/accept |
| `contact` | `ContactDto` / object | нет | embedded `contact` | `{name, phone, email}`; ограничений формата в DTO нет |
| `comment` | `String` / string | нет | `comment` | Особые отметки/комментарий; ограничения длины в DTO нет |
| `deliveryType` | enum / string | условно | `deliveryType` | `BY_GOOD`, `BY_CARGO`, `BY_GOOD_WITH_CARGO_WITHOUT_DETAILS`, `BY_GOOD_WITH_CARGO_WITH_DETAILS`; обязателен для WAREHOUSE/WAREHOUSE_428 + VEHICLE |
| `needTransport` | `Boolean` / boolean | нет | `needTransport` | Признак необходимости транспорта |
| `shipper` | `IdDto` / object | условно | `shipper` | Грузоотправитель; обязателен перед review/accept для контейнерной площадки |
| `carrier` | `IdDto` / object | нет | — | Deprecated-имя; MapStruct игнорирует, использовать `shipper` |
| `waybill` | `String` / string | нет | `waybill` | Номер транспортной накладной |

## Межполевые правила

- `RAILWAY` допустим только при `terminalArea.code = CONTAINER`.
- Для `WAREHOUSE/WAREHOUSE_428 + VEHICLE` нужен `deliveryType`; для прочих комбинаций при создании он нормализуется в `null`.
- Аннотация `@Valid` на ссылке проверяет вложенный `IdDto.id`, но не подтверждает существование записи — это делает слой доступа к данным.

Поле route отсутствует во входном DTO; создание/очистка связи рейса выполняется операциями Route, не обычным create/update заявки.
