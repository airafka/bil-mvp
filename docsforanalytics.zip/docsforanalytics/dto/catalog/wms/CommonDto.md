# `CommonDto`

> Технический паспорт сгенерирован из Java. Он фиксирует структуру и Bean Validation, но не заменяет ручное бизнес-описание.

DTO пакета `ru.korusconsulting.wms.dto`.

## Паспорт

- **Java FQCN:** `ru.korusconsulting.wms.dto.CommonDto`
- **Java package:** `ru.korusconsulting.wms.dto`
- **Тип:** `class` (top-level)
- **Использование в controller signatures:** response
- **Наследует:** [BaseNamedDto](BaseNamedDto.md)
- **Интерфейсы:** нет
- **Class-level validation:** нет
- **Method/property validation:** нет
- **Java-источник:** [CommonDto.java:14](../../../../../wms-layer/src/main/java/ru/korusconsulting/wms/dto/CommonDto.java#L14)

## Использование в endpoints

| Роль | Метод и путь | Контроллер (происхождение) |
|---|---|---|
| response | `POST` `/client/all` | `ClientController` (ALIS) |
| response | `POST` `/company/all` | `CompanyController` (ALIS) |
| response | `POST` `/currency/all` | `CurrencyController` (ALIS) |
| response | `POST` `/etsngcode/all` | `EtsngCodeController` (ALIS) |
| response | `POST` `/frequencyofservices/all` | `FrequencyOfServicesController` (ALIS) |
| response | `POST` `/goodtype/all` | `GoodTypeController` (ALIS) |
| response | `POST` `/loadingtype/all` | `LoadingTypeController` (ALIS) |
| response | `POST` `/receivingordercargo/all` | `ReceivingOrderCargoController` (ALIS) |
| response | `POST` `/receivingordercontaineritem/all` | `ReceivingOrderContainerItemController` (ALIS) |
| response | `POST` `/receivingorder/all` | `ReceivingOrderController` (ALIS) |
| response | `POST` `/service/all` | `ServiceController` (ALIS) |
| response | `POST` `/shippingordercargo/all` | `ShippingOrderCargoController` (ALIS) |
| response | `POST` `/shippingordercontaineritem/all` | `ShippingOrderContainerItemController` (ALIS) |
| response | `POST` `/shippingorder/all` | `ShippingOrderController` (ALIS) |
| response | `POST` `/tempregime/all` | `TempRegimeController` (ALIS) |
| response | `POST` `/termofperiodicservice/all` | `TermOfPeriodicServiceController` (ALIS) |
| response | `POST` `/unitofmeasure/all` | `UnitOfMeasureController` (ALIS) |
| response | `POST` `/vehiclebrand/all` | `VehicleBrandController` (ALIS) |
| response | `POST` `/vehicletype/all` | `VehicleTypeController` (ALIS) |

## Поля

| JSON-поле | Java-поле | Java-тип | Java null | JSON required | Jackson null-policy | Bean Validation | Объявлено в | Смысл / default |
|---|---|---|---|---|---|---|---|---|
| `id` | `id` | UUID | технически возможен (reference) | не задано | не задано | — | `BaseDto` | ID |
| `code` | `code` | String | технически возможен (reference) | не задано | не задано | — | `IdCodeDto` | — |
| `active` | `active` | Boolean | технически возможен (reference) | не задано | не задано | — | `IdActiveCodeDto` | — |
| `name` | `name` | String | технически возможен (reference) | не задано | не задано | — | `BaseNamedDto` | — |

## Ограничения интерпретации

- `JSON required` показывает только явный параметр `@JsonProperty(required = ...)`. Если он не задан, из Java-типа нельзя достоверно вывести обязательность входного JSON-поля.
- `primitive` запрещает Java-значение `null`, но сам по себе не требует присутствия поля во входном JSON: при отсутствии поведение зависит от способа создания объекта и настроек Jackson.
- `Jackson null-policy` относится к явно переданному `null`; отсутствие поля и `null` — разные случаи. Значение `Nulls.SKIP` оставляет текущее/default-значение свойства.
- `@NotNull`, `@NotBlank` и `@NotEmpty` — ограничения Bean Validation, а не декларация JSON required. Они срабатывают только когда для объекта запускается соответствующая validation-группа.
- `@Valid` запускает каскадную проверку переданного вложенного объекта, но сам по себе не запрещает `null`.
- `@Nullable` и `@NonNull` отражаются как Java-аннотации; генератор не приписывает им не объявленную в коде Jackson- или бизнес-семантику.
- Вложенный тип получает отдельный паспорт; ссылка разрешается относительно внешнего класса, package и import.
- Mapping, нормализация и серверные вычисления документируются в доменных бизнес-правилах.
