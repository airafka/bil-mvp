# `ReceivingOrderCreationDto`

> Технический паспорт сгенерирован из Java. Он фиксирует структуру и Bean Validation, но не заменяет ручное бизнес-описание.

DTO пакета `ru.korusconsulting.alis.dto.receivingorder`.

## Паспорт

- **Java FQCN:** `ru.korusconsulting.alis.dto.receivingorder.ReceivingOrderCreationDto`
- **Java package:** `ru.korusconsulting.alis.dto.receivingorder`
- **Тип:** `class` (top-level)
- **Использование в controller signatures:** request
- **Наследует:** [ReceivingOrderBaseDto](ReceivingOrderBaseDto.md)
- **Интерфейсы:** `BaseCreationDto`
- **Class-level validation:** нет
- **Method/property validation:** нет
- **Java-источник:** [ReceivingOrderCreationDto.java:17](../../../../../web-layer/src/main/java/ru/korusconsulting/alis/dto/receivingorder/ReceivingOrderCreationDto.java#L17)
- **Ручной бизнес-паспорт:** [ReceivingOrderCreationDto.md](../../receiving-order/ReceivingOrderCreationDto.md)

## Использование в endpoints

| Роль | Метод и путь | Контроллер (происхождение) |
|---|---|---|
| request | `POST` `/receivingorder` | `ReceivingOrderController` (ALIS) |

## Поля

| JSON-поле | Java-поле | Java-тип | Java null | JSON required | Jackson null-policy | Bean Validation | Объявлено в | Смысл / default |
|---|---|---|---|---|---|---|---|---|
| `client` | `client` | [IdDto](../wms/IdDto.md) | технически возможен (reference) | не задано | не задано | `@Valid`, `@NotNull` | `ReceivingOrderBaseDto` | — |
| `defaultContainerOwner` | `defaultContainerOwner` | [IdDto](../wms/IdDto.md) | технически возможен (reference) | не задано | не задано | `@Valid` | `ReceivingOrderBaseDto` | Собственник КТК по умолчанию. Если значение не передано, используется client заявки. |
| `contract` | `contract` | [IdDto](../wms/IdDto.md) | технически возможен (reference) | не задано | не задано | `@Valid`, `@NotNull` | `ReceivingOrderBaseDto` | — |
| `terminalArea` | `terminalArea` | [IdDto](../wms/IdDto.md) | технически возможен (reference) | не задано | не задано | `@Valid`, `@NotNull` | `ReceivingOrderBaseDto` | — |
| `transportType` | `transportType` | TransportType | технически возможен (reference) | не задано | не задано | `@NotNull` | `ReceivingOrderBaseDto` | — |
| `planReceivingDateTime` | `planReceivingDateTime` | Instant | технически возможен (reference) | не задано | не задано | — | `ReceivingOrderBaseDto` | — |
| `storagePeriod` | `storagePeriod` | BigDecimal | технически возможен (reference) | не задано | не задано | `@PositiveOrZero` | `ReceivingOrderBaseDto` | — |
| `orderStatus` | `orderStatus` | OrderStatus | технически возможен (reference) | не задано | не задано | `@NotNull` | `ReceivingOrderBaseDto` | — |
| `currency` | `currency` | [IdDto](../wms/IdDto.md) | технически возможен (reference) | не задано | не задано | `@Valid` | `ReceivingOrderBaseDto` | — |
| `contact` | `contact` | [ContactDto](../contact/ContactDto.md) | технически возможен (reference) | не задано | не задано | `@Valid` | `ReceivingOrderBaseDto` | — |
| `comment` | `comment` | String | технически возможен (reference) | не задано | не задано | — | `ReceivingOrderBaseDto` | — |
| `deliveryType` | `deliveryType` | ReceivingOrderDeliveryType | технически возможен (reference) | не задано | не задано | — | `ReceivingOrderBaseDto` | — |
| `needTransport` | `needTransport` | Boolean | технически возможен (reference) | не задано | не задано | — | `ReceivingOrderBaseDto` | — |
| `shipper` | `shipper` | [IdDto](../wms/IdDto.md) | технически возможен (reference) | не задано | не задано | `@Valid` | `ReceivingOrderBaseDto` | Грузоотправитель (на сущности это поле ru.korusconsulting.alis.model.receivingorder.ReceivingOrder#shipper). |
| `carrier` | `carrier` | [IdDto](../wms/IdDto.md) | технически возможен (reference) | не задано | не задано | — | `ReceivingOrderBaseDto` | Оставлено для обратной совместимости. На сущности нет соответствующего поля, MapStruct это значение игнорирует. |
| `waybill` | `waybill` | String | технически возможен (reference) | не задано | не задано | — | `ReceivingOrderBaseDto` | — |
| `payerId` | `payerId` | [IdDto](../wms/IdDto.md) | технически возможен (reference) | не задано | не задано | `@Valid` | `ReceivingOrderCreationDto` | — |
| `departureStationId` | `departureStationId` | [IdDto](../wms/IdDto.md) | технически возможен (reference) | не задано | не задано | `@Valid` | `ReceivingOrderCreationDto` | — |
| `destinationStationId` | `destinationStationId` | [IdDto](../wms/IdDto.md) | технически возможен (reference) | не задано | не задано | `@Valid` | `ReceivingOrderCreationDto` | — |

## Ограничения интерпретации

- `JSON required` показывает только явный параметр `@JsonProperty(required = ...)`. Если он не задан, из Java-типа нельзя достоверно вывести обязательность входного JSON-поля.
- `primitive` запрещает Java-значение `null`, но сам по себе не требует присутствия поля во входном JSON: при отсутствии поведение зависит от способа создания объекта и настроек Jackson.
- `Jackson null-policy` относится к явно переданному `null`; отсутствие поля и `null` — разные случаи. Значение `Nulls.SKIP` оставляет текущее/default-значение свойства.
- `@NotNull`, `@NotBlank` и `@NotEmpty` — ограничения Bean Validation, а не декларация JSON required. Они срабатывают только когда для объекта запускается соответствующая validation-группа.
- `@Valid` запускает каскадную проверку переданного вложенного объекта, но сам по себе не запрещает `null`.
- `@Nullable` и `@NonNull` отражаются как Java-аннотации; генератор не приписывает им не объявленную в коде Jackson- или бизнес-семантику.
- Вложенный тип получает отдельный паспорт; ссылка разрешается относительно внешнего класса, package и import.
- Mapping, нормализация и серверные вычисления документируются в доменных бизнес-правилах.
