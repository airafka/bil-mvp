# `ShippingOrderContainerQtyDto`

> Технический паспорт сгенерирован из Java. Он фиксирует структуру и Bean Validation, но не заменяет ручное бизнес-описание.

DTO пакета `ru.korusconsulting.alis.dto.shippingordercontainerqty`.

## Паспорт

- **Java FQCN:** `ru.korusconsulting.alis.dto.shippingordercontainerqty.ShippingOrderContainerQtyDto`
- **Java package:** `ru.korusconsulting.alis.dto.shippingordercontainerqty`
- **Тип:** `class` (top-level)
- **Использование в controller signatures:** request, response
- **Наследует:** [BaseDto](../wms/BaseDto.md)
- **Интерфейсы:** нет
- **Class-level validation:** нет
- **Method/property validation:** нет
- **Java-источник:** [ShippingOrderContainerQtyDto.java:26](../../../../../web-layer/src/main/java/ru/korusconsulting/alis/dto/shippingordercontainerqty/ShippingOrderContainerQtyDto.java#L26)

## Использование в endpoints

| Роль | Метод и путь | Контроллер (происхождение) |
|---|---|---|
| response | `POST` `/shipping-order/{shippingOrderId}/shipping-order-container-qty/list` | `ShippingOrderContainerQtyController` (ALIS) |
| request | `PUT` `/shipping-order/{shippingOrderId}/shipping-order-container-qty/merge` | `ShippingOrderContainerQtyController` (ALIS) |
| response | `PUT` `/shipping-order/{shippingOrderId}/shipping-order-container-qty/merge` | `ShippingOrderContainerQtyController` (ALIS) |

## Поля

| JSON-поле | Java-поле | Java-тип | Java null | JSON required | Jackson null-policy | Bean Validation | Объявлено в | Смысл / default |
|---|---|---|---|---|---|---|---|---|
| `id` | `id` | UUID | технически возможен (reference) | не задано | не задано | — | `BaseDto` | ID |
| `quantity` | `quantity` | Integer | технически возможен (reference) | не задано | не задано | `@Min(0)`, `@NotNull` | `ShippingOrderContainerQtyDto` | Количество КТК |
| `type` | `type` | ContainerType | технически возможен (reference) | не задано | не задано | `@NotNull` | `ShippingOrderContainerQtyDto` | Тип КТК |
| `empty` | `empty` | Boolean | технически возможен (reference) | не задано | не задано | `@NotNull` | `ShippingOrderContainerQtyDto` | Порожний |
| `items` | `items` | List<[ShippingOrderEtsngCodeDto](../shippingorderetsngcode/ShippingOrderEtsngCodeDto.md)> | технически возможен (reference) | не задано | не задано | `@NotNull` | `ShippingOrderContainerQtyDto` | Груз; default: `Collections.emptyList()` |
| `ownerClient` | `ownerClient` | [ClientDto](../client/ClientDto.md) | разрешён (`@Nullable`) | не задано | не задано | — | `ShippingOrderContainerQtyDto` | Собственник КТК |

## Ограничения интерпретации

- `JSON required` показывает только явный параметр `@JsonProperty(required = ...)`. Если он не задан, из Java-типа нельзя достоверно вывести обязательность входного JSON-поля.
- `primitive` запрещает Java-значение `null`, но сам по себе не требует присутствия поля во входном JSON: при отсутствии поведение зависит от способа создания объекта и настроек Jackson.
- `Jackson null-policy` относится к явно переданному `null`; отсутствие поля и `null` — разные случаи. Значение `Nulls.SKIP` оставляет текущее/default-значение свойства.
- `@NotNull`, `@NotBlank` и `@NotEmpty` — ограничения Bean Validation, а не декларация JSON required. Они срабатывают только когда для объекта запускается соответствующая validation-группа.
- `@Valid` запускает каскадную проверку переданного вложенного объекта, но сам по себе не запрещает `null`.
- `@Nullable` и `@NonNull` отражаются как Java-аннотации; генератор не приписывает им не объявленную в коде Jackson- или бизнес-семантику.
- Вложенный тип получает отдельный паспорт; ссылка разрешается относительно внешнего класса, package и import.
- Mapping, нормализация и серверные вычисления документируются в доменных бизнес-правилах.
