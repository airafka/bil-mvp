# `ContainerCreationDto`

> Технический паспорт сгенерирован из Java. Он фиксирует структуру и Bean Validation, но не заменяет ручное бизнес-описание.

DTO пакета `ru.korusconsulting.alis.dto.container`.

## Паспорт

- **Java FQCN:** `ru.korusconsulting.alis.dto.container.ContainerCreationDto`
- **Java package:** `ru.korusconsulting.alis.dto.container`
- **Тип:** `class` (top-level)
- **Использование в controller signatures:** request
- **Наследует:** [BaseCodedCreationDto](../wms/BaseCodedCreationDto.md)
- **Интерфейсы:** нет
- **Class-level validation:** нет
- **Method/property validation:** нет
- **Java-источник:** [ContainerCreationDto.java:21](../../../../../web-layer/src/main/java/ru/korusconsulting/alis/dto/container/ContainerCreationDto.java#L21)

## Использование в endpoints

| Роль | Метод и путь | Контроллер (происхождение) |
|---|---|---|
| request | `POST` `/container` | `ContainerController` (ALIS) |

## Поля

| JSON-поле | Java-поле | Java-тип | Java null | JSON required | Jackson null-policy | Bean Validation | Объявлено в | Смысл / default |
|---|---|---|---|---|---|---|---|---|
| `active` | `active` | Boolean | разрешён (`@Nullable`) | не задано | не задано | — | `BaseActivatedCreationDto` | — |
| `code` | `code` | String | технически возможен (reference) | не задано | не задано | `@NotBlank`, `@Size(max = ValidationConstants.MAX_LENGTH_100)` | `BaseCodedCreationDto` | — |
| `containerType` | `containerType` | ContainerType | технически возможен (reference) | не задано | не задано | `@NotNull` | `ContainerCreationDto` | — |
| `weight` | `weight` | BigDecimal | технически возможен (reference) | не задано | не задано | `@Positive`, `@NotNull` | `ContainerCreationDto` | — |
| `liftingCapacity` | `liftingCapacity` | BigDecimal | технически возможен (reference) | не задано | не задано | `@Positive`, `@NotNull` | `ContainerCreationDto` | — |
| `refrigerator` | `refrigerator` | Boolean | технически возможен (reference) | не задано | не задано | `@NotNull` | `ContainerCreationDto` | — |
| `standardSize` | `standardSize` | [IdCodeDto](../wms/IdCodeDto.md) | технически возможен (reference) | не задано | не задано | — | `ContainerCreationDto` | — |
| `owner` | `owner` | String | технически возможен (reference) | не задано | не задано | — | `ContainerCreationDto` | — |
| `ownerName` | `ownerName` | String | технически возможен (reference) | не задано | не задано | — | `ContainerCreationDto` | — |
| `renter` | `renter` | String | технически возможен (reference) | не задано | не задано | — | `ContainerCreationDto` | — |
| `renterName` | `renterName` | String | технически возможен (reference) | не задано | не задано | — | `ContainerCreationDto` | — |
| `height` | `height` | BigDecimal | технически возможен (reference) | не задано | не задано | `@Positive` | `ContainerCreationDto` | — |
| `length` | `length` | BigDecimal | технически возможен (reference) | не задано | не задано | `@Positive` | `ContainerCreationDto` | — |
| `containerTypeISO` | `containerTypeISO` | [IdCodeDto](../wms/IdCodeDto.md) | технически возможен (reference) | не задано | не задано | — | `ContainerCreationDto` | — |

## Ограничения интерпретации

- `JSON required` показывает только явный параметр `@JsonProperty(required = ...)`. Если он не задан, из Java-типа нельзя достоверно вывести обязательность входного JSON-поля.
- `primitive` запрещает Java-значение `null`, но сам по себе не требует присутствия поля во входном JSON: при отсутствии поведение зависит от способа создания объекта и настроек Jackson.
- `Jackson null-policy` относится к явно переданному `null`; отсутствие поля и `null` — разные случаи. Значение `Nulls.SKIP` оставляет текущее/default-значение свойства.
- `@NotNull`, `@NotBlank` и `@NotEmpty` — ограничения Bean Validation, а не декларация JSON required. Они срабатывают только когда для объекта запускается соответствующая validation-группа.
- `@Valid` запускает каскадную проверку переданного вложенного объекта, но сам по себе не запрещает `null`.
- `@Nullable` и `@NonNull` отражаются как Java-аннотации; генератор не приписывает им не объявленную в коде Jackson- или бизнес-семантику.
- Вложенный тип получает отдельный паспорт; ссылка разрешается относительно внешнего класса, package и import.
- Mapping, нормализация и серверные вычисления документируются в доменных бизнес-правилах.
