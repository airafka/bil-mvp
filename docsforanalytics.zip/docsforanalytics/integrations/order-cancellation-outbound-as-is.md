# Отмена заявки: сохранённый outbound-пакет

Сверено с backend `dev`, `3d3899d5d`, 11.11.2026. Состояние `AS_IS`, основание `SOURCE_CONFIRMED`: исходники, подключённые миграции и исходники тестов. Работающая среда и приём пакета в Datareon/TOS не проверялись.

## Когда возникает сообщение

`PUT /receivingorder/{id}/reject` и `PUT /shippingorder/{id}/reject` требуют соответственно `RECEIVING_ORDER_REJECT/DELETE` и `SHIPPING_ORDER_REJECT/DELETE`. `PUT /routes/{id}/reject` требует `ROUTE_REJECT/DELETE` и вызывает reject сервисов заявок в транзакции рейса; controller-аннотации заявок на этот внутренний вызов не переносятся. Проверка дополнительного права внутри сервисов сохраняется.

| Предыдущий статус | Результат reject | Сообщение отмены |
|---|---|---|
| `DRAFT`, `ON_REVIEW` | Отмена при допустимом переходе | Не создаётся |
| `ACCEPTED` | Отмена и постановка пакета в той же транзакции | Только если `terminalArea.code = CONTAINER` |
| `IN_PROGRESS`, `DONE` | Дополнительно требуется `ReceivingOrder.RejectAfterStart` / `ShippingOrder.RejectAfterStart` с уровнем `DELETE`; иначе `AccessDeniedException` до изменения состояния | Не создаётся |
| `REJECTED` | Ранний возврат текущей заявки | Повторный пакет не создаётся |

Миграция `20261023_order_reject_after_start_permissions` добавляет пути прав и `NO_ACCESS` для существующих role_id из role_permission. Фактические права пользователя зависят от конфигурации среды.

## Снимок и транзакция

Сервис блокирует заявку через `findAndLock`, проверяет переход/права, вызывает `ContainerStatusService.cancel*Order`, устанавливает `REJECTED` и обновляет DAO. Только если прежний статус был `ACCEPTED`, вызывается `OrderCancellationService.enqueue`.

Enqueue пропускает площадки, отличные от `CONTAINER` (включая null). Для контейнерной площадки обязателен рейс, иначе `ValidationException("Order.CancelRouteRequired")`. Поставка `RAILWAY` использует ReceivingRailwayRouteChainPackageExportService, остальные transportType — ReceivingAutoRouteChainPackageExportService; вывоз — ShippingRouteChainPackageExportService. Builder получает рейс и список **из одной отменяемой заявки**, а также собирает связанные строки и справочники. Это структура route chain package, сохранённая в момент отмены.

В поставке enqueue выполняется до `updateReceivingOrderLinks(id, [])`: ЖД-накладные ещё доступны построителю снимка. Сохранение payload идёт уже после установки статуса `REJECTED`. `OrderCancellationService` имеет `MANDATORY`: требуется текущая транзакция. Ошибка построения/сериализации или отсутствие рейса прерывают отмену; отдельного успешного commit статуса перед enqueue нет.

Сохраняются новый UUID строки, rootObjectId заявки, entityType `RECEIVING_ORDER` / `SHIPPING_ORDER`, messageType `RECEIVING_ORDER_CANCEL` / `SHIPPING_ORDER_CANCEL`, строка JSON в `payload`; builder задаёт attempts=0. Детали хранения — [outbound_data](../database/outbound-data-as-is.md).

BEFORE_COMMIT-слушатели статуса вызывают `syncRouteStatus(routeId, false)` при новом `REJECTED`: статус рейса пересчитывается без отправки обычного интеграционного пакета этим вызовом. Ошибки синхронизации рейса внутри catch логируются. У ReceivingOrderListener пересчёт категорий накладных расположен до route-null guard и вне этого catch: ошибка категории может прервать commit отмены. Это не отменяет уже созданные ранее outbound-строки.

## Отправка и повторные попытки

ScheduledOrderCancelExportService запускается с fixedDelay `${datareon.cron.orderCancel:5000}` (миллисекунды; в application.yaml также 5000). Последовательно обрабатывает receiving, затем shipping, вызывая экспорт до отсутствия подходящей строки. Пять секунд — задержка планировщика, не интервал retry.

| Тип | Внешний адрес |
|---|---|
| `RECEIVING_ORDER_CANCEL` | `POST ${datareon.base.url}/receivingOrderCancel` |
| `SHIPPING_ORDER_CANCEL` | `POST ${datareon.base.url}/shippingOrderCancel` |

BaseDatareonRestService задаёт JSON и Basic Authorization. OrderCancelExportService читает сохранённый JSON, не перестраивает его по актуальной заявке. `@JsonValue` у OrderCancelRequestDto отправляет сам JSON payload, без обёртки с полями messageType/payload. Пустая строка/null дают `Order cancellation payload is missing`; невалидный JSON — `Invalid order cancellation payload`.

Общий BaseExportService выбирает `success=false/null`, `attempts<5`, с истёкшим ожиданием. Первый поиск сортирует createdAt DESC. Затем выбирает подходящие строки с теми же rootObjectId/messageType и блокирует их через SKIP LOCKED. Строки группы не сравниваются по payload: отправляется DTO из первого возвращённого элемента, результат записывается всем заблокированным строкам. Порядок этой группы явно не задан.

Каждая итерация экспорта — `REQUIRES_NEW`. При успехе HTTP-ответа и разборе тела как UUID: success=true, errorMessage=null, attempts+1, lastAttemptAt, responseCode и messageId. Любой Throwable в блоке отправки/обработки ответа переводит группу в success=false, увеличивает attempts, сохраняет lastAttemptAt и текст ошибки. В обработчике ошибки responseCode/messageId не очищаются; они могут остаться от прежней обработки, включая частично обработанный ответ.

ExpiredCondition разрешает строку при lastAttemptAt=null либо выражении `(elapsed_seconds / 60 - 5 * attempts) > 0` на стороне БД. После первой неудачи порог — более пяти минут, далее более десяти, пятнадцати, двадцати; точный момент зависит от SQL-арифметики и планировщика. При attempts=5 автоматический выбор прекращается.

## Просмотр и ручной resend

`GET /outbounddata/{id}` и `POST /outbounddata/page` требуют `Integration/READ`; `PUT /outbounddata/resend/{id}` — `Integration/WRITE`. Resend не выполняет HTTP-отправку: устанавливает attempts=0, errorMessage=null, success=null, lastAttemptAt=null. Payload, messageId и responseCode сохраняются. Следующая отправка выполняется планировщиком; сбросить можно и ранее успешную строку. В публичном OutboundDataDto поля payload нет.

## Проверки и открытые вопросы

Исходники OrderCancellationServiceTest покрывают выбор авто/ЖД builder поставки, одну выбранную заявку в пакете, вывоз, отсутствие рейса и пропуск warehouse. OrderCancellationTest проверяет ранние/поздние статусы, дополнительные права, последовательность снимка до отвязки накладных и повторный reject. OrderCancellationListenerTest проверяет syncRouteStatus с false. Эти тесты в ходе документирования не запускались; Mockito-вызовы не доказывают работу Spring-транзакций или HTTP.

- `INFERENCE`: ошибка после приёма пакета внешней системой (например, тело ответа не UUID или ошибка локального commit) допускает повтор внешнего эффекта. Идемпотентность Datareon/TOS исходниками ALIS не подтверждена.
- `INFERENCE`: при нескольких eligible строках одного rootObjectId/messageType разные payload могут получить общий результат без отдельной отправки каждого. Нужен сценарий проверки конкуренции и дублей; SQL UNIQUE на эту пару в просмотренной цепочке нет.
- `OPEN_QUESTION`: согласован ли с TOS запрет отправки отмены из IN_PROGRESS/DONE и для WAREHOUSE?
- `OPEN_QUESTION`: фактический контракт ответного UUID, дедупликация и обработка повторов на внешней стороне.
- `OPEN_QUESTION`: runtime-проверка сериализации, HTTP-ошибок, исчерпания retry, транзакционного rollback и нескольких экземпляров scheduler.

## Источники

- [ReceivingOrderService.java](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/receivingorder/ReceivingOrderService.java)
- [ShippingOrderService.java](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/shippingorder/ShippingOrderService.java)
- [RouteService.java](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/route/RouteService.java)
- [OrderServiceUtils.java](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/OrderServiceUtils.java)
- [OrderCancellationService.java](../../../web-layer/src/main/java/ru/korusconsulting/alis/datareon/service/ordercancel/OrderCancellationService.java)
- [OrderCancelExportService.java](../../../web-layer/src/main/java/ru/korusconsulting/alis/datareon/service/ordercancel/OrderCancelExportService.java)
- [OrderCancelDatareonRestService.java](../../../web-layer/src/main/java/ru/korusconsulting/alis/datareon/service/ordercancel/OrderCancelDatareonRestService.java)
- [ScheduledOrderCancelExportService.java](../../../web-layer/src/main/java/ru/korusconsulting/alis/datareon/service/ordercancel/ScheduledOrderCancelExportService.java)
- [OrderCancelRequestDto.java](../../../web-layer/src/main/java/ru/korusconsulting/alis/datareon/dto/ordercancel/OrderCancelRequestDto.java)
- [BaseExportService.java](../../../web-layer/src/main/java/ru/korusconsulting/alis/datareon/service/BaseExportService.java)
- [BaseDatareonRestService.java](../../../web-layer/src/main/java/ru/korusconsulting/alis/datareon/service/BaseDatareonRestService.java)
- [ExpiredCondition.java](../../../db-layer/src/main/java/ru/korusconsulting/alis/filter/outbounddata/ExpiredCondition.java)
- [OutboundDataService.java](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/outbounddata/OutboundDataService.java)
- [OutboundDataController.java](../../../web-layer/src/main/java/ru/korusconsulting/alis/controller/outbounddata/OutboundDataController.java)
- [v.1.35.0_20261023_order_reject_after_start_permissions.sql](../../../db-layer/src/main/resources/db/changelog/v.1.35.0/v.1.35.0_20261023_order_reject_after_start_permissions.sql)
- [OrderCancellationServiceTest.java](../../../web-layer/src/test/java/ru/korusconsulting/alis/datareon/service/ordercancel/OrderCancellationServiceTest.java)
- [OrderCancellationTest.java](../../../web-layer/src/test/java/ru/korusconsulting/alis/service/OrderCancellationTest.java)
- [OrderCancellationListenerTest.java](../../../web-layer/src/test/java/ru/korusconsulting/alis/service/OrderCancellationListenerTest.java)
