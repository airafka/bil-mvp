# Собственник КТК в исходящих пакетах ALIS → Datareon

Справка для аналитика 1С: в каких исходящих пакетах, в каком блоке и в каком виде ALIS передаёт признак «Собственник КТК» (выбранный Client поставки, snapshot строки вывоза либо ownerClient безномерной строки; это не всегда текущий registry-владелец, бизнес-процесс описан в [container-remains-and-owner-as-is.md](../business-rules/container-remains-and-owner-as-is.md)).

Признак передаётся тремя разными исходящими пакетами — по одному на транспортный сценарий (автовывоз, поставка авто, поставка ЖД). Отдельного, вынесенного из пакетов сообщения «только про владельца» нет: поле всегда идёт внутри массива с данными контейнера.

## Сводная таблица

| Пакет (бизнес-сценарий) | Технический пакет / endpoint | Блок (массив) в пакете | Поле | Статус на 11.11.2026 |
|---|---|---|---|---|
| Поставка, авто | `RECEIVING_AUTO_ROUTE_CHAIN_PACKAGE`, `POST /receivingOrderAutoContainer` | `ReceivingOrderContainer[]` | `ownerContainerId` | Источник поля подтверждён в builder; приём внешней системой не проверен |
| Поставка, ЖД | `RECEIVING_RAILWAY_ROUTE_CHAIN_PACKAGE`, `POST /receivingOrderContainer` | `WaybillContainer[]` | `ownerContainerId` | Источник поля подтверждён в builder; приём внешней системой не проверен |
| Вывоз (любой транспорт) | `SHIPPING_ROUTE_CHAIN_PACKAGE`, `POST /shippingOrderContainer` | `ShippingOrderContainer[]` | `containerOwnerId` | Текущее имя после KIS-4870; DRAFT/ON_REVIEW синхронизируются с регистром, принятые строки сохраняют снимок. |
| Вывоз без номера | `SHIPPING_ROUTE_CHAIN_PACKAGE`, `POST /shippingOrderContainer` | `ShippingOrderContainerQty[]` | `containerOwner` | UUID выбранного ownerClient, null guard в экспортёре отсутствует. |

Пакет по заявкам на услугу (`SERVICE_ORDER_CHAIN_PACKAGE`, `/serviceOrder`) этого поля не содержит вовсе — собственник КТК в этом сценарии не передаётся.

## Формат поля

Поля владельца — GUID, ссылка на запись клиента. Карточки клиентов передаются в Client[]. Receiving builders добавляют выбранных владельцев. ShippingRouteChainPackageExportService формирует Client[] только из ShippingOrder.client: отдельные containerOwner/ownerClient туда не добавляются. Если владелец не совпал ни с одним клиентом заявок пакета, его UUID может не иметь карточки в Client[]. Это подтверждение состава builder, не результат доставки в 1С.

Если у контейнера собственник на момент выгрузки не определён (в поставке — не выбран при добавлении контейнера в заявку; в вывозе — контейнер ещё не был принят на склад), для номерных строк поле может быть null. У qty exporter безусловно вызывает ownerClient.getId(): отсутствие владельца способно сорвать сборку, а не сформировать null.

## Блок вывоза: исправление 08.10.2026

С 22.09 по 08.10.2026 в сценарии «Вывоз» (`ShippingOrderContainer[].ownerContainerId`) поле всегда приходило пустым — это был дефект на нашей стороне. Исправление KIS-4830 (08.10.2026): при добавлении контейнера в заявку на вывоз (или при замене контейнера в строке) ALIS запоминает текущего собственника контейнера и передаёт его в пакете.

Что важно учитывать при приёме в 1С:

- DRAFT/ON_REVIEW строки теперь синхронизируются при штатной смене владельца; принятые строки эта синхронизация не меняет;
- миграция 20261102 исправляет неудалённые DRAFT/ON_REVIEW строки при наличии регистра; старые принятые строки этим backfill не исправляются;
- код миграции не создаёт повторные отправки уже отправленных пакетов; фактическая история доставок не проверялась.

Технический разбор — [container-remains-and-owner-as-is.md](../business-rules/container-remains-and-owner-as-is.md#владелец-на-строке-вывоза-kis-4830).

## Связанные документы

- [Route chain package export: полный контракт всех 4 пакетов](../business-rules/route-chain-package-export-as-is.md)
- [Регистр остатков и владельца КТК: бизнес-процесс](../business-rules/container-remains-and-owner-as-is.md)
- [Обработка пакетов на стороне Datareon](route-chain-package-datareon-processing.md)

## Несовместимое изменение и область подтверждения

Для вывоза прежнее ownerContainerId заменено на containerOwnerId; поставка сохраняет ownerContainerId. Qty передаёт containerOwner. Приём этих имён Datareon/1С нужно подтвердить. Shipping Client[] включает только клиентов заявок, поэтому присутствие отличающегося владельца не гарантировано; подробности и риски — [актуальная сверка](../business-rules/shipping-container-owners-as-is.md).
