# Интеграционные контуры ALIS

> **Сверено:** backend `3d3899d5d` (13.11.2026) · **Основание:** `SOURCE_CONFIRMED` — исходный код, миграции и тесты (тесты не запускались); БД и стенд не проверялись. Содержание внешних материалов 1С/Datareon — `EXTERNAL_SNAPSHOT` в соответствующих документах.

Раздел описывает обмен данными между системами как сквозной процесс. Документ одного контура не делится на независимые описания 1С, Datareon и ALIS: это затруднило бы поиск преобразования, из-за которого изменилось поле. Вместо этого основной документ показывает всю цепочку, а большие технические контракты вынесены в отдельные паспорта и подключаются к контексту LLM только при необходимости.

Канонические имена участников и различие ролей «источник факта / посредник / операционное хранилище / исполнитель» определены в [бизнес-карте систем](../business/systems.md). Интеграционный документ уточняет эти роли для одного потока, но не назначает master-систему только по направлению HTTP-вызова.

## Как устроен один контур

```mermaid
flowchart LR
    B[Бизнес-объект и словарь] --> S[Система-источник]
    S --> M[Шина / Datareon]
    M --> T[Преобразования и маршрутизация]
    T --> A[API и DTO ALIS]
    A --> L[Серверная логика и БД]
    L --> O[Ошибки, мониторинг и открытые вопросы]
```

Для каждого контура фиксируются:

1. канонический термин и бизнес-синонимы;
2. источник, условие отбора и структура исходного объекта;
3. внешний транспорт, маршрут и промежуточный тип данных;
4. преобразования значений и единиц измерения;
5. endpoint, DTO, серверная логика и физическая модель ALIS;
6. правила повторной обработки, ошибки и наблюдаемость;
7. подтверждённые расхождения между слоями;
8. версия каждого источника и граница достоверности.

## Обновление 29 сентября 2026: мониторинг Datareon удалён, появился stub-контур

**Мониторинг.** Коммит `a5a40f94` («remove datareon monitoring», 17.09.2026) убрал `MonitorClient` и инфраструктуру инцидентов (`IncidentDto`/`IncidentType`/`IncidentSeverity`, флаг `datareonMonitoringEnabled`) без замены; в текущем коде этих классов нет. Это касается **всех** контуров: убраны `logInboundPacket` на входящих endpoint'ах [DatareonController](../../../web-layer/src/main/java/ru/korusconsulting/alis/controller/datareon/DatareonController.java) (`/contract`, `/contractor`, `/cell-occupancy`, `/event`, `/remain`, `/container-remain`, `/batch`, `/railway-carriage-remain`) и `logOutboundPacket` в [`BaseDatareonRestService`](../../../web-layer/src/main/java/ru/korusconsulting/alis/datareon/service/BaseDatareonRestService.java) — базовом классе исходящих `*DatareonRestService`. Удалена именно эта система мониторинга/инцидентов; обычные логи, inbound/outbound записи и обработку ошибок нужно проверять отдельно по конкретному контуру.

**Stub-контур.** `POST /datareon/contract_with_contractor` (`f11ff7ba` 18.09.2026, `a912531c` 23.09.2026) — явно временный endpoint (`@Operation(description = "Temporary endpoint...")`): принимает `JsonNode` произвольной формы, только логирует и ничего не сохраняет. Не путать с TO-BE предложением `/datareon/contract-with-client` из внешнего материала аналитика «Интеграция договоров и контрагентов из 1С:ДО» (в репозиторий не загружен; в коде такого endpoint нет). Подробнее — [contract-edo-datareon-as-is.md](../business-rules/contract-edo-datareon-as-is.md).

## Исходящее направление: ALIS → Datareon

Таблица «Реестр контуров» ниже — про входящие потоки (1С → Datareon → ALIS). Для обратного направления (route chain package, 4 пакета — Shipping/ReceivingAuto/ReceivingRailway/ServiceOrder) отправляющая ALIS-сторона разобрана в [route-chain-package-export-as-is.md](../business-rules/route-chain-package-export-as-is.md), а обработка на стороне Datareon (по материалу, предоставленному аналитиком, не source-level) — в [route-chain-package-datareon-processing.md](route-chain-package-datareon-processing.md). Справка для аналитика 1С о передаче собственника КТК (поставка: `ownerContainerId`; вывоз: `containerOwnerId` и qty `containerOwner`) в этих пакетах — [container-owner-outbound-contract.md](container-owner-outbound-contract.md).

Входящие события и остатки Datareon, для которых нет отдельного сквозного документа (`/event`, `/remain`, `/container-remain`, `/batch`, `/cell-occupancy`, `/contract`, `/contractor` и др.), описаны со стороны ALIS в [реестре входящих событий](../business-rules/inbound-event-registry-as-is.md) и связанных с ним документах `business-rules/*-datareon-as-is.md`.

## Реестр контуров

| Контур | Сквозной документ | Технический контракт | Состояние |
|---|---|---|---|
| 1С ЭТРАН → Datareon → ALIS, ЖД-накладная | [ГУ-27 / накладная ЭТРАН / ЖДН / СМГС 2015](1c-etran-waybill-gu27-as-is.md) | [тип `Etran27` в Datareon](1c-etran-waybill-gu27-datareon-contract.md) | Внешний snapshot вложений от 22.09.2026; backend-часть сверена с `3d3899d5d`, deployed 1С/Datareon и отсутствующие оригиналы не проверены |
| 1С WMS → Datareon → ALIS | — | — | Материалы не получены |
| 1С TOS → Datareon → ALIS | — | — | Материалы не получены |
| 1С CRM → Datareon → ALIS | — | — | Материалы не получены |

`1С ЭТРАН` в этой таблице — имя интеграционного источника. В будущих материалах нужно отдельно проверять, является ли WMS/TOS/CRM конфигурацией 1С, внешней системой или только бизнес-названием интерфейса.

## Правило именования

Имя файла строится как `<источник>-<посредник>-<объект>-as-is.md`. Канонический термин размещается в заголовке, а все разговорные названия — в явной таблице синонимов. Синоним не означает юридическую или форматную эквивалентность документов: он означает, что пользователи могут так называть объект в рамках данного процесса.

## Как загружать в LLM

- Для вопроса о процессе: этот индекс + сквозной документ.
- Для вопроса о полях Datareon: добавить технический контракт.
- Для вопроса о поведении ALIS: добавить [Waybill AS-IS](../business-rules/waybill-etran-as-is.md), нужные [DTO](../dto/catalog/datareon/inbound/WaybillIntegrationDto.md) и [физические модели](../database/waybill-root-as-is.md).
- Для подготовки ТЗ: добавить [GPT-карточку ревью](../traceability/tz-review-template.md) и [чек-лист](../traceability/tz-checklist.md).

В prompt нужно просить модель различать четыре слоя: внешний факт из предоставленного материала, подтверждённый ALIS source-level AS-IS, вывод из сопоставления и TO-BE-решение.

## Отмена заявок

[Outbound отмены поставки и вывоза](order-cancellation-outbound-as-is.md): снимок payload, права, транзакции, HTTP, retry и resend.

## Уточнение целевой сверки 11.11.2026

[Досылочные: входной контракт и чтение](../business-rules/waybill-supplementary-as-is.md); [владельцы КТК: актуальный контракт](../business-rules/shipping-container-owners-as-is.md).

## Целевая сверка безопасности и инфраструктуры 11.11.2026

[Datareon: permitAll, no-op contract_with_contractor и удалённый мониторинг](../business-rules/security-and-integration-boundaries-as-is.md).
