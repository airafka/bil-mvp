# Копирование заявок

> **Сверено:** backend `3d3899d5d` (12.11.2026) · **Основание:** `SOURCE_CONFIRMED` — исходный код, миграции и тесты (тесты не запускались); БД и стенд не проверялись.

Копирование создаёт новый корень через обычный create-процесс. Поэтому новая заявка получает новый UUID, новый номер, статус `DRAFT` и заново созданные обязательные услуги договора.

Copy endpoints не принимают request DTO: единственный входной параметр — UUID исходной заявки в path. Внутри сервис формирует модель новой заявки и проводит её через тот же create lifecycle; обязательность полей обычных HTTP create DTO к copy-запросу напрямую не применяется. Контракты ручного создания: [ReceivingOrderCreationDto](../dto/receiving-order/ReceivingOrderCreationDto.md) и [ShippingOrderCreationDto](../dto/shipping-order/ShippingOrderCreationDto.md).

## Общая семантика

| Операция | Копирует корень | Копирует дочерние данные |
|---|---:|---:|
| partial copy | да | нет |
| full copy | да | да, в зависимости от типа заявки |

Обе операции доступны по `POST /{id}/partial-copy` и `POST /{id}/full-copy` с permission `*_ORDER_COPY` и READ level.

## Поля корня

### Поставка

Копируются (`ReceivingOrderService.copyOrder`): клиент, владелец КТК по умолчанию (`defaultContainerOwner`), договор, площадка, транспорт, валюта, `deliveryType`, срок хранения, `needTransport`, контакт, грузоотправитель, комментарий, номер транспортной накладной (`waybill`), плательщик и станции.

Не копируются: исходные `id`, `number`, `status`, audit-поля, плановая/фактическая дата, рейс, решение по документам (`documentConfirmed`), агрегированные итоги и связи с ЖД-накладными.

### Вывоз

Копируются (`ShippingOrderService.copyOrder`): клиент, договор, площадка (`id`/`code`/`name`), транспорт, `fillingType`, валюта, `deliveryType`, `needTransport`, грузополучатель, контакт и комментарий.

Не копируются: исходные `id`, `number`, `status`, audit-поля, плановая/фактическая дата, рейс, агрегаты и `ktkNumberUnknown`. Адрес грузополучателя не переносится, а заново вычисляется при create из `consignee.addressFact` (с проверкой роли и клиента — если грузополучатель с тех пор утратил роль, копирование упадёт с `ShippingOrder.InvalidConsigneeRole`).

В обоих copy-методах контакт читается без null-check, хотя поле модели nullable. Копирование заявки без контакта может завершиться `NullPointerException`; это дефект/ограничение текущей реализации.

Копия проходит обычный create: для поставки `CONTAINER + RAILWAY` повторно проверяются плательщик и станции, для обеих сторон — `OrderCombinationValidator`.

## Full copy: поставка

Full copy запрещён для `transportType=RAILWAY`.

| Тип | Что копируется |
|---|---|
| `CONTAINER + VEHICLE` | `ReceivingOrderContainer` (КТК, пломбы, порожний, таможня, класс опасности, владелец, `ktkNumberUnknown`), затем их `ReceivingOrderContainerItem` с переназначением на новые контейнерные строки |
| `WAREHOUSE + VEHICLE + BY_GOOD` | товары |
| `... + BY_CARGO` | blackbox-строки |
| `... + BY_GOOD_WITH_CARGO_WITHOUT_DETAILS` | товары и `totalCargoQuantity` |
| `... + BY_GOOD_WITH_CARGO_WITH_DETAILS` | товары, затем грузы с переназначением на новые товарные строки |

Не копируются рейс, накладные и старые дополнительные операции; обязательные услуги создаются заново по актуальным условиям договора. Дочерние строки создаются через обычный `add` своих сервисов, поэтому проходят их проверки (в т.ч. партии товара `OrderGoodBatchValidator`).

## Full copy: вывоз

Full copy запрещён для `transportType=RAILWAY`.

| Тип | Что копируется |
|---|---|
| `CONTAINER + VEHICLE` | `ShippingOrderContainer` (КТК, пломбы, порожний, таможня, класс опасности, `random`, `ktkNumberUnknown`), затем `ShippingOrderContainerItem` |
| `WAREHOUSE + VEHICLE + BY_GOOD` | товары |
| `... + BY_CARGO` | blackbox-строки |
| `... + BY_GOOD_WITH_CARGO_WITH_DETAILS` | товары, затем грузы |

Не копируются рейс, ЭТРАН, вагоны, безномерные КТК (`ShippingOrderContainerQty`) и старые дополнительные операции.

## Требования к будущим изменениям

В ТЗ на копирование нужно перечислять поля белым списком. Формулировка «скопировать заявку полностью» недостаточна: маршрут, даты, транспортные документы, интеграционные состояния и фактические значения обычно не должны наследоваться.

Связанные документы: [типы заявок](order-types.md), [поставка](receiving-orders.md), [вывоз](shipping-orders.md), [DTO](../dto/README.md).
