# Основные и досылочные накладные

Срез `dev` `3d3899d5d`, 11.11.2026; `AS_IS / SOURCE_CONFIRMED` по коду, миграциям и исходникам тестов. Изменение `930a1d076` от 10.11.2026. Среда и внешняя система не проверялись, тесты не запускались. Документ уточняет [общий импорт ЭТРАН](waybill-etran-as-is.md).

## Входной контракт и разрешение связи

В `WaybillIntegrationDto.Waybill` добавлены `waybill_parent_identifier` (String parentIdentifier) и `related_document` (список RelatedDocument с полем waybill_connection_type). Связь обрабатывается только при точном входном type=`Досылочная накладная`.

Непустой parent identifier преобразуется в Integer. Ссылка на собственный identifier отклоняется с `ValidationException("Досылочная накладная не может ссылаться на саму себя")`. Если основная уже есть, сохраняется FK; если нет — только identifier, FK остаётся NULL. Тип связи читается **только из первого элемента** related_document: код должен преобразоваться в Integer и существовать в справочнике, иначе `Неизвестный код связи накладных: …`. Дополнительные элементы не определяют тип связи. Пустые значения не очищают прежние связи; null-элемент списка отдельно не защищён.

После сохранения накладной и дочерних строк выполняется синхронизация: для основной находятся ожидающие досылочные с её identifier, проставляется parent FK, копируется категория основной. Поддержаны оба порядка поступления и несколько досылочных на одну основную. При повторном импорте основной исключения связанных дочерних накладных применяются снова. Resolver при наличии parent возвращает его категорию до остальных проверок; без parent применяет обычные правила станций/статуса поставки.

## Исключение вагонов основной

Для каждого вагона досылочной ищутся все WRC основной с тем же ID физического RailwayCarriage. У найденных WRC ставится excluded=true, затем excluded=true у **всех контейнеров этого WRC**, а не только совпавших КТК. У досылочной собственные строки этим методом не исключаются. Удаления строк нет; обратное снятие excluded при смене родителя/состава этим алгоритмом не реализовано.

Запросы вагонов по поставке, exists/type и проверки завершения учитывают wrc.excluded=false; запросы контейнеров по поставке требуют wc.excluded=false и wrc.excluded=false. Выгрузки ReceivingTransportManifest и ReceivingRailwayRouteChainPackage, а также счётчики waybill_view исключают такие строки. Прямые запросы по ID накладной/вагона не все фильтруют excluded: флаг не является глобальным soft-delete.

## Повтор существующего identifier

Danger-коды разрешаются до поиска существующей накладной. Повтор обновляет status, непустой type, connection-поля при соответствующем входном type, категорию и товары. Номер, станции, payer, даты, состав вагонов/КТК, ЗПУ и отметки не заменяются повтором. Проверка состава для создания новой накладной повторно не вызывается.

Товары сопоставляются по `(etsngCode.id, gngCode)`. Найденная строка сохраняет UUID, получает новые грузовые характеристики, веса, размеры, опасность и таможенные данные; ненайденная добавляется. Старые строки, отсутствующие во входном списке, не удаляются. products=null пропускает обновление, пустой список не очищает товары. Это частичный upsert, а не замена всего агрегата.

## Чтение и группировка

`GET /waybill/{id}/related-documents`, право `WAYBILL/READ`, возвращает список WaybillRelatedDocumentDto: id, number, connectionTypeCode, connectionTypeName. Для досылочной — основная, если FK разрешён; иначе пустой список. Для type=`Накладная на погрузку` — дочерние по parent FK. Для остальных типов — пустой список. Причина связи берётся из досылочной и может быть NULL. Прямой readById и method permission сами по себе не доказывают ограничение по клиенту; security runtime не проверялся.

В сгруппированном ответе WaybillStationPairGroupDto.WaybillDto появились type и children. Если основная входит в текущую группу выборки, досылочная вложена в её children как полный DTO; иначе остаётся на верхнем уровне. Это группировка текущих rows, а не загрузка всех родственников из БД. Вложение одноуровневое, вложенные children формируются пустыми; произвольная рекурсивная иерархия не поддержана алгоритмом. waybillCount остаётся количеством исходных rows, а не только корней.

## Физическая модель

Миграция `v.1.35.0_20261105_KIS-4627_waybill_relations.sql` (подключена в cumulative, вошла 10 ноября) создаёт:

| Объект | Изменение |
|---|---|
| waybill_connection_type | id UUID PK; code INTEGER NOT NULL UNIQUE; name VARCHAR(1000) NOT NULL; записи 45 «Отцеп», 47 «Ремонт» |
| waybill | waybill_parent_id UUID nullable FK → waybill(id); waybill_parent_identifier INTEGER nullable; waybill_connection_type_id UUID nullable FK → справочник |
| Индексы | waybill_parent_identifier_idx и waybill_parent_id_idx |
| waybill_railway_carriage | excluded BOOLEAN NOT NULL DEFAULT FALSE |
| waybill_container | excluded BOOLEAN NOT NULL DEFAULT FALSE |

SQL не задаёт ON DELETE CASCADE для этих FK, уникальность parent identifier, CHECK против самоссылки или циклов. Самоссылка отсекается только описанной проверкой импорта; более длинные циклы этим кодом явно не защищены.

## Проверки и открытые вопросы

В WaybillDatareonServiceIntegrationTest есть сценарии main-first, supplementary-first, нескольких досылочных, повторной обработки и обновления груза; WaybillServiceIntegrationTest — children и досылочная без основной в выборке. Исходники прочитаны, тесты не запускались. HTTP endpoint related-documents, конкуренция импорта, неизвестные коды/циклы и обратное включение вагонов требуют отдельных проверок.

`INFERENCE`: смена связи не восстанавливает исключения старой основной; отсутствие удаления старых товаров может сохранять устаревший груз. `OPEN_QUESTION`: бизнес-правила для исправления ошибочной связи, нескольких причин в related_document и нескольких уровней досылки. Подтверждение UI и фактической схемы внешнего JSON этой сверкой не получено.

## Завершение сверки 930a1d076: 12.11.2026

Дополнительно сопоставлены оба изменённых integration test: main-first/child-first, два ребёнка одной основной, сохранение excluded при повторах, сохранение ID и обновление веса product. Hierarchy-тест ожидает общий count=3 при одном корневом DTO с двумя полными children; children имеют пустой собственный children, а waybillParentId отсутствует в JSON. Досылочная без найденной основной остаётся на верхнем уровне. Это assertions исходников, без запуска тестов.

Export-ветки ReceivingTransportManifest/ReceivingRailwayRouteChainPackage явно исключают excluded WRC/WC; в package проверяется также excluded родительского WRC. Эти изменения не означают, что каждый произвольный byWaybill DAO-вызов автоматически фильтрует excluded. Entity-info миграция upsert-ит WaybillConnectionType по name, обновляя label/description; отдельный HTTP CRUD этого справочника коммит не добавляет. Код related-documents и source-level READ permission сверены отдельно от генератора API.

## Источники

- [WaybillIntegrationDto.java](../../../web-layer/src/main/java/ru/korusconsulting/alis/dto/datareon/inbound/WaybillIntegrationDto.java)
- [WaybillDatareonService.java](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/datareon/WaybillDatareonService.java)
- [WaybillService.java](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/waybill/WaybillService.java)
- [WaybillController.java](../../../web-layer/src/main/java/ru/korusconsulting/alis/controller/waybill/WaybillController.java)
- [WaybillCategoryResolver.java](../../../db-layer/src/main/java/ru/korusconsulting/alis/model/waybill/WaybillCategoryResolver.java)
- [WaybillContainerRepository.java](../../../db-layer/src/main/java/ru/korusconsulting/alis/model/waybillcontainer/WaybillContainerRepository.java)
- [WaybillRailwayCarriageRepository.java](../../../db-layer/src/main/java/ru/korusconsulting/alis/model/waybillrailwaycarriage/WaybillRailwayCarriageRepository.java)
- [view_waybill.sql](../../../db-layer/src/main/resources/db/changelog/rerunnable/view_waybill.sql)
- [v.1.35.0_20261105_KIS-4627_waybill_relations.sql](../../../db-layer/src/main/resources/db/changelog/v.1.35.0/v.1.35.0_20261105_KIS-4627_waybill_relations.sql)
- [cumulative.yml](../../../db-layer/src/main/resources/db/changelog/v.1.35.0/cumulative.yml)
- [WaybillDatareonServiceIntegrationTest.java](../../../web-layer/src/integrationTest/java/ru/korusconsulting/alis/service/datareon/WaybillDatareonServiceIntegrationTest.java)
- [WaybillServiceIntegrationTest.java](../../../web-layer/src/integrationTest/java/ru/korusconsulting/alis/service/waybill/WaybillServiceIntegrationTest.java)
