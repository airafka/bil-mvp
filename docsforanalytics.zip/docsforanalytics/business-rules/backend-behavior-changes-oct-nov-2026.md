# Уточнения бизнес-поведения: октябрь–ноябрь 2026

Целевая сверка `dev` `3d3899d5d`, 11.11.2026. AS_IS / SOURCE_CONFIRMED по коду и исходникам тестов; стенд и Java-тесты не запускались. Это журнал конкретных изменений, а не заявление о полной сверке контуров.

## Копирование рейса

`471133b1f` временно начал переносить дату исходника, но итоговый `8f622a62e` в тот же день заменил это на Instant.now(). Текущий `POST /routes/{id}/partial-copy` (ROUTE_COPY/READ) создаёт DRAFT-рейс с текущим временем планирования, копирует тип/площадку/транспорт/комментарий и автомобильные ссылки; заявки не копируются. Старое описание «дата не задаётся» неверно. Это серверный Instant в момент выполнения, не исходная дата и не локальная дата пользователя. Метод вызывает add внутри @Transactional copyRoute; controller validation обычного create через этот вызов не запускается.

## Завершение ЖД-поставки при прибытии вагона

`4c1cfe13d` добавил проверку обеих контейнерных моделей: наличие прямого ReceivingOrderContainer **или** WaybillContainer блокирует завершение заявки из вагонной ветки CARRIAGE_ARRIVED. Текущий WaybillContainerDaoService использует countActiveContainersByReceivingOrderId: excluded контейнеры и контейнеры excluded-вагонов не учитываются. Все активные вагоны должны быть завершены, а переход в DONE — разрешён моделью. Прежний риск «WaybillContainer полностью игнорируются и последний вагон преждевременно закрывает заявку» закрыт кодом. Проверки принадлежности _id заявке и nullable TaskStatus — отдельные вопросы; исправление этого условия их не доказывает.

## Вес груза КТК вывоза

Несмотря на название коммита «receiving Cargo-Weight», `818586514` изменяет ShippingOrderContainer.getCargoWeight: `(weight или 0) - (container отсутствует ? 0 : container.weight)`. NULL у строки weight или ссылки container больше не вызывает прежнюю NPE. Оставшийся случай — существующий container с NULL weight: отдельной защиты в getter нет. Container.weight получил JPA @Column(nullable=false); это не является backfill/миграцией старых данных. Отрицательный результат subtraction не ограничен этим методом. Отчёт ТН продолжает суммировать результаты и умножать на 1000; сам getter не делает пересчёт единиц.

## Количество КТК в заявке на услугу

`9155b20a8`: ServiceOrderService.findById после super.findById обогащает ServiceOrderDto.containerQuantity через countByServiceOrderId. Это COUNT строк ServiceOrderContainer по serviceOrder.id, не COUNT DISTINCT физических КТК. Дополнительных условий deleted/статуса в новом count нет. Описание «detail не обогащается» устарело. List/page имеют собственную логику обогащения; нельзя переносить этот COUNT на любые DTO-ответы других операций.

## Фильтры и meta

| Коммиты | Изменение текущего кода | Граница |
|---|---|---|
| 907bbe2a8 | ReceivingOrderPredicate применяет clientPredicate к явному пути ReceivingOrder.client | Это исправление association path; не доказательство всей client isolation |
| 93915517d | ClientService для MetaContext entityName=receivingorder без associationPath подставляет `client`, сохраняет entityIds/scope | Непустой associationPath и другие entityName не переписываются |
| e9fa1fc04, c0724fd89 | ReceivingOrderGoodFilter.code: SearchString по clientGood.code; meta alias code→clientGood.code | Это код/артикул номенклатуры, не UUID товарной строки |
| 2fccd6bf5 | ShippingOrderGood: тот же code predicate и meta alias | byOr передаётся общему addFilterCondition |
| 29c96653f | Receiving/ShippingOrderCargo.code по receiving/shippingOrderGood.clientGood.code; meta code по тому же пути | Не код Cargo и не код GoodPackage |
| b42ab46f7 | RailwayCarriage обычный filter добавляет type/model по кодам связей; meta использует RailwayCarriageMetaFilter и отдельную railway_carriage_meta_view | Обычный filter и meta filter имеют разные типы/имена полей |

В meta вагона railwayCarriageType применяется к view.type, model — к view.model. Вес, грузоподъёмность и пробеги представлены SearchString и сравниваются с stringValue чисел, а не SearchNumber-диапазонами. dateDepotRepair — SearchDate<Instant>; BETWEEN с одинаковыми start/end означает [start, start+1 день). Это не подтверждает локальный календарный день пользователя. Meta filter больше не наследует обычный RailwayCarriageFilter с его excludeUsedInActiveOrders; не следует считать эти контракты взаимозаменяемыми.

В c0724fd89 также изменены пять бинарных Excel-шаблонов warehouse. Код alias проверен, но содержимое впоследствии сверено в [отдельном отчёте](../traceability/excel-template-diff-2026-11-11.md); внешние формулы требуют runtime-проверки.

## ЕТСНГ в движениях КТК

`3b30f5466`: ContainerMovementMapper при UNLOAD_FINISH передаёт transportType в поиск ЕТСНГ. VEHICLE читает ReceivingOrderContainerItem по заявке и контейнеру; RAILWAY читает WaybillProduct через WC/WRC/Waybill по container.id. В ЖД-ветке текущий SQL-запрос не ограничен receivingOrder.id, не задаёт distinct и не проверяет excluded. `INFERENCE`: при истории одного КТК в нескольких накладных возможны чужие/повторные коды. Это требует отдельного теста; изменение источника не означает полную корректность scope.

## Проверки и открытые вопросы

Исходники RouteServiceIntegrationTest содержат копирование авто-рейса без заявок, InboundEventDatareonServiceTest — carriage arrived; это не доказывает отдельный тест новой даты/двойной проверки контейнеров. В просмотренных изменениях новых прямых тестов cargoWeight и detail count не добавлено. Все перечисленные runtime-сценарии остаются проверкой на стенде; найденные риски не объявляются воспроизведёнными дефектами.

## Источники

- [RouteService.java](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/route/RouteService.java)
- [CarriageArrivedAction.java](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/datareon/inbound/action/CarriageArrivedAction.java)
- [WaybillContainerDaoService.java](../../../db-layer/src/main/java/ru/korusconsulting/alis/model/waybillcontainer/WaybillContainerDaoService.java)
- [WaybillContainerRepository.java](../../../db-layer/src/main/java/ru/korusconsulting/alis/model/waybillcontainer/WaybillContainerRepository.java)
- [ShippingOrderContainer.java](../../../db-layer/src/main/java/ru/korusconsulting/alis/model/shippingordercontainer/ShippingOrderContainer.java)
- [Container.java](../../../db-layer/src/main/java/ru/korusconsulting/alis/model/container/Container.java)
- [ServiceOrderService.java](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/serviceorder/ServiceOrderService.java)
- [ServiceOrderContainerDaoService.java](../../../db-layer/src/main/java/ru/korusconsulting/alis/service/serviceordercontainer/ServiceOrderContainerDaoService.java)
- [ReceivingOrderPredicate.java](../../../db-layer/src/main/java/ru/korusconsulting/alis/predicate/receivingorder/ReceivingOrderPredicate.java)
- [ClientService.java](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/client/ClientService.java)
- [RailwayCarriageMetaViewPredicate.java](../../../db-layer/src/main/java/ru/korusconsulting/alis/predicate/railway/RailwayCarriageMetaViewPredicate.java)
- [ReceivingOrderContainerItemDaoService.java](../../../db-layer/src/main/java/ru/korusconsulting/alis/service/receivingordercontainer/ReceivingOrderContainerItemDaoService.java)
- [ContainerMovementMapper.java](../../../web-layer/src/main/java/ru/korusconsulting/alis/mapper/containermovement/ContainerMovementMapper.java)
- [RouteServiceIntegrationTest.java](../../../web-layer/src/integrationTest/java/ru/korusconsulting/alis/service/route/RouteServiceIntegrationTest.java)
- [InboundEventDatareonServiceTest.java](../../../web-layer/src/integrationTest/java/ru/korusconsulting/alis/service/datareon/inbound/InboundEventDatareonServiceTest.java)

## SearchDate: отдельный общий контракт

ddb4c596d обобщает SearchDate<T extends Temporal & Comparable<?>> для temporal-типов и переключает predicate на ComparableExpression. При неуказанном type: если end непустой — BETWEEN, иначе GREATER_THEN. Общий isNotEmpty проверяет start либо IS_NULL/IS_NOT_NULL; один end сам по себе не делает этот helper активным. Однако некоторые потребители имеют собственную проверку активности, учитывающую end, — см. ниже. Общий BETWEEN вызывает path.between(start,end), без автоматического расширения до конца календарного дня. JSON-форматы дат нужно читать по конкретному generic-полю.

Во всех затронутых ddb4c596d полях фильтров зафиксирован Instant; сам коммит не переводит их на LocalDate. Полная инвентаризация declarations parent→commit:

| Фильтр | SearchDate<Instant> поля |
|---|---|
| AdditionalAgreementFilter, TermOfServiceFilter | validFrom, validTo |
| ContractFilter | validFrom, validTo, contractDate |
| ClientDriverFilter | poaValidTo |
| ContainerMovementFilter | eventDateTime |
| MetaFieldFilter, OutboundDataFilter | date; lastAttemptAt соответственно |
| ReceivingOrderFilter | planDateTime (alias planReceivingDateTime), planReceivingDate, planReceivingTime |
| ShippingOrderFilter | planDateTime (alias plannedShippingDateTime), planShippingDate, planShippingTime |
| RouteClientOrderFilter | plannedDateTime, createdAt |
| RouteFilter | dateTime (alias dataTime) |
| ServiceOrderFilter | completionAt |
| ShippingOrderContainerFilter | dataTimeKrugloyePole |
| ShippingOrderRailwayCarriageFilter | dataTimeKrugloyePole, dateDepotRepair |
| WaybillFilter | waybillCreatedAt |
| WaybillRailwayCarriageFilter, ReceivingOrderWaybillCarriageFilter | dateDepotRepair |
| BaseEditableFilter / EditableFilter | createdAt, updatedAt / типы getter-ов |

Predicate-ветки Waybill, WaybillRailwayCarriage и ReceivingOrder сохраняют специальный BETWEEN с равными start/end как [start, start+1 день). Route, ShippingOrder, ShippingOrderContainer и ShippingOrderRailwayCarriage дополнительно допускают end-only/start-only BETWEEN, превращая их в <=end/>=start; их собственный isDateFilterPresent учитывает end. Это правила конкретных consumers, сохранённые при типизации, а не свойства общего SearchDate. byOr передаётся в общие helpers только там, где caller его использует; типизация сама не превращает все условия в OR.

Источники: [SearchDate](../../../wms-layer/src/main/java/ru/korusconsulting/wms/filter/base/searchtype/SearchDate.java), [SearchDateType](../../../wms-layer/src/main/java/ru/korusconsulting/wms/filter/base/searchtype/SearchDateType.java), [BaseIdentifierPredicate](../../../wms-layer/src/main/java/ru/korusconsulting/wms/predicate/BaseIdentifierPredicate.java), [RoutePredicate](../../../db-layer/src/main/java/ru/korusconsulting/alis/predicate/route/RoutePredicate.java), [ShippingOrderPredicate](../../../db-layer/src/main/java/ru/korusconsulting/alis/predicate/shippingorder/ShippingOrderPredicate.java).

## Meta views справочников (b42ab46f7)

container_meta_view содержит id КТК и container_type_iso=код ISO из LEFT JOIN. Только meta поля containerTypeISO переводится ContainerDaoService на эту view; остальные поля идут общим DAO-путём. ContainerMetaViewPredicate ограничивает id подзапросом исходных Container, переиспользуя ContainerPredicate. MetaContext в специальный view-запрос передаётся как NULL; нельзя автоматически переносить сюда generic scoped-meta поведение.

railway_carriage_meta_view содержит собственные поля вагона и строковые code модели/типа через LEFT JOIN. RailwayCarriageController meta принимает отдельный FilterWithPaging<RailwayCarriageMetaFilter>, создаёт вложенный фильтр при NULL и вызывает специальный сервис; page/list по-прежнему используют RailwayCarriageFilter. Числовые веса/пробеги в meta-фильтре представлены SearchString, дата — SearchDate<Instant>, noworkingParking — SearchBoolean. active есть во view, но не в этом meta-filter; volume/axlesCount/length также не являются его объявленными фильтрами. Не следует путать доступные поля view со всеми поддерживаемыми входными фильтрами.

Изменённый EntityInfoConsistencyTest исключает обе view из требований обычного entity-info. Это не проверка их фильтрации/HTTP/пагинации. Прямые runtime-проверки в аудите не выполнялись.

Источники: [ContainerMetaViewPredicate](../../../db-layer/src/main/java/ru/korusconsulting/alis/predicate/container/ContainerMetaViewPredicate.java), [RailwayCarriageMetaViewPredicate](../../../db-layer/src/main/java/ru/korusconsulting/alis/predicate/railway/RailwayCarriageMetaViewPredicate.java), [ContainerDaoService](../../../db-layer/src/main/java/ru/korusconsulting/alis/service/container/ContainerDaoService.java), [RailwayCarriageController](../../../web-layer/src/main/java/ru/korusconsulting/alis/controller/railway/RailwayCarriageController.java), [Container SQL](../../../db-layer/src/main/resources/db/changelog/rerunnable/view_container_meta.sql), [Railway SQL](../../../db-layer/src/main/resources/db/changelog/rerunnable/view_railway_carriage_meta.sql).

## Meta вывоза и веса container items (fade0b93e)

ShippingOrderController больше не добавляет fillingType=ALL к meta-запросу: переданный фильтр сохраняется, запрос без такого ограничения включает другие типы заполнения. Это не отключает остальные predicates и обогащение фильтра сервиса.

В ShippingOrderContainerItemPredicate поля grossWeight/netWeight фильтруют собственные item.wightGross/item.wightNet (точные имена entity). Ранее использовались вес родительской контейнерной строки и её вес минус тара физического КТК. Одновременно заданные wightGross/grossWeight или wightNet/netWeight добавляют отдельные AND-условия к одной колонке; это не автоматические JSON-алиасы. Сверены оба файла исходного diff и текущий код; runtime-запросы не выполнялись.

Источники: [ShippingOrderController](../../../web-layer/src/main/java/ru/korusconsulting/alis/controller/shippingorder/ShippingOrderController.java), [ShippingOrderContainerItemPredicate](../../../db-layer/src/main/java/ru/korusconsulting/alis/predicate/shippingordercontainer/ShippingOrderContainerItemPredicate.java).
