# Бизнес-правила заявки на вывоз

> **Сверено:** backend `3d3899d5d` (12.11.2026) · **Основание:** `SOURCE_CONFIRMED` — исходный код, миграции и тесты (тесты не запускались); БД и стенд не проверялись.

`ShippingOrder` специализирует транспортную заявку и наследует [общие типы](order-types.md) и [статусную модель](order-statuses.md).

## Контракты и модель

- Сущность: [ShippingOrder](../entities/catalog/entities/shippingorder/ShippingOrder.md)
- DTO: [create](../dto/shipping-order/ShippingOrderCreationDto.md), [update](../dto/shipping-order/ShippingOrderUpdateDto.md), [response](../dto/shipping-order/ShippingOrderDto.md), [карточка](../dto/shipping-order/ShippingOrderDetailedDto.md)
- БД: [таблицы заявок](../database/orders.md)
- Физическая целостность: [ER/integrity-карта таблиц вывоза](../database/shipping-order-integrity-map.md) — FK/UNIQUE/delete, plan/fact по `fillingType`, ETRAN membership, каскады, totals и route/outbound
- Копирование: [правила вывоза](order-copying.md#вывоз)
- Интеграции: [сообщения вывоза](order-integrations.md#вывоз)
- Входящее завершение вагонной задачи: [AS-IS порожнего ЖД-вывоза без КТК](shipping-railway-empty-completion.md)
- Остальные входящие результаты: [сравнение TOS, WMS, выезда и прямого завершения](shipping-inbound-actions.md)
- Ошибки: [каталог бизнес-ошибок](order-errors.md#только-вывоз)
- Обязательные поля и порядок проверок: [карта валидации вывоза](order-validation.md#вывоз-корневой-request)
- PDF-отчёты: [MX-3, ContainerTN, Packing List и общий availability AS-IS](order-pdf-reports-as-is.md)
- Excel-реестр: [корневые выгрузки V1/V2, фильтры и client scope](order-excel-exports-as-is.md)
- Дочерний Excel, часть 1: [blackbox, cargo, КТК и содержимое КТК V1/V2](shipping-order-child-excel-exports-as-is.md)
- Дочерний Excel, часть 2: [товары, услуги, связанные накладные ЭТРАН и вагоны V1/V2](shipping-order-child-excel-exports-part2-as-is.md)

## Создание и редактирование

`POST /shippingorder/` использует [ShippingOrderCreationDto](../dto/shipping-order/ShippingOrderCreationDto.md), `PUT /shippingorder/{id}` — [ShippingOrderUpdateDto](../dto/shipping-order/ShippingOrderUpdateDto.md). Update DTO наследует creation DTO и добавляет обязательный `id`. Полная таблица обязательности приведена в [карте валидации](order-validation.md#вывоз-корневой-request).

| ID | Правило |
|---|---|
| `BR-SO-002` | Новый объект получает `DRAFT`, серверные UUID и номер. |
| `BR-SO-003` | Проверяется сочетание площадки/транспорта/вида вывоза/типа заполнения (`OrderCombinationValidator`). |
| `BR-SO-004` | Для `CONTAINER + RAILWAY` отсутствующий `fillingType` нормализуется в `ALL`; `@PrePersist` также подставляет `ALL` при `null`. |
| `BR-SO-005` | Грузополучатель должен иметь роль `isConsignee=true` и принадлежать клиенту заявки; адрес берётся из `addressFact` грузополучателя. |
| `BR-SO-006` | После создания добавляются обязательные услуги договора (`SHIPMENT`) по тем же формулам, что у поставки. |
| `BR-SO-007` | Клиент, площадка, транспорт и номер являются неизменяемыми JPA-полями (`updatable=false`). `deliveryType`, `fillingType`, `needTransport` не меняются через update (сервис их не переносит). |
| `BR-SO-008` | При update меняются договор, валюта, контакт (только непустой), `plannedShippingDateTime`, комментарий и грузополучатель (`null` очищает его и адрес). Рейс назначается через `POST /routes/{id}/assign`. |

## Общая валидация review и accept

| Условие | Ошибка |
|---|---|
| Валюта задана | `ShippingOrder.MissingCurrency` |
| `plannedShippingDateTime` задана | `ShippingOrder.MissingPlannedShippingDateTime` |
| Для `CONTAINER` задан `consignee` | `ShippingOrder.MissingConsignee` |

## Матрица содержательной валидации

Accept (вызывается из accept рейса) не принимает `ShippingOrderCreationDto` или `ShippingOrderUpdateDto`: `ShippingOrderAcceptValidator` читает сохранённый агрегат. Конкретные DTO отдельных ресурсов — товаров, грузов, КТК, вагонов и ЭТРАН — перечислены в [карте DTO дочерних частей](order-validation.md#dto-дочерних-частей-агрегата).

Физический выбор между номерными строками и плановыми количествами, а также ограничения, которые не обеспечивает БД, сведены в [plan/fact-разделе ER/integrity-карты](../database/shipping-order-integrity-map.md#planfact-развилка-по-fillingtype). Бизнес-валидация ниже описывает требуемый состав для accept, но не означает автоматическую очистку строк другой модели.

| Площадка | Транспорт | Проверяемые части |
|---|---|---|
| `WAREHOUSE` | `VEHICLE` | рейс, товары, детальный груз, blackbox |
| `CONTAINER` | `VEHICLE` | рейс, контейнеры/quantity для `NONE_CONTAINER`, вес и items КТК |
| `CONTAINER` | `RAILWAY` | ЭТРАН, конкретные или количественные вагоны, вес и items КТК |

### Склад + автомобиль

- Заявка назначена в рейс (`route != null`), иначе `ShippingOrder.MissingTransport`.
- `BY_GOOD`: нужна хотя бы одна `ShippingOrderGood`.
- `BY_CARGO`: нужен `ShippingOrderBlackbox`, товарные строки не требуются.
- `BY_GOOD_WITH_CARGO_WITH_DETAILS`: нужны товары и `ShippingOrderCargo`.
- `plannedQuantity`, `price`, `totalPrice` товара должны быть > 0.
- Для детального груза нужна ссылка `cargo`; отрицательные количества отклоняются, но 0/`null` текущей реализацией допускаются.

### Контейнерная площадка + автомобиль

- Заявка назначена в рейс, иначе `ShippingOrder.MissingTransport`.
- Обычно требуется минимум один `ShippingOrderContainer`.
- Исключение `fillingType=NONE_CONTAINER`: должна быть ровно одна `ShippingOrderContainerQty` с `quantity=1`, `empty=true` и без связанных `ShippingOrderEtsngCode`.
- Для КТК с известным номером нужен вес > 0. Проверка MissingOwnerContainer у номерной строки удалена; текущее поле снимка называется containerOwner, SQL container_owner_id. Сервер читает Client из registry при add/смене КТК, входной owner mapper игнорирует. Это не отменяет проверку состояния регистра при reserve. Вес строки при add берётся из справочника КТК. [Точный контракт](shipping-container-owners-as-is.md).
- NONE_CONTAINER дополнительно требует ownerClient у qty и хотя бы один ON_TERMINAL КТК выбранного владельца с нужным типом. Количество с остатками не сравнивается, конкретный КТК этой проверкой не резервируется. Смешанные NULL ownerClient остаются отдельным риском.
- Порожний КТК не может иметь items, непорожний обязан иметь items.
- Проверка занятости КТК другой заявкой (feature flag) удалена 21.09.2026 (`9a05f552`, KIS-4661); наличие КТК в остатках проверяется при accept через `ContainerStatusService.reserveForShippingOrder`.
- При accept запрещён `ktkNumberUnknown=true`; review (не вызывается) его допускает.

### Контейнерная площадка + ЖД

- При `fillingType=ALL` нужна хотя бы одна `ShippingOrderEtranInvoice`.
- При `ALL`, `RAILWAY_CARRIAGE` (и прочих, кроме `CONTAINER`/`NONE`) нужны конкретные `ShippingOrderRailwayCarriage`.
- При `CONTAINER` или `NONE` нужны строки `ShippingOrderRailwayCarriageQty`.
- При `ALL` каждый конкретный вагон должен иметь `etranInvoice`, иначе `ShippingOrder.MissingRailwayCarriageEtranInvoice`.
- Контейнеры проверяются на вес и согласованность items (владелец не проверяется).
- Отдельная проверка наличия хотя бы одного конкретного КТК для ЖД в карте валидаторов не вызывается; допустимость заявки без КТК требует решения.

## Отклонение

`PUT /shippingorder/{id}/reject` (permission `SHIPPING_ORDER_REJECT`) переводит заявку в `REJECTED` и отменяет резерв КТК (`ContainerStatusService.cancelShippingOrder`); недопустимый переход — `ShippingOrder.RejectNotAllowed`. В отличие от поставки, действий с накладными нет. Тот же метод вызывается каскадом из `PUT /routes/{id}/reject`.

## Известные расхождения

1. ~~Сервис реализует accept, но HTTP endpoint не найден.~~ Accept выполняется через `POST /routes/{id}/change-status/accept`; review не вызывается.
2. `PUT /shippingorder/{id}` использует `body.id`; path ID методом не принимается.
3. ~~`ShippingOrderDto.documentConfirmed` без mapping.~~ Поля больше нет в `ShippingOrderDto`.
4. Swagger `allowableValues` для `fillingType` в `ShippingOrderDto` не содержит `NONE_CONTAINER`, хотя enum и логика его поддерживают.
5. Метод проверки `description` container item отсутствует в фактически вызываемом наборе валидаторов (константа `ShippingOrderContainerItem.MissingDescription` не используется).
6. `CARRIAGE_ARRIVED` завершает `ShippingOrderRailwayCarriage`, но не проверяет завершение всех вагонов и не переводит порожнюю ЖД-заявку без КТК в `DONE`; полный flow — в [отдельном AS-IS](shipping-railway-empty-completion.md).
7. `STATUS_COMPLETED` обходит общую матрицу переходов и переводит любую нетерминальную заявку, включая `DRAFT` и `ON_REVIEW`, прямо в `DONE`; дочерние задачи и владельцы КТК не проверяются. Сопоставление со специализированными TOS/WMS actions — в [карте входящих действий](shipping-inbound-actions.md).
8. Ранее описанный endpoint `POST /shipping-order/{id}/shipping-order-container-item/preview/meta/{fieldName}` (коммит `42eee4ee`) в `dev` отсутствует — этот коммит не входит в историю ветки.
