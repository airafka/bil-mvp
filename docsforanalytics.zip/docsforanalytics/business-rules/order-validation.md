# Валидация заявок и обязательность полей

> **Сверено:** backend `3d3899d5d` (12.11.2026) · **Основание:** `SOURCE_CONFIRMED` — исходный код, миграции и тесты (тесты не запускались); БД и стенд не проверялись.

Этот документ разделяет проверки HTTP-запроса и проверки сохранённого агрегата. Они выполняются в разные моменты и используют разные источники данных.

## Уровни валидации

| Уровень | Когда | Что проверяется | Источник правил |
|---|---|---|---|
| 0. UI (frontend) | В браузере до отправки запроса | Обязательность и формат полей формы, зависимости полей, доступность кнопок по статусу и праву | zod-схемы и конфиги форм; см. [UI-правила заявок](order-ui-rules-as-is.md) |
| 1. JSON binding | До входа в метод контроллера | Синтаксис JSON, UUID, ISO-8601 даты, имена enum | Jackson и типы полей request DTO |
| 2. Bean Validation | До входа в метод контроллера | `@NotNull`, `@PositiveOrZero`, вложенные объекты под `@Valid`, class-level `@AssertTrue` | Конкретный request DTO |
| 3. Создание/изменение модели | В сервисе create/update | Существование ссылочных записей, допустимость редактирования, сочетание площадки/транспорта/типов, нормализация | mapper, DAO, `OrderCombinationValidator`, сервис заявки |
| 4. Переход статуса | В начале review/accept/reject | Разрешён ли переход из текущего статуса | `OrderStatus.isStatusChangeAllowed` |
| 5. Review/accept | После проверки перехода, над сохранённым агрегатом | Полнота корня, транспорт (рейс), товары, грузы, КТК, вагоны и документы | `ReceivingOrderAcceptValidator` или `ShippingOrderAcceptValidator` |

Уровень 0 действует только для запросов из штатного UI и может быть как строже, так и мягче сервера — расхождения сведены в [реестр UI ↔ backend](order-ui-rules-as-is.md#реестр-расхождений-ui--backend). Ошибка на одном уровне не означает, что последующие уровни пройдены. Например, поле `currency` разрешено не передавать при создании `DRAFT`, но без валюты заявка не пройдёт accept.

## Как читать обязательность

- **В request** — поле обязано присутствовать уже в JSON из-за Bean Validation.
- **Условно в request** — поле проверяется только при заданной комбинации других полей.
- **Перед review/accept** — поле может отсутствовать в create/update, но должно быть заполнено в сохранённом агрегате к моменту перехода статуса.
- **Серверное** — клиент не задаёт итоговое значение; его генерирует или переопределяет сервер.
- **Игнорируется при update** — поле есть в DTO и проходит Bean Validation, но `prepareModelToUpdate` его не переносит в сохранённую модель.

`@NotNull` запрещает `null`, но для строки не запрещает `""`. `@NotBlank` запрещает `null`, пустую строку и строку из пробелов. В корневых DTO заявок используются преимущественно `@NotNull`.

## Поставка: корневой request

Конкретные контракты: [ReceivingOrderCreationDto](../dto/receiving-order/ReceivingOrderCreationDto.md) и [ReceivingOrderUpdateDto](../dto/receiving-order/ReceivingOrderUpdateDto.md); общие поля обоих запросов вынесены в [ReceivingOrderBaseDto](../dto/receiving-order/ReceivingOrderBaseDto.md). Изменяемые при update поля определяет `ReceivingOrderService.prepareModelToUpdate`.

| JSON-поле | Create | Update | Дополнительная бизнес-проверка |
|---|---:|---:|---|
| `id` | серверное | обязательно | Update ищет заявку по `body.id`; path-параметр контроллером не используется |
| `client` | обязательно | обязательно, игнорируется | После создания клиент не меняется |
| `contract` | обязательно | обязательно | При смене — разыменовывается через DAO |
| `terminalArea` (`IdDto`) | обязательно | обязательно, игнорируется | При create загружается по `id` (`TerminalAreaCatalogMapperHelper.fromId`); после создания не меняется |
| `transportType` | обязательно | обязательно, игнорируется | После создания не меняется |
| `orderStatus` | обязательно | обязательно, игнорируется | При create заменяется на `DRAFT` |
| `defaultContainerOwner` | нет | нет | Create: если не задан — подставляется `client`. Update: применяется только непустое значение |
| `storagePeriod` | нет | нет | Если задан, `>= 0`; при update перезаписывается (в т.ч. `null`) |
| `deliveryType` | условно | игнорируется | Обязателен для `WAREHOUSE + VEHICLE`; вне этой комбинации при create сбрасывается в `null`. Update не меняет вид поставки |
| `payerId` | условно | необязательно | На create обязательно для CONTAINER + RAILWAY. На update непустая отличающаяся ссылка загружается через PayerDaoService; NULL сохраняет прежнее значение |
| `departureStationId`, `destinationStationId` | условно | отсутствуют | На create обязательны вместе с payerId для CONTAINER + RAILWAY без env-переключателя; иначе ValidationException с текстом «payerId, departureStationId и destinationStationId обязательны …» |
| `currency` | нет | фактически обязательно | Обязательна перед accept; update при `currency=null` разыменовывает `updateModel.getCurrency().getId()` → NPE (HTTP 500) |
| `planReceivingDateTime` | нет | нет | Обязательна перед accept; при update перезаписывается |
| `shipper` | нет | нет | Обязателен перед accept при `terminalArea.code=CONTAINER` |
| `contact` | нет | нет | При update применяется только непустой объект |
| `comment`, `waybill` | нет | нет | При update перезаписываются |
| `needTransport` | нет | игнорируется | Задаётся только при create |
| `carrier` | нет | нет | Deprecated и игнорируется mapper-ом; использовать `shipper` |

departureStationId/destinationStationId принадлежат только create DTO; mapper update игнорирует станции. payerId также есть в update DTO и маппится в payer. Рейс (route) в корневых request DTO отсутствует и назначается через POST /routes/{id}/assign.

## Вывоз: корневой request

Конкретные контракты: [ShippingOrderCreationDto](../dto/shipping-order/ShippingOrderCreationDto.md) и [ShippingOrderUpdateDto](../dto/shipping-order/ShippingOrderUpdateDto.md). Update DTO наследует все поля creation DTO и добавляет `id`.

| JSON-поле | Create | Update | Дополнительная бизнес-проверка |
|---|---:|---:|---|
| `id` | серверное | обязательно | Update ищет заявку по `body.id`; path-параметр контроллером не используется |
| `client` | обязательно | обязательно, игнорируется | После создания клиент не меняется |
| `contract` | обязательно | обязательно | При смене — разыменовывается через DAO |
| `terminalArea` (`TerminalAreaCatalogDto`) | обязательно | обязательно, игнорируется | Mapper переносит `id`/`code`/`name` из запроса без загрузки из справочника; `OrderCombinationValidator` при create использует присланный `code` |
| `transportType` | обязательно | обязательно, игнорируется | После создания не меняется |
| `orderStatus` | обязательно | обязательно, игнорируется | При create заменяется на `DRAFT` |
| `deliveryType` | условно | игнорируется | Обязателен для `WAREHOUSE + VEHICLE`; вне этой комбинации при create сбрасывается в `null` |
| `fillingType` | нет | игнорируется | `NONE_CONTAINER` разрешён только для `CONTAINER + VEHICLE`; для `CONTAINER + RAILWAY` отсутствие нормализуется в `ALL`; default модели — `ALL` |
| `currency` | нет | фактически обязательно | Обязательна перед accept; update при `currency=null` → NPE (HTTP 500) |
| `plannedShippingDateTime` | нет | нет | Обязательна перед accept; при update перезаписывается |
| `consignee` | нет | нет | Обязателен перед accept для `CONTAINER`; при записи проверяются роль (`ShippingOrder.InvalidConsigneeRole`) и принадлежность клиенту заявки (`ShippingOrder.InvalidConsigneeClient`); `null` очищает грузополучателя и адрес |
| `consigneeAddress` | серверное | серверное | Значение из запроса не используется: подставляется `consignee.addressFact` (trim, пустое → `null`) |
| `contact` | нет | нет | При update применяется только непустой объект |
| `comment` | нет | нет | При update перезаписывается |
| `needTransport` | нет | игнорируется | Задаётся только при create |

С 24.09.2026 (`d30d77ad`, KIS-4093) сущности `ShippingOrderTransport`/`ReceivingOrderTransport` и таблицы `*_order_transport` удалены (миграция `v.1.34.0_20260718_KIS-4093_remove_order_transport.sql`); дублирующийся грузополучатель на транспорте больше не существует.

## Заявка на услугу: корневой request

Конкретные контракты: [ServiceOrderCreationDto](../dto/service-order/ServiceOrderCreationDto.md) и [ServiceOrderUpdateDto](../dto/service-order/ServiceOrderUpdateDto.md).

| JSON-поле | Create | Update | Дополнительная бизнес-проверка |
|---|---:|---:|---|
| `id` | серверное | обязательно | `PUT /service-order/{id}`: path `id` должен совпадать с `body.id`, иначе `IllegalArgumentException("Path id does not match DTO id")` |
| `client` | обязательно | отсутствует | После создания не меняется |
| `service` | обязательно | обязательно | Реализовано только значение `CHANGE_OWNER` |
| `comment` | нет | нет | Перезаписывается (в т.ч. `null`) |

Create устанавливает `status=DRAFT`. Update и delete разрешены только в `DRAFT`. Accept не имеет request body и проверяет минимум одну сохранённую связь с контейнером.

## Межполевая проверка create/update

После преобразования DTO в модель выполняется `OrderCombinationValidator` (create — `validateAndNormalize`, update — `validate` над сохранённой моделью):

1. Если `transportType=RAILWAY`, `terminalArea.code` должен быть `CONTAINER` (`*.InvalidTerminalAreaTransportType`).
2. Для `WAREHOUSE + VEHICLE` поле `deliveryType` обязательно (`*.MissingDeliveryType`).
3. Для вывоза `fillingType=NONE_CONTAINER` разрешён только при `CONTAINER + VEHICLE` (`ShippingOrder.InvalidFillingType`).
4. При create поставки/вывоза `deliveryType` вне `WAREHOUSE + VEHICLE` сбрасывается в `null`.
5. При create вывоза `CONTAINER + RAILWAY` и пустом `fillingType` устанавливается `ALL`.

Так как update не меняет площадку, транспорт, `deliveryType` и `fillingType`, проверка при update фактически повторно подтверждает уже сохранённую комбинацию. Код `WAREHOUSE_428` по-прежнему считается складом, хотя запись справочника удалена миграцией KIS-3543.

Обратная совместимость WAREHOUSE_428 ограничена OrderCombinationValidator: accept validators используют TerminalAreaEnum.valueOf, где этого значения нет. Нельзя считать такую подставленную площадку полноценным поддерживаемым вариантом accept. Для NUMBER/DATE/quantity проверок сохраняются отдельные NULL-риски: сравнение BigDecimal без guard или распаковка nullable Long может дать 500 раньше агрегированного ValidationException.

## Review и accept проверяют агрегат, а не request DTO

Публичных endpoints review/accept у заявок поставки и вывоза нет. Accept вызывается для каждой заявки рейса из `POST /routes/{id}/change-status/accept` (см. [статусную модель](order-statuses.md#допустимые-переходы-orderstatus)); метод `review` в production не вызывается. Сервис блокирует заявку (`findAndLock`), проверяет переход, запускает accept-валидатор и только после успеха резервирует КТК, меняет статус и формирует outbound-данные.

Порядок агрегатной проверки:

1. Только для поставки при accept сначала проверяются неопределённый тип вагона (`ReceivingOrder.UndefinedRailwayCarriageType`, для `RAILWAY` и `VEHICLE`) и неопределённый тип КТК (`ReceivingOrder.UndefinedContainerType`, только `CONTAINER` + `RAILWAY`/`VEHICLE`); каждая ошибка выбрасывается сразу, поэтому они не объединяются с остальными. При review обе предварительные проверки и ktkNumberUnknownCheck не вызываются. UNKNOWN типа КТК и модель вагона «Не определено» — разные понятия: модель этой проверкой не блокируется.
2. Собираются ошибки общих полей корня: валюта, плановая дата, `shipper`/`consignee` для контейнерной площадки.
3. По паре `terminalArea.code + transportType` выбирается набор валидаторов дочерних частей.
4. Только при accept для `CONTAINER + VEHICLE` проверяется `ktkNumberUnknown`.
5. Накопленные коды объединяются через `", "` и возвращаются одной `ValidationException`.

Полная матрица дочерних проверок находится в правилах [поставки](receiving-orders.md#матрица-содержательной-валидации) и [вывоза](shipping-orders.md#матрица-содержательной-валидации), а расшифровка кодов — в [каталоге ошибок](order-errors.md).

## DTO дочерних частей агрегата

Корневые create/update DTO не содержат товары, транспорт, КТК, вагоны и документы. Они сохраняются отдельными endpoints до accept. Ниже указаны конкретные request DTO, данные которых затем читает агрегатный валидатор.

| Часть агрегата | Поставка | Вывоз |
|---|---|---|
| Транспорт | Отдельного DTO нет (с KIS-4093, `d30d77ad`): транспорт — это рейс [`Route`](../entities/catalog/entities/route/Route.md), назначаемый через `POST /routes/{id}/assign`; проверка `ReceivingOrder.MissingTransport` = `route == null` | То же: `ShippingOrder.MissingTransport` = `route == null` |
| Товар | [`ReceivingOrderGoodCreationDto`](../dto/catalog/receivingordergood/ReceivingOrderGoodCreationDto.md), [`ReceivingOrderGoodUpdateDto`](../dto/catalog/receivingordergood/ReceivingOrderGoodUpdateDto.md) | [`ShippingOrderGoodCreationDto`](../dto/catalog/shippingordergood/ShippingOrderGoodCreationDto.md), [`ShippingOrderGoodUpdateDto`](../dto/catalog/shippingordergood/ShippingOrderGoodUpdateDto.md) |
| Детальное грузовое место | [`ReceivingOrderCargoCreationDto`](../dto/catalog/receivingordercargo/ReceivingOrderCargoCreationDto.md), [`ReceivingOrderCargoUpdateDto`](../dto/catalog/receivingordercargo/ReceivingOrderCargoUpdateDto.md) | [`ShippingOrderCargoCreationDto`](../dto/catalog/shippingordercargo/ShippingOrderCargoCreationDto.md), [`ShippingOrderCargoUpdateDto`](../dto/catalog/shippingordercargo/ShippingOrderCargoUpdateDto.md) |
| Blackbox | [`ReceivingOrderBlackboxCreationDto`](../dto/catalog/receivingorderblackbox/ReceivingOrderBlackboxCreationDto.md), [`ReceivingOrderBlackboxUpdateDto`](../dto/catalog/receivingorderblackbox/ReceivingOrderBlackboxUpdateDto.md) | [`ShippingOrderBlackboxCreationDto`](../dto/catalog/shippingorderblackbox/ShippingOrderBlackboxCreationDto.md), [`ShippingOrderBlackboxUpdateDto`](../dto/catalog/shippingorderblackbox/ShippingOrderBlackboxUpdateDto.md) |
| Контейнер | [`ReceivingOrderContainerCreationDto`](../dto/catalog/receivingordercontainer/ReceivingOrderContainerCreationDto.md), [`ReceivingOrderContainerUpdateDto`](../dto/catalog/receivingordercontainer/ReceivingOrderContainerUpdateDto.md) | [`ShippingOrderContainerCreationDto`](../dto/catalog/shippingordercontainer/ShippingOrderContainerCreationDto.md), [`ShippingOrderContainerUpdateDto`](../dto/catalog/shippingordercontainer/ShippingOrderContainerUpdateDto.md) |
| Содержимое контейнера | [`ReceivingOrderContainerItemCreationDto`](../dto/catalog/receivingordercontainer/ReceivingOrderContainerItemCreationDto.md), [`ReceivingOrderContainerItemUpdateDto`](../dto/catalog/receivingordercontainer/ReceivingOrderContainerItemUpdateDto.md) | [`ShippingOrderContainerItemCreationDto`](../dto/catalog/shippingordercontainer/ShippingOrderContainerItemCreationDto.md), [`ShippingOrderContainerItemUpdateDto`](../dto/catalog/shippingordercontainer/ShippingOrderContainerItemUpdateDto.md) |
| Безномерные контейнеры | — | [`ShippingOrderContainerQtyCreationDto`](../dto/catalog/shippingordercontainerqty/ShippingOrderContainerQtyCreationDto.md), [`ShippingOrderContainerQtyUpdateDto`](../dto/catalog/shippingordercontainerqty/ShippingOrderContainerQtyUpdateDto.md) |
| Конкретные вагоны | Через `WaybillRailwayCarriage` в агрегате накладной | [`ShippingOrderRailwayCarriageCreationDto`](../dto/catalog/shippingorderrailwaycarriage/ShippingOrderRailwayCarriageCreationDto.md), [`ShippingOrderRailwayCarriageUpdateDto`](../dto/catalog/shippingorderrailwaycarriage/ShippingOrderRailwayCarriageUpdateDto.md) |
| Безномерные вагоны | — | [`ShippingOrderRailwayCarriageQtyCreationDto`](../dto/catalog/shippingorderrailwaycarriageqty/ShippingOrderRailwayCarriageQtyCreationDto.md), [`ShippingOrderRailwayCarriageQtyUpdateDto`](../dto/catalog/shippingorderrailwaycarriageqty/ShippingOrderRailwayCarriageQtyUpdateDto.md) |
| ЭТРАН | Через `Waybill` в агрегате накладной | [`ShippingOrderEtranInvoiceCreationDto`](../dto/catalog/shippingorderetraninvoice/ShippingOrderEtranInvoiceCreationDto.md), [`ShippingOrderEtranInvoiceUpdateDto`](../dto/catalog/shippingorderetraninvoice/ShippingOrderEtranInvoiceUpdateDto.md) |

### Партия товарной строки (уровень 3)

С 13.10.2026 (`8ee1ab68`, KIS-4841) при add/update товарной строки поставки и вывоза (`ReceivingOrderGoodService`, `ShippingOrderGoodService`) сервис вызывает [`OrderGoodBatchValidator`](../../../web-layer/src/main/java/ru/korusconsulting/alis/dto/ordergood/validation/OrderGoodBatchValidator.java). «Учёт включён» = `ClientGood.batchAccountingType` равен `MANUFACTURE_DATE` или `EXPIRATION_DATE`. Правила проверяются по порядку, первая ошибка — `ValidationException` → HTTP 400:

| Условие | Код |
|---|---|
| `batchUnknown=true`, учёт не включён | `OrderGood.BatchUnknownNotAllowed` |
| `batchUnknown=true` и передана `batch` | `OrderGood.BatchUnknownWithBatch` |
| учёт включён, `batchUnknown=false`, `batch=null` | `OrderGood.MissingBatch` |

Accept партию не проверяет; строки, создаваемые WMS-результатом, валидатор не проходят. Принадлежность `batch` выбранному `ClientGood` валидатор не проверяет.

Для заявки на услугу контейнеры задаются отдельным [`ServiceOrderContainerSaveDto`](../dto/catalog/serviceordercontainer/ServiceOrderContainerSaveDto.md): `@AssertTrue` — должен быть указан хотя бы один из `id` или `containerOwnerId`. Accept затем требует, чтобы в БД была минимум одна связь `ServiceOrderContainer`.

Ссылки ведут в generated-паспорта с полями и Bean Validation. Для DTO без ручного паспорта бизнес-смысл следует подтверждать сервисной логикой; accept повторно проверяет только явно перечисленные бизнес-инварианты агрегата.

## Открытые вопросы

1. [АНАЛИТИК] Update поставки/вывоза с `currency=null` падает NPE (HTTP 500) вместо понятной ошибки валидации. Нужно ли сделать `currency` обязательной в update DTO или разрешить очистку?
2. [АНАЛИТИК] Update молча игнорирует `deliveryType`, `fillingType`, `needTransport`, `terminalArea`, `transportType`, `client`, хотя они обязательны/присутствуют в update DTO. Нужно ли явное сообщение об ошибке при попытке изменить их?
3. [АНАЛИТИК] Вывоз: `terminalArea.code` берётся из запроса без сверки со справочником по `id` — несоответствие `id`/`code` в запросе не обнаруживается.

## Уточнение целевой сверки 11.11.2026

У NONE_CONTAINER accept проверяет ownerClient и наличие ON_TERMINAL КТК нужного типа; количество с остатками не сравнивается этой проверкой. [Подробности и nullable-риск](shipping-container-owners-as-is.md).
