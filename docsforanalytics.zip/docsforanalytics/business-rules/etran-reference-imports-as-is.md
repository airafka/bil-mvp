# Справочники ЭТРАН: вагоны и КТК

> **Сверено:** backend `3d3899d5d` (13.11.2026) · **Основание:** `SOURCE_CONFIRMED` — исходный код, миграции и тесты (тесты не запускались); БД и стенд не проверялись.

Документ фиксирует **backend AS-IS** двух пакетных импортов: `POST /datareon/etran_railway` и `POST /datareon/etran_container`.

Импорт клиентских снимков остатков через `/datareon/container-remain` и `/datareon/railway-carriage-remain` является другим процессом и описан в [отдельном inbound AS-IS](remain-inbound-as-is.md).

Исторические материалы по вагонам (источник недоступен; [реестр](../research/unavailable-sources.md)) и по КТК (источник недоступен; [реестр](../research/unavailable-sources.md)) не содержат commit. Их описание Java-backend сверено здесь заново. Описанные в них скрипты 1С/Datareon, таблицы соответствий `sort`, вычисление `remaining_mileage`, замена кода контейнера и вычисление ISO отсутствуют в этом backend-репозитории и остаются **неподтверждённой внешней частью**, а не правилами ALIS.

## Общий контракт

Оба метода находятся в [DatareonController](../api/endpoints-generated.md#datareoncontroller), принимают `application/json`, при успехе возвращают `200` без тела и не имеют `@Secure`. Они входят в разрешённую Spring Security зону `/datareon/**`.

```mermaid
flowchart LR
    EXT[1С / Datareon<br/>внешняя граница] --> HTTP[POST /datareon/etran_*]
    HTTP --> BV[Jackson + Bean Validation]
    BV --> DUP[Последняя запись<br/>на точный code]
    DUP --> REF[Поиск по точному code и справочники:<br/>порядок зависит от endpoint]
    REF --> UPS{Найден?}
    UPS -->|нет| CREATE[Проверить обязательные для create поля; создать]
    UPS -->|да| UPDATE[Обновление по принципу patch:<br/>null/blank сохраняют прежнее]
    CREATE --> TX[Commit всего пакета]
    UPDATE --> TX
```

Общие свойства:

- `MessageID` обязателен как UUID, но используется только в warning о повторе кода **внутри одного пакета**;
- `MessageID` не сохраняется и не проверяется на повтор;
- одинаковый точный `code` внутри пакета схлопывается, побеждает последняя запись; порядок уникальных ключей соответствует первому появлению;
- пробелы и регистр не нормализуются;
- create/update выполняются последовательно в одной транзакции пакета; ошибка любого элемента откатывает все предыдущие изменения этого HTTP-вызова;
- с 03.09.2026 (`90f71f39` KIS-4665, `1c97f92d` KIS-4664) обновление работает как patch: `null` (для строк — blank) во входе сохраняет прежнее значение; `code` и `active` существующей записи не меняются (до этого update был полным, очищал optional-поля и ставил `active=true`);
- новая запись создаётся с `active=true`;
- row lock, optimistic `@Version` и DB-native upsert не используются.

## Импорт справочника вагонов

### HTTP и входной DTO

`POST /datareon/etran_railway` принимает [`EtranRailwayCarriageIntegrationDto`](../../../web-layer/src/main/java/ru/korusconsulting/alis/datareon/dto/railwaycarriage/EtranRailwayCarriageIntegrationDto.java). Корневой `@Valid` каскадирует на каждый элемент благодаря type-use `@Valid`; `null`-элементы отдельно запрещены `@NotNull`.

| JSON | Java-тип | Bean Validation | Семантика backend |
|---|---|---|---|
| `MessageID` | UUID | `@NotNull` | Только контекст warning; не idempotency key. |
| `etran_railway` | array | `@NotEmpty`; элементы `@NotNull @Valid` | Минимум один вагон. |
| `code` | String | `@NotBlank` | Номер вагона, точный ключ схлопывания и поиска. |
| `lifting_capacity` | BigDecimal | nullable | Обязателен только для create (`ValidationException` → `400`); при update `null` сохраняет прежнее. Знак не ограничен. |
| `type_id` | String | nullable | Код `RailwayCarriageType`, не UUID. Обязателен только для create; при update blank сохраняет прежний тип; неизвестный код → `404`. |
| `model` | String | nullable | Код модели: при отсутствии в справочнике `RailwayCarriageModel` **создаётся** (`findOrCreateByCode`); blank/`null` сохраняет прежнюю модель (при create — без модели). |
| `date_depot_repair` | Instant | nullable | Требует Jackson-совместимый instant; `null` сохраняет прежнее. |
| `sort`, `owner`, `proxy_operator` | String | nullable | Сохраняются как есть; blank при update сохраняет прежнее значение. |
| `volume`, `weight`, `length`, `mileage_rate`, `mileage`, `remaining_mileage` | BigDecimal | nullable, знак не ограничен | Сохраняются без вычисления и смены единиц; `null` сохраняет прежнее. |
| `axles_count` | Integer | nullable | `null` сохраняет прежнее. |
| `noworking_parking` | Boolean | nullable | `null` сохраняет прежнее. |

В текущих JPA-комментариях [RailwayCarriage](../entities/catalog/entities/railway/RailwayCarriage.md) грузоподъёмность и тара обозначены в килограммах, пробеги — в километрах (изменено 90f71f397). Endpoint сохраняет переданные числа без пересчёта. Это указание единиц в исходнике, а не подтверждение единиц фактического внешнего payload.

### Серверный алгоритм

```mermaid
flowchart TD
    A[Валидный railway package] --> M[LinkedHashMap code → last DTO]
    M --> N[Следующий уникальный вагон]
    N --> F[find RailwayCarriage by exact code]
    F --> U{Вагон найден?}
    U -->|нет| R{type_id и lifting_capacity заданы?}
    R -->|нет| E400[ValidationException → 400; rollback]
    R -->|да| C[Тип по коду; модель find-or-create;<br/>контрольная цифра; create]
    U -->|да| E[Patch: непустые поля из входа,<br/>прочие — прежние; code/active не меняются]
    C --> MORE{Есть ещё?}
    E --> MORE
    MORE -->|да| N
    MORE -->|нет| COMMIT[Commit]
```

На каждый уникальный элемент выполняются отдельные поиски вагона, типа (если `type_id` не blank) и модели (если `model` не blank). Пакетного чтения нет.

Тип ищется точным регистрозависимым `code`; отсутствующий тип даёт `NotFoundException` (`404`). Модель ищется так же, но неизвестная модель **создаётся** активной строкой `RailwayCarriageModel` в той же транзакции — опечатка в коде модели порождает новую запись справочника. Миграция KIS-4665 идемпотентно добавляет модель `Не определено`. Только при **создании** `RailwayCarriageService.preAdd` проверяет, что номер состоит из восьми цифр и имеет корректную контрольную цифру.

Mapper формирует [RailwayCarriageCreationDto](../dto/catalog/railway/RailwayCarriageCreationDto.md) (`active=true`) или [RailwayCarriageUpdateDto](../dto/catalog/railway/RailwayCarriageUpdateDto.md), в который для каждого поля подставляет входное значение, а при `null`/blank — значение существующего вагона; `code` и `active` всегда берутся из существующей записи. Очистить поле через этот импорт невозможно.

Предварительный `findByCode` точный и регистрозависимый. Проверка уникальности при create использует `EXACTLY_MATCHES_IGNORE_CASE`, а физический unique constraint БД — обычный регистрозависимый `UNIQUE(code)`. Поэтому пакет с вариантом регистра существующего номера идёт в ветку create, но штатно отклоняется прикладной проверкой как дубликат.

## Импорт справочника КТК

### HTTP и входной DTO

`POST /datareon/etran_container` принимает [`EtranContainerIntegrationDto`](../../../web-layer/src/main/java/ru/korusconsulting/alis/datareon/dto/container/EtranContainerIntegrationDto.java). `@Valid` стоит на списке, но у generic-элемента нет `@NotNull`: вложенные поля непустого элемента проверяются, а literal `null` проходит Bean Validation и позже приводит к runtime `500` при чтении `getCode()`. С 03.09.2026 (`1c97f92d`, KIS-4664) `@NotBlank`/`@NotNull` с `container_type`, `weight`, `ISO`, `lifting_capacity` сняты: они обязательны только для create.

| JSON | Java-тип | Bean Validation | Семантика backend |
|---|---|---|---|
| `MessageID` | UUID | `@NotNull` | Только warning; не idempotency key. |
| `etran_container` | array | `@NotEmpty @Valid` | Минимум один элемент; сам элемент `null` явно не запрещён. |
| `code` | String | `@NotBlank` | Номер КТК, точный ключ схлопывания и поиска. |
| `container_type` | String | nullable | Точное enum-имя либо точное русское `tosType`. Обязателен для create; при update blank сохраняет прежний тип. |
| `weight` | BigDecimal | `@Positive` при наличии | Масса тары, без преобразования. Обязателен для create; `null` при update сохраняет прежнее. |
| `lifting_capacity` | BigDecimal | `@Positive` при наличии | Грузоподъёмность, без преобразования. Обязателен для create. |
| `ISO` | Long | `@Positive` при наличии | Identifier строки `ContainerTypeISO`, не её UUID/код. Обязателен для create; `null` при update сохраняет прежний ISO. |
| `height`, `length` | BigDecimal | `@Positive` при наличии | Без преобразования; `null` сохраняет прежнее. |
| `owner`, `owner_name`, `renter`, `renter_name` | String | nullable | Справочные реквизиты; blank при update сохраняет прежнее значение. |

JPA-комментарии [Container](../entities/catalog/entities/container/Container.md) называют `weight` и `liftingCapacity` тоннами, но endpoint не умножает и не делит значения. Известные внешние преобразования `×1000`, length/height и ISO относятся к Datareon-документу, а не к Java-сервису; единицы фактического входного payload требуют внешнего подтверждения.

`container_type` принимает без нормализации одно из enum-имён `REFRIGERATOR_20`, `REFRIGERATOR_40`, `STANDARD_20`, `STANDARD_40`, `TANK_20`, `TANK_40`, `UNKNOWN` либо соответствующий точный русский текст `Рефрижератор 20/40`, `Стандартный 20/40`, `Танк 20/40`, `Не определен`. Другое значение даёт `IllegalArgumentException` (`500`). Значение `UNKNOWN` и DB CHECK `chk_container_container_type` добавлены KIS-4664.

### Серверный алгоритм

```mermaid
flowchart TD
    A[Валидный container package] --> M[LinkedHashMap code → last DTO]
    M --> ISOS[Собрать уникальные ISO]
    ISOS --> IR[Одним запросом найти все переданные ISO]
    IR --> OK{Все ISO найдены?}
    OK -->|нет| E500[EntityNotFoundException; rollback]
    OK -->|да| CR[Одним exact code IN запросом найти Container]
    CR --> N[Следующий DTO]
    N --> CT[Преобразовать container_type]
    CT --> U{Container exact-code найден?}
    U -->|нет| C[Проверить обязательные поля, номер/unique; create]
    U -->|да| UP[Patch: непустые поля из входа]
    C --> MORE{Есть ещё?}
    UP --> MORE
    MORE -->|да| N
    MORE -->|нет| COMMIT[Commit]
```

Справочник `container_type_iso` (по непустым ISO) и существующие контейнеры читаются по одному пакетному запросу до изменений. Если хотя бы один переданный ISO отсутствует, `ContainerTypeISOService` бросает `EntityNotFoundException` и ни один контейнер не меняется.

Mapper формирует [ContainerCreationDto](../dto/catalog/container/ContainerCreationDto.md) с `active=true`, `refrigerator=false` (даже для `REFRIGERATOR_20/40`), без `standardSize` и с `containerTypeISO` найденной строки. Для update формируется [ContainerUpdateDto](../dto/catalog/container/ContainerUpdateDto.md), где `code`, `active`, `refrigerator` и `standardSize` берутся из существующего [Container](../entities/catalog/entities/container/Container.md), а остальные поля — из входа при непустом значении, иначе прежние. До 03.09.2026 update принудительно ставил `active=true`, `refrigerator=false`, `standardSize=null` и очищал непереданные реквизиты.

Только ветка create вызывает проверку 11-символьного контейнерного номера и контрольной цифры. Латинские буквы допускаются в любом регистре. Из-за реализации validator неизвестный символ среди первых четырёх позиций может привести к `NullPointerException`, а не к ожидаемому `ValidationException`.

Как и для вагонов, предварительный пакетный поиск точный и регистрозависимый, прикладная uniqueness-проверка create — без учёта регистра, DB `UNIQUE(code)` — регистрозависимый.

## Повторная загрузка и конкурентность

| Ситуация | Вагон | КТК |
|---|---|---|
| Повтор того же `MessageID` | Полный новый upsert | Полный новый upsert |
| Точный дубль code в одном пакете | Последний DTO | Последний DTO |
| Отличие регистра/пробелов | Другой map key и exact lookup | Другой map key и exact lookup |
| Объект уже существует | Patch-update; `null`/blank сохраняют прежнее | Patch-update; `active`/`refrigerator`/`standardSize` не меняются |
| Два параллельных первых пакета | Оба могут не найти строку; конфликт на проверке/DB unique | То же |
| Ошибка позднего элемента | Rollback всего пакета | Rollback всего пакета |

Ни один сервис не блокирует строку при update. Параллельные обновления одного объекта имеют поведение last-commit-wins по всему набору полей. Предварительная проверка уникальности не заменяет constraint и не делает create атомарным.

Эти импорты изменяют глобальные справочные [RailwayCarriage](../entities/catalog/entities/railway/RailwayCarriage.md) и [Container](../entities/catalog/entities/container/Container.md), на которые уже могут ссылаться Waybill, заявки и остатки. Проверок статуса связанных заявок или занятости объекта нет. Отличие от [импорта Waybill](waybill-etran-as-is.md): специализированные endpoints используют общие `RailwayCarriageService`/`ContainerService`, но также выполняют справочный patch-update; они не являются lookup-only.

## Ошибки HTTP

| Условие | Исключение AS-IS | HTTP |
|---|---|---:|
| Некорректный JSON/UUID/Instant/число, пустой пакет, нарушение `@Not*`/`@Positive` | Jackson или Bean Validation | `400` |
| Create без обязательных полей (`type_id`/`lifting_capacity` для вагона; `container_type`/`weight`/`ISO`/`lifting_capacity` для КТК) | `ValidationException` | `400` |
| Невалидный новый номер вагона/большинство невалидных номеров КТК | `ValidationException` | `400` |
| Не найден тип вагона | `NotFoundException` | `404` |
| Unknown `container_type` | `IllegalArgumentException` | `500` |
| ISO отсутствует в `ContainerTypeISO` | `EntityNotFoundException` | `500` |
| `null`-элемент container list либо неизвестная буква/символ в префиксе нового code | `NullPointerException` | `500` |
| Прикладной duplicate | `DuplicateEntityException` | `409` |
| DB duplicate (`23505`) и иная `DataIntegrityViolationException` | — | `500` (с 16.09.2026, `d24879c6`; раньше `23505` → `409`) |
| Иная DB integrity/runtime error | catch-all | `500` |

OpenAPI обоих методов заявляет только `200` и `400` без content/schema. Фактические `404`, `409` и `500` в декларативном контракте не отражены. Формат ответа задаёт общий [ExceptionAdvice](../../../web-layer/src/main/java/ru/korusconsulting/alis/exception/ExceptionAdvice.java).

## Физические ограничения и seed

- `container.code` имеет `UNIQUE`; колонка обязательна через базовую исходную миграцию.
- `railway_carriage.code` после удаления `client_id` имеет `UNIQUE`; type и lifting capacity обязательны в исходной таблице.
- `container_type_iso.identifier` имеет `NOT NULL UNIQUE`, `code` — `NOT NULL`; миграция seed создаёт identifiers `1–6`, `8`, `10`, `12`, `18`, `20`, `50–52`, `54–56`, `66`, `67`, `69`, `70`, `72`, `73`, `80`, `81`.
- Миграция вагонов создаёт тип `Не определено`, переводит на него три старых неопределённых типа и удаляет их.
- Числовые колонки обычно `NUMERIC(15,3)`; container lifting capacity создана как `NUMERIC(15,6)`. Входной DTO не задаёт `@Digits`, поэтому переполнение precision/scale проявится на БД и откатит пакет.

Применённая схема среды не проверялась. Источники: [container ISO migration](../../../db-layer/src/main/resources/db/changelog/v.1.35.0/v.1.35.0_20260727_KIS-4432_edit_container_table_and_create_container_iso_dictionary.sql), [railway fields/type migration](../../../db-layer/src/main/resources/db/changelog/v.1.35.0/v.1.35.0_20260729_KIS-4321_edit_railway_carriage_table.sql), [container unique](../../../db-layer/src/main/resources/db/changelog/v.1.0.0/v1.0.0_20250213_KIS-151_drop_column_client_id_and_make_code_unique_in_table_container.sql) и [railway unique](../../../db-layer/src/main/resources/db/changelog/v.1.33.0/v.1.33.0_20260306_KIS-3234_remove_client_id_from_railway_carriage.sql).

## Влияющие commits

| Commit | Изменение |
|---|---|
| `0fed0cd23a15e23fd331899336afc3cc103556df`, 06.08.2026, `KIS-4432 add datareon integration for container dictionary` | Добавил container endpoint/DTO/service/mapper, ISO-справочник, поля Container и миграцию seed. |
| `1e46c564852d88d4bb13acb579a20479b4350e97`, 06.08.2026, `KIS-4321 Railway carriage datareon synchronization` | Добавил railway endpoint/DTO/service/mapper, новые поля вагона, тип `Не определено` и проверки update-полей. |
| `b133cd12098021e4414db148d9da429f7b8c5d7c`, 12.08.2026, `KIS-4432 remove redundant etranType mapper for container type` | Перевёл container mapper на общий `ContainerType.fromTosType`: принимаются enum-name и точный русский `tosType`. |
| `cd8ab54287495f1d40cc1e6b1acef831712c0252`, 20.08.2026, `KIS-4365 add scoped meta support for nested shipping order fields` | Перенёс/адаптировал DTO и сервисы в текущую структуру; основной смысл commit шире этих интеграций. |
| `90f71f39`, 03.09.2026, `KIS-4665 add unknown railway carriage model and update railway carriage sync` | Patch-update вагона, `type_id`/`lifting_capacity` обязательны только для create, find-or-create модели, seed модели `Не определено`. |
| `1c97f92d`, 03.09.2026, `KIS-4664 add unknown container type and update container sync` | Patch-update КТК, обязательные поля только для create, `ContainerType.UNKNOWN` и DB CHECK типа. |

## Тестовая трассировка

### Дополнительная сверка 11.11.2026

90f71f397/1c97f92df сверены также вне справочных endpoints: WaybillDatareonService не обновляет существующий физический вагон/КТК и возвращает его до разрешения модели/типа/ISO из входа. Для нового вагона больше нет умножения грузоподъёмности на 1000 и тары на 100; для нового КТК нет прежнего умножения грузоподъёмности на 1000. Эти ветки не следует смешивать с patch-update отдельных справочных endpoints.

Seed модели «Не определено» не является автоматическим fallback при пустой model: helper возвращает NULL. Accept поставки проверяет неопределённый **тип**, а не эту модель. В новом ContainerType CHECK допускается UNKNOWN; CHECK сам по себе не запрещает SQL NULL.

Новый unit test 1c97f92df задаёт UNKNOWN для авто/ЖД-поставки и ожидает ReceivingOrder.UndefinedContainerType; связанные integration fixtures переведены на STANDARD_20, вызовы — на validateForAccept. Эти тесты не подтверждают HTTP импорт ЭТРАН и в аудите не запускались.

Отдельных unit/integration/controller tests для `EtranRailwayCarriageDatareonService`, `EtranContainerDatareonService`, `/etran_railway` или `/etran_container` в найденном test tree нет.

Связанные проверки покрывают только части цепочки:

- [RailwayCarriageServiceTest](../../../web-layer/src/test/java/ru/korusconsulting/alis/service/railway/RailwayCarriageServiceTest.java) подтверждает, что сервис копирует все синхронизируемые поля update DTO (patch-семантику обеспечивает mapper, тестом не покрыт);
- [RailwayCarriageValidatorUtilTest](../../../web-layer/src/test/java/ru/korusconsulting/alis/utils/RailwayCarriageValidatorUtilTest.java) проверяет алгоритм номера вагона;
- [ContainerValidatorUtilTest](../../../web-layer/src/test/java/ru/korusconsulting/alis/utils/ContainerValidatorUtilTest.java) проверяет примеры контрольной цифры КТК.

Не покрыты endpoint validation, last-duplicate-wins, packet rollback, lookup type/model/ISO, find-or-create модели, create/update выбор, case mismatch, patch-семантика update, повтор `MessageID`, конкурентность и фактические HTTP errors. Найденные тесты не запускались.

Основные Java-источники: [railway service](../../../web-layer/src/main/java/ru/korusconsulting/alis/datareon/service/railwaycarriage/EtranRailwayCarriageDatareonService.java), [railway mapper](../../../web-layer/src/main/java/ru/korusconsulting/alis/datareon/mapper/railwaycarriage/EtranRailwayCarriageMapper.java), [container service](../../../web-layer/src/main/java/ru/korusconsulting/alis/datareon/service/container/EtranContainerDatareonService.java), [container mapper](../../../web-layer/src/main/java/ru/korusconsulting/alis/datareon/mapper/container/EtranContainerMapper.java), [RailwayCarriageService](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/railway/RailwayCarriageService.java), [ContainerService](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/container/ContainerService.java) и [ContainerTypeISOService](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/containertypeiso/ContainerTypeISOService.java).
