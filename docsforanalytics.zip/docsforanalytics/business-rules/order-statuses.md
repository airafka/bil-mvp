# Статусная модель заявок

> **Сверено:** backend `3d3899d5d` (12.11.2026) · **Основание:** `SOURCE_CONFIRMED` — исходный код, миграции и тесты (тесты не запускались); БД и стенд не проверялись.

## Общие правила транспортной заявки

Применяются к [ReceivingOrder](receiving-orders.md) и [ShippingOrder](shipping-orders.md). Источник: `OrderStatus` (`db-layer/.../model/orderstatus/OrderStatus.java`), `OrderServiceUtils`, `ReceivingOrderService`, `ShippingOrderService`, `RouteService`.

| ID | Правило |
|---|---|
| `BR-ORDER-010` | При создании сервер всегда устанавливает `DRAFT` (`OrderStatus.DEFAULT`), независимо от `orderStatus` в request DTO. |
| `BR-ORDER-011` | Переход в тот же статус допустим в enum (`isStatusChangeAllowed(x, x) = true`), но не гарантирует успешный accept. Повтор вызывает validator/reserve заново: уже EXPECTED/RESERVED_OUT КТК блокируют резервирование. При пустом наборе физических КТК эта защита не срабатывает, и повторная очередь возможна — см. вопрос 4. |
| `BR-ORDER-012` | Операции review/accept/reject блокируют строку заявки через `findAndLock`. |
| `BR-ORDER-013` | Редактирование заявки и её дочерних частей разрешено в `DRAFT`; в `ON_REVIEW` — только с permission `RECEIVING_ORDER_SEND_TO_ACCEPT` (для обеих сторон); в остальных статусах — `AccessDeniedException` «Order can't be updated in status …». |
| `BR-ORDER-014` | Изменение orderStatus через DAO публикует ReceivingOrderStatusChangedEvent/ShippingOrderStatusChangedEvent. BEFORE_COMMIT listener при наличии рейса вызывает syncRouteStatus: sendToIntegration=false для REJECTED, true иначе. Только ошибки route sync перехватываются. ReceivingOrderListener до route-null guard и вне catch пересчитывает категории Waybill; эта ошибка способна сорвать commit. Отдельный AFTER_COMMIT notification listener описан в интеграциях. |

## Допустимые переходы `OrderStatus`

| Из | В | Кто реально инициирует |
|---|---|---|
| `DRAFT` | `ON_REVIEW` | Метод `review` есть, но production-вызова нет: `RouteService.updateOrderStatuses` вызывает его только для статуса рейса `ON_REVIEW`, а `changeStatus` обрабатывает лишь `DRAFT`/`ACCEPTED`, и endpoint есть только `/routes/{id}/change-status/accept`. |
| `DRAFT` | `ACCEPTED` | `POST /routes/{id}/change-status/accept` (permission `ROUTE_SEND_ACCEPT`): `RouteService.changeStatus` вызывает `accept` для каждой заявки рейса. |
| `DRAFT` | `REJECTED` | `PUT /receivingorder/{id}/reject`, `PUT /shippingorder/{id}/reject`, каскад `PUT /routes/{id}/reject` |
| `ON_REVIEW` | `ACCEPTED` | Accept рейса (если заявка оказалась в `ON_REVIEW`) |
| `ON_REVIEW` | `REJECTED` | Reject заявки или рейса |
| `ACCEPTED` | `DRAFT` | Разрешено enum-моделью; вызывающий сценарий в коде не найден |
| `ACCEPTED` | `IN_PROGRESS` | Входящее событие TOS/WMS (`STATUS_IN_WORK` и др.) |
| `ACCEPTED` | `DONE` | Входящее событие (`STATUS_COMPLETED` и др.) |
| `ACCEPTED` | `REJECTED` | Reject заявки или рейса |
| `IN_PROGRESS` | `DONE` | Завершение обработки (входящее событие) |
| `IN_PROGRESS` | `REJECTED` | Reject заявки или рейса |
| `DONE` | `REJECTED` | Поздняя отмена, разрешена моделью |

**Пользовательский путь.** С KIS-4735 карточки поставки и вывоза не отправляют заявку на review; заявки рейса переводятся `DRAFT → ACCEPTED` кнопкой рейса `POST /routes/{id}/change-status/accept` — см. [`UI-ORDER-003`](order-ui-rules-as-is.md#общие-правила). Ошибки accept отдельных заявок собираются в одну `ValidationException` вида `Route.OrderService.Accept.<номер заявки>.<сообщение>`; при любой ошибке транзакция рейса откатывается. Рейс без заявок → `Route.IsEmpty`.

`REJECTED` терминален. Для проверки занятости остатков активны `ON_REVIEW`, `ACCEPTED`, `IN_PROGRESS` (`ACTIVE_STATUSES_FOR_REMAINS`). Для переходов от TOS допустимыми исходными статусами считаются `ACCEPTED`, `IN_PROGRESS` (`CORRECT_STATUS_FOR_TOS_TRANSITION`).

Для порожнего ЖД-вывоза действие `CARRIAGE_ARRIVED` реализует только переход заявки в `IN_PROGRESS` и завершение вагонной задачи. Переход заявки в `DONE` после последнего вагона отсутствует; см. [сквозной AS-IS и подтверждённый дефект](shipping-railway-empty-completion.md).

`STATUS_IN_WORK` и `STATUS_COMPLETED` (`BaseChangeStatusResultAction`) являются исключениями из таблицы допустимых переходов: не вызывают `OrderStatus.isStatusChangeAllowed` и заменяют любой статус, кроме `DONE`/`REJECTED`, соответственно на `IN_PROGRESS` или `DONE`. Статусы дочерних задач не проверяются; повтор после `DONE` завершается ошибкой action (подходящая заявка не найдена). См. сравнение действий [вывоза](shipping-inbound-actions.md) и [поставки](receiving-inbound-actions.md).

## Review и accept

Эти операции не принимают DTO с полями заявки: они читают уже сохранённый агрегат. Последовательность и различие между Bean Validation request DTO и агрегатной проверкой описаны в [карте валидации](order-validation.md#review-и-accept-проверяют-агрегат-а-не-request-dto). Review сейчас не вызывается (см. выше) — столбец «Review» описывает код метода.

| Проверка | Review | Accept |
|---|---:|---:|
| Допустимость перехода | да | да |
| Общие обязательные поля (`currency`, плановая дата, `shipper`/`consignee` для `CONTAINER`) | да | да |
| Проверки по матрице площадка × транспорт | да | да |
| Содержимое агрегата | да | да |
| Запрет `ktkNumberUnknown` | нет | да, только `CONTAINER + VEHICLE` |
| Неопределённый тип вагона / КТК поставки (`UNDEFINED`/`UNKNOWN`) | нет | да, только поставка |
| Резервирование КТК (`ContainerStatusService.reserveFor*Order`) | нет | да |
| Исходящая интеграция заявки | нет | да, если не включён route chain package (см. [интеграции](order-integrations.md)) |

Reject: `ContainerStatusService.cancel*Order(order, previousStatus)`, статус `REJECTED`; для исходных `IN_PROGRESS`/`DONE` дополнительно проверяется соответствующее `RejectAfterStart/DELETE`. Только из `ACCEPTED` на `CONTAINER` сохраняется outbound-пакет отмены; повторный reject уже отклонённой заявки возвращает её без нового пакета. См. [полный контракт отмены](../integrations/order-cancellation-outbound-as-is.md). У поставки дополнительно обнуляются связи ЖД-накладных с заявкой (`waybillDaoService.updateReceivingOrderLinks(id, [])`). Ошибка недопустимого перехода: поставка — `ReceivingOrder.InvalidStatus`, вывоз — `ShippingOrder.RejectNotAllowed`.

## Сервисная заявка

`ServiceOrderStatus` не наследует `OrderStatus`.

```mermaid
flowchart LR
    A[Создание] --> B[DRAFT]
    B -->|update состава| B
    B -->|accept: есть хотя бы один контейнер| C[DONE]
    B -->|delete| D[Заявка удалена]
```

- В `DRAFT` разрешены update и delete (`checkServiceOrderStatusForModification`); delete удаляет и строки `ServiceOrderContainer`.
- Accept из не-`DRAFT` → `IllegalStateException`; без `ServiceOrderContainer` → `ValidationException("Service order must contain at least one container")`.
- При accept меняются владельцы КТК, устанавливаются `DONE` и `completionAt=now`, пишется `outbound_data` (`SERVICE_ORDER_CHAIN_PACKAGE`).
- Возврат из `DONE` кодом не предусмотрен.

## Вопросы для будущего проектирования

1. ~~Где находится внешний API/consumer для `ReceivingOrderService.accept` и `ShippingOrderService.accept`?~~ **Закрыто кодом**: accept вызывается из `RouteService.changeStatus` (`POST /routes/{id}/change-status/accept`). Мёртвым остаётся `review` (переход в `ON_REVIEW` недостижим) — нужно решение, удалять ли `ON_REVIEW` из модели.
2. Нужен ли реально переход `ACCEPTED → DRAFT`? Для `DONE → REJECTED` найден реализованный сценарий поздней отмены с `RejectAfterStart/DELETE`; необходимость сообщения TOS для него остаётся открытым вопросом.
3. ~~`OrderServiceUtils` проверяет permission `RECEIVING_ORDER_SEND_TO_ACCEPT` и для вывоза.~~ **Подтверждён дефект/решение не принято**: `OrderServiceUtils.checkOrderStatusForUpdate` жёстко проверяет `Permission.RECEIVING_ORDER_SEND_TO_ACCEPT`; вызывается из `ReceivingOrderService`, `ShippingOrderService` и дочерних сервисов обеих сторон (`*Good`, `*Cargo`, `*Blackbox`, `*RequestedService`, `*ContainerItem`, `ReceivingOrderContainerService`, `ShippingOrderEtranInvoice`, `ShippingOrderEtsngCode`, `ShippingOrderContainerQty`, `ShippingOrderRailwayCarriage(Qty)`, `Waybill`, `WaybillContainer`). Подробности — [физическая модель транспорта вывоза](../database/shipping-order-transport-as-is.md#проверка-статуса-при-update-разделяемая-и-потенциально-неточная-проверка). Практически значимо только при появлении `ON_REVIEW`.
4. [АНАЛИТИК] Повторный accept рейса заново вызывает accept заявок. Для уже зарезервированных физических КТК reserve отвергает операцию; при отсутствии физических КТК (например, складской состав или безномерные строки) повтор может дойти до нового outbound заявки/рейса. Общей идемпотентности endpoint нет. Требуются отдельные сценарии для обоих составов; повторная отправка не является безусловным результатом каждого accept.

## Контроль публичного списка статусов 11.11.2026

OrderStatusController POST /orderstatus/all явно исключает ON_REVIEW из OrderStatus.values. Статус остаётся в enum/переходах и совместимых проверках, но это не означает доступную review-команду. RouteController публикует change-status/accept, review mapping удалён. Исправлена противоречащая строка таблицы route-lifecycle, где исторический endpoint ещё был показан как текущий.
