# Типы и классификация заявок

> **Сверено:** backend `3d3899d5d` (12.11.2026) · **Основание:** `SOURCE_CONFIRMED` — исходный код, миграции и тесты (тесты не запускались); БД и стенд не проверялись.

Тип заявки определяется несколькими независимыми осями. В ТЗ недостаточно написать только «заявка на поставку»: нужно указать направление, площадку, транспорт и способ описания содержимого.

Какие поля необходимо передать при create/update и когда запускается проверка выбранной комбинации, см. в [карте валидации](order-validation.md#межполевая-проверка-createupdate).

## 1. Направление (`ClientOrderType`)

| Код | Название | Корневая сущность | Правила |
|---|---|---|---|
| `RECEIVING` | Поставка | [ReceivingOrder](../entities/catalog/entities/receivingorder/ReceivingOrder.md) | [Правила поставки](receiving-orders.md) |
| `SHIPMENT` | Вывоз | [ShippingOrder](../entities/catalog/entities/shippingorder/ShippingOrder.md) | [Правила вывоза](shipping-orders.md) |
| `OPERATION` | Операция | Не является прямым discriminator конкретной JPA-сущности | Используется при классификации условий/операций; заявку на услугу см. отдельно |

[ServiceOrder](../entities/catalog/entities/serviceorder/ServiceOrder.md) имеет собственный тип услуги `ServiceOrderType`, а не поле `ClientOrderType`.

## 2. Площадка (`TerminalAreaEnum`)

| Код | Смысл | Основной способ описания груза |
|---|---|---|
| `WAREHOUSE` | Склад | Товары, грузовые места или недетализированный груз |
| `CONTAINER` | Контейнерная площадка | КТК; для ЖД также вагоны и документы |

`WAREHOUSE_428` сохранён в проверках обратной совместимости, но удалялся миграцией KIS-3543; его нельзя использовать в новом ТЗ без отдельного решения.

## 3. Транспорт (`TransportType`)

| Код | Значение TOS | Ограничение |
|---|---|---|
| `VEHICLE` | `АВТО` | Допустим для склада и контейнерной площадки |
| `RAILWAY` | `ЖД` | `BR-ORDER-001`: допустим только для `CONTAINER` |

## Матрица реализованных комбинаций

| Площадка | Транспорт | Поставка | Вывоз | Основные обязательные данные перед review/accept |
|---|---|---:|---:|---|
| `WAREHOUSE` | `VEHICLE` | да | да | Непустая связь Route + данные согласно `deliveryType` |
| `WAREHOUSE` | `RAILWAY` | нет | нет | Ошибка `*.InvalidTerminalAreaTransportType` |
| `CONTAINER` | `VEHICLE` | да | да | Route + номерные КТК; для вывоза NONE_CONTAINER вместо номера проверяется отдельная qty-строка и владелец |
| `CONTAINER` | `RAILWAY` | да | да | Накладные/ЭТРАН, вагоны; свойства имеющихся КТК (минимум КТК сейчас не контролируется) |

Комбинации, отсутствующие в таблице, не следует добавлять в ТЗ как допустимые без изменения `OrderCombinationValidator` и accept-валидаторов.

## 4. Вид поставки (`ReceivingOrderDeliveryType`)

Применяется к `ReceivingOrder` при `WAREHOUSE + VEHICLE`.

| Код | Что описывает заявку | Дочерние данные |
|---|---|---|
| `BY_GOOD` | По номенклатуре | `ReceivingOrderGood` |
| `BY_CARGO` | По грузовым местам без товарной детализации | `ReceivingOrderBlackbox` |
| `BY_GOOD_WITH_CARGO_WITHOUT_DETAILS` | Номенклатура + только общее число грузовых мест | товары + `totalCargoQuantity` |
| `BY_GOOD_WITH_CARGO_WITH_DETAILS` | Номенклатура + детальные грузовые места | `ReceivingOrderGood` + `ReceivingOrderCargo` |

`BR-ORDER-002`: для `WAREHOUSE + VEHICLE` вид обязателен; в остальных комбинациях при создании нормализуется в `null`.

## 5. Вид вывоза (`ShippingOrderDeliveryType`)

Применяется к `ShippingOrder` при `WAREHOUSE + VEHICLE`.

| Код | Что описывает заявку | Дочерние данные |
|---|---|---|
| `BY_GOOD` | По номенклатуре | `ShippingOrderGood` |
| `BY_CARGO` | По грузовым местам без товарной детализации | `ShippingOrderBlackbox` |
| `BY_GOOD_WITH_CARGO_WITH_DETAILS` | Номенклатура + детальные грузовые места | `ShippingOrderGood` + `ShippingOrderCargo` |

## 6. Тип заполнения вывоза (`ShippingOrderFillingType`)

Это отдельная ось: она показывает, известны ли конкретные номера вагонов и КТК.

| Код | Вагоны | КТК | Количественные сущности |
|---|---|---|---|
| `ALL` | конкретные номера | конкретные номера | не заменяют номерные строки |
| `RAILWAY_CARRIAGE` | конкретные номера | без конкретных номеров | контейнеры описываются количеством |
| `CONTAINER` | без конкретных номеров | конкретные номера | вагоны описываются количеством |
| `NONE` | без конкретных номеров | без конкретных номеров | оба вида описываются количеством |
| `NONE_CONTAINER` | неприменимо/по сценарию авто | один неизвестный порожний КТК | ровно одна `ShippingOrderContainerQty`: `quantity=1`, `empty=true`, без ЕТСНГ |

`BR-SO-001`: `NONE_CONTAINER` допустим только для `CONTAINER + VEHICLE` (иначе `ShippingOrder.InvalidFillingType`). Default модели — `ALL` (`@Builder.Default` + `@PrePersist`); validateAndNormalize дополнительно ставит ALL при create CONTAINER + RAILWAY с NULL. Обычный update не переносит fillingType из DTO и не вызывает эту нормализацию. Для остальных комбинаций fillingType не обнуляется; prePersist также заменяет NULL на ALL.

Безномерные операции по частям заявки привязаны к конкретному типу: `/shipping-order/{id}/shipping-order-container/unnumbered/*` — только `fillingType=CONTAINER`, `/shipping-order/{id}/shipping-order-railway-carriage/unnumbered/*` — только `RAILWAY_CARRIAGE` (иначе `IllegalArgumentException`). Константа `ShippingOrderFillingType.UNNUMBERED_TYPES` = все типы, кроме `ALL`, используется при экспорте маршрутов. Endpoints `/shippingorder/unnumbered/*` удалены 09.09.2026 (`4696ed25`, «remove deprecated api»).

## 7. Тип сервисной заявки (`ServiceOrderType`)

| Код | Смысл | Результат выполнения |
|---|---|---|
| `CHANGE_OWNER` | Смена владельца КТК | Владельцем всех связанных контейнеров становится клиент заявки |

## Наследование правил

- Все три корня наследуют правила идентификации и номера из [Order](../entities/catalog/mapped-superclasses/order/Order.md).
- `ReceivingOrder` и `ShippingOrder` дополнительно наследуют площадку, транспорт и общий статус из [TransportOrder](../entities/catalog/mapped-superclasses/order/TransportOrder.md).
- Статусы транспортных и сервисных заявок различаются: [статусная модель](order-statuses.md).

## Проектирование нового типа

Новый тип нельзя добавлять только новой enum-константой. Требуется определить:

1. Родителя: `Order`, `TransportOrder` или новый базовый тип.
2. Положение во всех осях классификации и допустимые комбинации.
3. Собственный состав агрегата и переиспользуемые дочерние сущности.
4. Статусную модель: наследовать `OrderStatus` или создать отдельную.
5. Creation/update/response DTO и правила mutability каждого поля.
6. Матрицу review/accept, коды ошибок и feature flags.
7. Состав partial/full copy.
8. Outbound/inbound сообщения, root object и идемпотентность.
9. Permission, RLS, миграции, индексы, отчёты и тесты.

Результат проектирования связывается по цепочке из [библиотеки правил](README.md#принцип-переиспользования), а общие правила получают `BR-ORDER-*` вместо дублирования в каждой специализации.
