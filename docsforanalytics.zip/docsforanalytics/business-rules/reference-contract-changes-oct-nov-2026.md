# Справочники, владельцы и ошибки: уточнения октября–ноября

Целевая сверка 3d3899d5d от 11.11.2026, AS_IS / SOURCE_CONFIRMED по коду и исходникам тестов. Runtime и Java-тесты не запускались.

## Создание грузового места

b25f1cb27 добавляет `POST /cargo/`, CARGO/CREATE, JSON BaseCodedCreationDto → IdCodeDto. Code имеет @NotBlank и @Size(max=100); inherited active остаётся частью DTO. CargoService перед add проверяет count по CargoFilter.code через SearchString и при совпадении выбрасывает DuplicateEntityException с кодом Cargo.CodeAlreadyExists. В SQL cargo.code VARCHAR(100) NOT NULL UNIQUE: приложение и БД имеют разные уровни защиты/сравнения. Объявлены ответы 200/400/409. Внутренний findOrCreateCargo использует DAO напрямую и не является вызовом этого публичного add с его проверкой.

## Уникальность клиента по ИНН/КПП

3677c832e добавляет checkInnKppUniqueness при создании, если inn != NULL; прежде эта проверка была только в update. Count строится по inn и по kpp только если kpp != NULL. Поэтому null kpp означает поиск по ИНН без ограничения КПП, а не проверку пары (ИНН, NULL). SearchString.isNotBlank отбрасывает blank INN/KPP: при blank KPP его условие также отсутствует, а при blank INN create-проверка способна получить ещё более широкий count. При count>0 — Client.InnKppAlreadyExists; OpenAPI create/update исправлен на 409.

Update вызывает проверку при непустом новом inn и изменении inn или kpp. В текущем count нет исключения ID самой обновляемой строки; `INFERENCE`: некоторые изменения, например очистка КПП при том же ИНН, могут конфликтовать с самой записью. Требуется отдельный тест. Проверка count-then-write сама по себе не исключает гонку; live constraints не проверялись.

## История владельцев: исключение для SERVICE_ORDER

1db3d70b3 изменяет статусный предикат на `(orderStatus condition AND newStatus condition) OR orderType=SERVICE_ORDER`. Сервис page/meta по-прежнему задаёт DONE и ON_TERMINAL/DEPARTED, но SERVICE_ORDER проходит эту группу независимо от статуса услуги и newStatus, включая NULL статусы истории. Фильтр контейнера, явно заданный orderType, клиент и остальные условия остаются снаружи этой OR-группы и сохраняются.

Следовательно, описание «API показывает только выполненные заявки» верно для receiving/shipping, но не является общей гарантией для услуг. Исходник ContainerOwnerHistoryControllerIntegrationTest содержит page/meta-кейс с draft service order и отдельную проверку orderType=RECEIVING_ORDER; тест не запускался.

## Смена владельца по умолчанию у поставки

545a1ebfd: если update передаёт непустого отличающегося defaultContainerOwner, сервис загружает Client, меняет default и добавляет post-update действие, которое переписывает владельца всех найденных прямых ReceivingOrderContainer и связанных WaybillContainer. Это не только заполнение пустых значений: индивидуальные прежние владельцы перезаписываются. Текущий Waybill lookup исключает excluded-контейнеры/вагоны. Общая проверка статуса update сохраняется; NULL default владельца не очищает. Сам этот метод не меняет ContainerOwner registry.

## ISO-тип в route chain package

20209781a добавляет в три транспортных пакета (receiving auto/railway, shipping) `ContainerTypeIso[]` с полями id и containerTypeCode; Container[].containerTypeIso — UUID этого справочника. Список строится по используемым Container.containerTypeISO, с пропуском NULL и дедупликацией по непустому ID. Это не поле identifier из ЭТРАН и не ContainerType enum. Service-order package этим изменением не дополнен. Отправка отмены использует те же builders для нового снимка; старый сохранённый JSON не меняется автоматически. f6cfeb3c0/86d2dc4fa корректируют тест/форматирование, не добавляют отдельный бизнес-контракт.

## Ошибки групп Keycloak

5665d28d8 проверяет ответ создания группы: любой HttpStatus.isError даёт Keycloak.UserGroupAlreadyExists, поэтому код не доказывает, что внешняя причина именно дубль. Поиск имени использует exact=true и берёт первый результат; пустой список даёт keycloak-any-error. 7898d0aaa убирает прежнюю ведущую точку из обеих строк. Доступность Keycloak и форма публичного error DTO здесь отдельно не проверялись.

## Границы сверки

Пагинация countcontaineronterminal из 8846daaef и последующее добавление клиентов с нулевым count уже описаны в [правилах владельцев вывоза](shipping-container-owners-as-is.md). Эта проверка не закрывает все остальные части коммитов 7d92a3277/45e6620a1 или общий контракт client scope. Текущий результат бинарного сравнения шаблонов — [отдельный отчёт](../traceability/excel-template-diff-2026-11-11.md).

## Источники

- [CargoController.java](../../../web-layer/src/main/java/ru/korusconsulting/alis/controller/cargo/CargoController.java)
- [CargoService.java](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/cargo/CargoService.java)
- [BaseCodedCreationDto.java](../../../wms-layer/src/main/java/ru/korusconsulting/wms/dto/BaseCodedCreationDto.java)
- [v1.0.0_20250318_KIS-742_add_table_cargo.sql](../../../db-layer/src/main/resources/db/changelog/v.1.0.0/v1.0.0_20250318_KIS-742_add_table_cargo.sql)
- [ClientService.java](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/client/ClientService.java)
- [ContainerOwnerHistoryPredicate.java](../../../db-layer/src/main/java/ru/korusconsulting/alis/predicate/containerownerhistory/ContainerOwnerHistoryPredicate.java)
- [ContainerOwnerHistoryService.java](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/containerownerhistory/ContainerOwnerHistoryService.java)
- [ContainerOwnerHistoryControllerIntegrationTest.java](../../../web-layer/src/integrationTest/java/ru/korusconsulting/alis/controller/containerownerhistory/ContainerOwnerHistoryControllerIntegrationTest.java)
- [ReceivingOrderService.java](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/receivingorder/ReceivingOrderService.java)
- [BaseRouteChainPackageExportService.java](../../../web-layer/src/main/java/ru/korusconsulting/alis/datareon/service/routechainpackage/BaseRouteChainPackageExportService.java)
- [ContainerTypeIsoDto.java](../../../web-layer/src/main/java/ru/korusconsulting/alis/datareon/dto/routechainpackage/ContainerTypeIsoDto.java)
- [WmsKeycloakFacade.java](../../../wms-layer/src/main/java/ru/korusconsulting/wms/service/keycloak/WmsKeycloakFacade.java)
