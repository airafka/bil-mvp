# Waybill и входящий ЭТРАН: актуальный AS-IS

> **Сверено:** backend `3d3899d5d` (12.11.2026) · **Основание:** `SOURCE_CONFIRMED` — исходный код, миграции и тесты (тесты не запускались); БД и стенд не проверялись.

Документ фиксирует **AS-IS** контура ЖД-накладной: `POST /datareon/waybill`, создание и повторную загрузку агрегата, справочники, пользовательские endpoints, связь с поставкой, ошибки, транзакции и тесты. TO-BE здесь не проектируется.

Историческое исследование ЖД-модель вокруг Waybill (источник недоступен; [реестр](../research/unavailable-sources.md)) выполнено на `3d8c8bb71a04fef2e9319d350ae7c0d1bfbaa318`. Этот документ заменяет его как источник **текущего** AS-IS, но не переносит предложенный там overlay/вариант C в реализованную модель.

Формирование пакета в 1С ЭТРАН, процесс `Etran_27`, фильтр статусов и преобразования Datareon описаны отдельно в [сквозном контуре ГУ-27 / накладной ЭТРАН / ЖДН / СМГС 2015](../integrations/1c-etran-waybill-gu27-as-is.md). Полная структура внешнего типа находится в [паспорте Datareon `Etran27`](../integrations/1c-etran-waybill-gu27-datareon-contract.md).

Как накладные показываются и привязываются в интерфейсе — в [UI-правилах накладных](waybill-ui-rules-as-is.md).

## Граница агрегата

```mermaid
flowchart LR
    E[POST /datareon/waybill] --> W[Waybill]
    W --> WRC[WaybillRailwayCarriage]
    WRC --> RC[RailwayCarriage<br/>справочный объект]
    WRC --> WC[WaybillContainer]
    WC --> C[Container<br/>справочный объект]
    WC --> Z[WaybillZpu]
    W --> P[WaybillProduct]
    P --> ETSNG[Etsng]
    P --> DP[DangerProduct]
    W --> SM[SpecialMark]
    W --> TM[TariffMark]
    RO[ReceivingOrder] -. nullable link .-> W
```

- [Waybill](../entities/catalog/entities/waybill/Waybill.md) — корень source-агрегата ЭТРАН; `waybillIdentifier` уникален в БД.
- [WaybillRailwayCarriage](../entities/catalog/entities/waybillrailwaycarriage/WaybillRailwayCarriage.md) — снимок участия физического [RailwayCarriage](../entities/catalog/entities/railway/RailwayCarriage.md) в накладной.
- [WaybillContainer](../entities/catalog/entities/waybillcontainer/WaybillContainer.md) — снимок КТК внутри WRC; ссылается на физический [Container](../entities/catalog/entities/container/Container.md).
- [WaybillProduct](../entities/catalog/entities/waybillproduct/WaybillProduct.md), [WaybillZpu](../entities/catalog/entities/waybillzpu/WaybillZpu.md), [WaybillSpecialMark](../entities/catalog/entities/waybillspecialmark/WaybillSpecialMark.md) и [WaybillTariffMark](../entities/catalog/entities/waybilltariffmark/WaybillTariffMark.md) принадлежат накладной.
- `Waybill.receivingOrder` nullable. Отдельного overlay-контейнера конкретной поставки в этой модели нет: несколько экранов поставки читают исходные WRC/WC/Product напрямую.

## Входной endpoint и DTO

`POST /datareon/waybill` принимает `@RequestBody @Valid` [WaybillIntegrationDto](../dto/catalog/datareon/inbound/WaybillIntegrationDto.md) и возвращает [WaybillShortDto](../dto/catalog/waybill/WaybillShortDto.md). Endpoint находится в публичной security-зоне `/datareon/**`; отдельного `@Secure` у метода нет. В отличие от универсального `/datareon/event`, этот метод не создаёт `InboundEvent` и не вызывает журналирование входного пакета.

Корневые поля:

| JSON | Java | Обязательность AS-IS | Использование |
|---|---|---|---|
| `Version` | `version` | nullable | Сервис не читает. |
| `MessageId`, alias `MessageID` | `messageId` | nullable UUID | Сервис не читает; не является ключом дедупликации. |
| `waybill` | `waybill` | `@NotNull` | Единственное поле, обязательность которого реально проверяется корневым `@Valid`. |

Критическая деталь: на `WaybillIntegrationDto.waybill` отсутствует `@Valid`. Поэтому `@NotNull` вложенных `waybill_status`, `waybill_number`, `waybill_identifier`, станций и полей вагона **не каскадируют** при controller validation. Их фактическая обязательность определяется последующими преобразованиями, обращениями к спискам и DB constraints.

Вложенные паспорта DTO:

- [Waybill](../dto/catalog/datareon/inbound/WaybillIntegrationDto.Waybill.md);
- [RailwayCarriage](../dto/catalog/datareon/inbound/WaybillIntegrationDto.Waybill.RailwayCarriage.md);
- [Container](../dto/catalog/datareon/inbound/WaybillIntegrationDto.Waybill.Container.md);
- [Product](../dto/catalog/datareon/inbound/WaybillIntegrationDto.Waybill.Product.md);
- [ContainerZpu](../dto/catalog/datareon/inbound/WaybillIntegrationDto.Waybill.ContainerZpu.md), [SpecialMark](../dto/catalog/datareon/inbound/WaybillIntegrationDto.Waybill.SpecialMark.md), [TariffMark](../dto/catalog/datareon/inbound/WaybillIntegrationDto.Waybill.TariffMark.md).

Поддерживаются aliases `Грузы`, `Вагоны`, `wagon_container`/`Контейнеры`, `СпециальныеОтметки`, `ТарифныеОтметкиЗаОтправку`, `container_zpu`/`КонтейнерЗПУ`. Это альтернативные JSON-имена тех же списков, а не отдельные модели.

## Алгоритм импорта

```mermaid
flowchart TD
    R[Принять WaybillIntegrationDto] --> D[Разрешить DangerProduct для products]
    D --> I[Integer.valueOf waybill_identifier]
    I --> F{Waybill с identifier найден?}
    F -->|да| S[Обновить status, type, связи и товары]
    F -->|нет| V[Проверить сочетание products / containers]
    V --> M[Создать Waybill creationSource=ETRAN;<br/>найти/создать станции, плательщика]
    M --> C1[Создать WRC; найти RailwayCarriage<br/>или создать новый]
    C1 --> C2[Создать WC; найти Container<br/>или создать новый]
    C2 --> C3[Создать Product, ZPU, marks]
    S --> SYNC[Разрешить связи досылочных;<br/>исключить вагоны основной]
    C3 --> SYNC
    SYNC --> COMMIT[Commit общей транзакции]
```

Весь `handleInboundWaybill` выполняется в одной транзакции. Для новой накладной корень, справочники и дочерние строки либо фиксируются вместе, либо откатываются вместе. Списки накладных читают обычную view `waybill_view`, поэтому новые данные видны сразу после commit. До 14.09.2026 (`978ba888`, KIS-4690) после commit асинхронно обновлялась materialized view `grouped_waybill`.

### Повтор с существующим identifier

Поиск выполняется исключительно по числовому `waybill_identifier`. Если запись уже есть:

1. danger-коды из входных products разрешаются до поиска;
2. обновляются status, непустой type, connection-поля досылочной и категория;
3. товары частично upsert-ятся по ЕТСНГ/GNG с сохранением UUID найденной строки; отсутствующие во входе старые товары не удаляются;
4. номер, станции, payer, даты, состав вагонов/КТК, ЗПУ и отметки не заменяются;
5. после сохранения выполняется разрешение связей досылочных и исключение вагонов основной.

Сверка 11.11.2026 (`930a1d076`): прежнее описание «меняется только status» устарело. Это частичный upsert, не полная замена агрегата; MessageId/Version не используются для дедупликации. Подробности полей, ошибок, категорий и чтения children — [основные и досылочные накладные](waybill-supplementary-as-is.md).

### Новая накладная и условная валидация

Ручной validator действует только при создании:

| Условие | Требование |
|---|---|
| `products.size() >= 2` | Ровно один контейнер. |
| Один product и хотя бы один WRC с непустым числовым `netWeight > 0` | Минимум один контейнер. |
| Один product и нет загруженного вагона | Контейнер может отсутствовать. |
| Нет products | Ошибка. |

`products` и `containers` фактически не могут быть `null`, потому что validator вызывает `.size()`. Для создания также фактически требуются ненулевые списки `railwayCarriages`, `containerZpus`, `specialMarks`, `tariffMarks`, поскольку mapper их перебирает без подстановки пустого списка. Семь дат корня обязательны в create-ветке из-за обращений без null-check: `deliveryDeadline.toLocalDate()`, а `createdAt`, `submittedAt`, `approvedAt`, `acceptedAt`, `cargoAcceptedAt`, `departureAt` — через `atZone`. Эти требования не отражены Bean Validation и при нарушении обычно дают `500`, а не понятный `400`.

### Корень и справочники

- `waybill_identifier`, TGNL/OKPO и коды справочников преобразуются из строк в числа; некорректный формат даёт runtime-ошибку.
- Шесть временных меток интерпретируются в зоне `Europe/Moscow` и сохраняются как `Instant`; `deliveryDeadline` сохраняется как `LocalDate` через `toLocalDate()`, без перевода зоны.
- Станция ищется по ESR-коду. Если её нет, создаётся запись с входным наименованием, причём `code` также заполняется этим наименованием.
- Пустой `payer_code` ведёт к поиску/созданию плательщика `Без плательщика` с `code=null`. Непустой код преобразуется в `Long`; отсутствующий плательщик создаётся с входным именем.
- ETSNG ищется по коду; отсутствующий элемент создаётся с входным названием.
- Пустой `danger_product` означает seed-запись с identifier `-1`. Известный числовой код связывается со справочником. Неизвестный, нечисловой либо выходящий за `Integer` код даёт `ValidationException` и HTTP `400`.

### Вагоны

Для каждого входного [RailwayCarriage DTO](../dto/catalog/datareon/inbound/WaybillIntegrationDto.Waybill.RailwayCarriage.md):

- глобальный `RailwayCarriage` ищется по точному номеру; **найденный объект используется как есть и не изменяется** (с 03.09.2026, `90f71f39`, KIS-4665; до этого перезаписывался входными данными);
- для нового вагона обязательны `type_id` и `railway_lifting_capacity` (иначе `ValidationException` → `400`); `type_id` — готовый код `RailwayCarriageType`, отсутствие кода в справочнике → `NotFoundException` (`404`);
- непустая `model` ищется по коду, а отсутствующая модель **создаётся** (`RailwayCarriageModelService.findOrCreateByCode`);
- грузоподъёмность, объём, тара `railway_weight`, длина и пробеги сохраняются без пересчёта единиц; строковые числа парсятся;
- WRC сохраняет контекст накладной: ownership, renter, previous cargo, gross/net weight и places.

Дата ремонта использует только календарную часть. Год раньше 1970 и пустое значение дают `null`; некорректная дата логируется и также превращается в `null`.

### Контейнеры и ЗПУ

Для каждого [Container DTO](../dto/catalog/datareon/inbound/WaybillIntegrationDto.Waybill.Container.md):

- `carriage_number` обязан совпасть с номером одного из WRC **этого пакета**; иначе импорт падает;
- физический `Container` ищется по точному номеру; **найденный объект используется как есть и не изменяется** (с 03.09.2026, `1c97f92d`, KIS-4664);
- только для нового КТК ISO преобразуется в `Long` и ищется в `ContainerTypeISO` (отсутствующий identifier → `404`, некорректный формат → `500`), `container_type` принимается готовым enum `ContainerType` (включая `UNKNOWN`), создаётся `refrigerator=false`;
- WC сохраняет supply/sending request, owner, length, net weight, а в собственное поле `weight` записывает входной `weight_gross`.

Каждый ZPU ищет WC текущего пакета по номеру физического КТК. Несовпадение номера прерывает транзакцию. Сохраняются `zpu` и `zpu_type`.

## Пользовательские endpoints Waybill

Полные transport-сигнатуры, required-флаги, media types и DTO доступны в generated-разделах [WaybillController](../api/endpoints-generated.md#waybillcontroller), [WaybillRailwayCarriageController](../api/endpoints-generated.md#waybillrailwaycarriagecontroller), [WaybillContainerController](../api/endpoints-generated.md#waybillcontainercontroller), [WaybillProductController](../api/endpoints-generated.md#waybillproductcontroller), [WaybillSpecialMarkController](../api/endpoints-generated.md#waybillspecialmarkcontroller) и [WaybillTariffMarkController](../api/endpoints-generated.md#waybilltariffmarkcontroller). Все эти методы защищены permission `WAYBILL` и являются read-only.

### Корень `/waybill`

До 14.09.2026 (`978ba888`, KIS-4690) существовали `/grouped/page`, `/incoming/grouped/page`, `/outgoing/grouped/page` и DTO `GroupedWaybillFilter`/`GroupedWaybillDto`/`WaybillTabFilter`/`WaybillArchiveFilter`/`WaybillArchiveRowDto`; они удалены вместе с materialized view `grouped_waybill`.

| Endpoint | Request → response | Серверная логика |
|---|---|---|
| `GET /{id}` | path UUID → [WaybillDetailedDto](../dto/catalog/waybill/WaybillDetailedDto.md) | Карточка одной живой накладной. |
| `POST /incoming/page` | `FilterWithPaging<WaybillFilter>` (+ `X-Timezone`) → page `WaybillStationPairGroupDto` | `WaybillType.INCOMING` принудительно выставляется в filter; группировка по станции/плательщику строится в запросе `WaybillViewDaoService.getHierarchyPage` (QueryDSL `groupBy`), а не SQL-view. |
| `POST /incoming/meta/{fieldName}` | тот же filter | Meta по входящим. |
| `POST /outgoing/page` | тот же паттерн, `WaybillType.OUTGOING` | Группировка так же, в запросе. |
| `POST /outgoing/meta/{fieldName}` | — | Meta по исходящим. |
| `POST /archive/page` | тот же паттерн, `WaybillType.ARCHIVE` | Единый `WaybillFilter` вместо прежнего `WaybillArchiveFilter`; ответ — тот же `WaybillStationPairGroupDto`, а не `WaybillArchiveRowDto`. |
| `POST /archive/meta/{fieldName}` | — | Meta по архиву. |
| `POST /receiving-order/{id}/meta/{fieldName}` | `FilterWithPaging<WaybillFilter>` → `IdsCodeDto[]` | Добавляет ограничение по связанной поставке (`receivingOrderId` + `receivingOrderIdNullOrEqual=false`). |
| `POST /payers` | `FilterWithPaging<WaybillPayerFilter>` → page `PayerDto` | Справочник плательщиков в контексте Waybill. |
| `POST /departure-stations/page` | station filter → page `RailwayStationDto` | Станции отправления из накладных. |
| `POST /destination-stations/page` | station filter → page `RailwayStationDto` | Станции назначения из накладных. |
| `POST /for-receiving-order/page` | [WaybillForReceivingOrderFilter](../dto/catalog/waybill/WaybillForReceivingOrderFilter.md) → page [WaybillForReceivingOrderRowDto](../dto/catalog/waybill/WaybillForReceivingOrderRowDto.md) | Кандидаты для поставки: непривязанные либо уже связанные с этой поставкой; используются входящие ESR и недостающие payer/stations из заявки. С 14.10.2026 (`059d5f5a`, KIS-4861) накладные со статусом `Работа с документом окончена` **больше не исключаются** — их можно выбрать и привязать к поставке (константа `STATUS_WORK_DONE` и Javadoc `buildWaybillFilter` в `WaybillService` остались, но фильтр не применяется). |

Списки читают обычную (не materialized) view [`waybill_view`](../../../db-layer/src/main/resources/db/changelog/rerunnable/view_waybill.sql) без refresh-цикла; прежняя модель — в [DEPRECATED-заметке](../database/grouped-waybill-as-is.md). Отдельный source-level [паспорт waybill_view и группировки](../database/waybill-view-as-is.md) добавлен при сверке 11.11.2026. Общего `POST /waybill/meta/{fieldName}` нет — только `/incoming|outgoing|archive/meta/{fieldName}` и `/receiving-order/{id}/meta/{fieldName}`.

**`overdueDays` (коммит `17978487`, KIS-4690, 15 сентября 2026).** Поле строки ответа `WaybillStationPairGroupDto` считается в `WaybillService.calculateOverdueDays` относительно `LocalDate.now(timezone)`, где `timezone` — обязательный заголовок `X-Timezone` запроса (см. таблицу endpoint'ов выше), а не серверная/UTC дата. Значение непустое, только если одновременно: (1) накладная **не привязана** к заявке на поставку (`receivingOrderId == null`) и (2) `deliveryDeadline` раньше «сегодня» в этой таймзоне; иначе поле `null` — в частности, у уже привязанной к поставке накладной `overdueDays` не считается вовсе, даже если её `deliveryDeadline` истёк.

### Дочерние read endpoints

| Ресурс | Endpoints | Основные DTO |
|---|---|---|
| `/waybill-railway-carriage` | `POST /page`, `POST /meta/{field}`, `POST /receiving-order/{id}/meta/{field}`, `GET /{id}` | filter → `WaybillRailwayCarriageDto`/detail |
| `/waybill-container` | `POST /page`, `POST /meta/{field}`, `POST /receiving-order/{id}/meta/{field}` | filter → [WaybillContainer](../entities/catalog/entities/waybillcontainer/WaybillContainer.md) DTO page |
| `/waybill-product` | `POST /page`, `POST /meta/{field}`, `POST /receiving-order/{id}/meta/{field}`, `GET /{id}` | filter → WaybillProduct DTO/detail |
| `/waybill-special-mark` | `POST /page` | filter → WaybillSpecialMark DTO page |
| `/waybill-tariff-mark` | `POST /page` | filter → WaybillTariffMark DTO page |

Текущие WRC-фильтр `railwayCarriageType` (JSON alias `sort`) и meta `sort`/`railwaycarriagetype` используют `railwayCarriage.sort`, а не `railwayCarriage.type.code`. Историческое описание по `42eee4ee` нельзя переносить на текущий predicate/service. Для контейнерного meta `etsngcode` коды берутся из товаров той же накладной, поэтому один код сопоставляется всем её КТК, а не конкретному содержимому контейнера.

## Связь с заявкой на поставку

Новый scoped API находится в [ReceivingOrderController](../api/endpoints-generated.md#receivingordercontroller):

| Endpoint | DTO | Право | Эффект |
|---|---|---|---|
| `POST /receivingorder/{id}/waybills` | optional `WaybillFilter` → список [WaybillShortDto](../dto/catalog/waybill/WaybillShortDto.md) | `ReceivingOrder/READ` | Читает связанные накладные. |
| `PUT /receivingorder/{id}/waybills` | [WaybillSelectionDto](../dto/catalog/waybill/WaybillSelectionDto.md) → список `WaybillShortDto` | `ReceivingOrder/WRITE` | Полностью заменяет набор связей. |
| `PUT /receivingorder/{receivingOrderId}/waybill-containers/owners` | список `WaybillContainerOwnerUpdateDto` → тот же список | `RECEIVING_ORDER/WRITE` | С 22.09.2026 (`3bcf0113`, KIS-4716): задаёт собственника (`ownerContainer`) у `WaybillContainer` накладных этой заявки; только `DRAFT`/`ON_REVIEW`; ID должны быть уникальны и принадлежать заявке (иначе `404`). |
| `POST .../waybill-railway-carriages/page` | [ReceivingOrderWaybillCarriageFilter](../dto/catalog/waybill/ReceivingOrderWaybillCarriageFilter.md) → grouped page | `ReceivingOrder/READ` | Группирует WRC по накладным. |
| `POST .../waybill-containers/page` | [ReceivingOrderWaybillContainerFilter](../dto/catalog/waybill/ReceivingOrderWaybillContainerFilter.md) → grouped page | `ReceivingOrder/READ` | Группирует WC по накладным. |
| `POST .../waybill-products/page` | [ReceivingOrderWaybillProductFilter](../dto/catalog/waybill/ReceivingOrderWaybillProductFilter.md) → grouped page | `ReceivingOrder/READ` | Группирует товары по накладным. |

Три grouped child-read сначала вызывают пользовательское ограничение для `ReceivingOrder` и возвращают `404`, если заявка недоступна. В просмотренной цепочке bulk save такой отдельной row-level проверки не вызывает.

`WaybillSelectionDto.waybillIds` имеет `@NotNull`, но элементы списка не имеют `@NotNull`. Bulk-алгоритм:

0. проверяет статус заявки `OrderServiceUtils.checkOrderStatusForUpdate`: изменение разрешено только в `DRAFT` и `ON_REVIEW` (для `ON_REVIEW` — при праве `RECEIVING_ORDER_SEND_TO_ACCEPT`), иначе `AccessDeniedException` → `403` (с 22.09.2026, `3bcf0113`, KIS-4716);
1. для всех переданных существующих Waybill устанавливает `receiving_order_id` текущей заявки;
2. у ранее связанных с ней, но не выбранных Waybill очищает ссылку;
3. пустой список очищает все связи этой заявки;
4. неизвестные Waybill IDs молча не попадают в результат;
5. Waybill, уже связанная с другой заявкой, перепривязывается без проверки;
6. `WaybillContainer` выбранных накладных без собственника получают `ownerContainer = ReceivingOrder.defaultContainerOwner`.

Алгоритм не проверяет тип поставки, статус накладной, состав WRC/WC и не использует блокировку строк. Одиночные link/relink/unlink legacy-контроллера тоже вызывают `checkOrderStatusForUpdate`. При `reject` поставки сервис очищает все её Waybill-связи.

Legacy [ReceivingOrderEtranInvoiceController](../api/endpoints-generated.md#receivingorderetraninvoicecontroller) остаётся действующим:

| Endpoint | DTO | AS-IS |
|---|---|---|
| `POST /receivingorderetraninvoice/all` | optional [WaybillLinkedToOrderFilter](../dto/catalog/waybill/WaybillLinkedToOrderFilter.md) → `IdCodeDto[]` | Нет `@Secure`; без order filter возвращается пустой список. |
| `POST /page`, `GET /{id}` | filter/path → [WaybillLinkedToOrderDto](../dto/catalog/waybill/WaybillLinkedToOrderDto.md) | Permission `ReceivingOrder.EtranInvoice/READ`. |
| `POST /` | [WaybillLinkRequestDto](../dto/catalog/waybill/WaybillLinkRequestDto.md) → linked DTO | Привязывает одну накладную; request не имеет Bean Validation. |
| `PUT /{oldWaybillId}` | `WaybillLinkRequestDto` → linked DTO | При разных ID отвязывает старую и привязывает указанную новую. |
| `DELETE /{waybillId}` | path → linked DTO | Только очищает `receivingOrder`, Waybill не удаляет. |
| `POST /{receivingOrderId}` | `WaybillSelectionDto` → список short DTO | Тот же bulk replace, но endpoint защищён уровнем `DELETE`. |

Legacy `DELETE /receivingorderrailwaycarriage/{id}` отличается: он физически удаляет [WaybillRailwayCarriage](../entities/catalog/entities/waybillrailwaycarriage/WaybillRailwayCarriage.md), а не только связь с поставкой. Это потенциально удаляет source-часть накладной вместе с зависимыми WC/ZPU по каскадам БД.

## Ошибки HTTP

| Условие | Исключение/источник AS-IS | HTTP |
|---|---|---:|
| Нет корневого `waybill` | Bean Validation | `400` |
| Некорректный JSON, UUID либо enum `container_type` | Jackson | `400` |
| Неизвестный `danger_product` | `ValidationException` | `400` |
| Не найден `ContainerTypeISO` | `NotFoundException` | `404` |
| Не найден Waybill/ReceivingOrder в одиночном link/relink | `NotFoundException` | `404` |
| Нулевые списки/даты, нечисловой identifier/TGNL/ISO/вес | NPE/`NumberFormatException` | `500` |
| Нарушено правило product/container | `IllegalArgumentException` | `500` |
| Container не сопоставлен WRC или ZPU не сопоставлен WC | `EntityNotFoundException` без отдельного mapping | `500` |
| Новый вагон без `type_id`/`railway_lifting_capacity` | `ValidationException` | `400` |
| Не найден код типа нового вагона | `NotFoundException` | `404` |
| Конкурентная вставка одинакового identifier | DB unique violation (`DataIntegrityViolationException`) | `500` (с 16.09.2026, `d24879c6`; раньше `23505` → `409`) |

OpenAPI endpoint заявляет `400 Validation problems`, но не раскрывает фактические `404/409/500` и их response schemas. Формат ошибок задаётся общим `ExceptionAdvice`.

## Повторы, конкурентность и доверие

- DB migration задаёт `waybill_identifier INTEGER NOT NULL UNIQUE`; это единственный подтверждённый бизнес-ключ импорта.
- Проверка «найти, иначе создать» не использует row lock/upsert. Два параллельных первых пакета одного identifier могут оба пройти `find` и столкнуться на unique constraint.
- Параллельные повторы существующей накладной могут перезаписывать status, type, связи и товары без optimistic locking; `@Version` у Waybill не найден.
- Импорт накладной создаёт отсутствующие глобальные RailwayCarriage/Container/модели вагонов, но существующие справочные объекты не меняет (с 03.09.2026).
- `MessageId` не сохраняется, поэтому невозможно доказать, что один внешний пакет обработан ровно один раз.
- Import endpoint публичен на уровне Spring Security. Внутренний источник, gateway/authentication и внешний Datareon transform этим репозиторием не подтверждены.
- Применённая схема БД и реальные cascade constraints среды не проверялись; выводы по ограничениям сделаны по Liquibase.

## Изменения после исторического исследования

| Commit | Влияние на текущий AS-IS |
|---|---|
| `4e55d447eb554311d5d5e8dab8877011befccbfe`, 21.08.2026, `KIS-4590 remove value calculation from waybill integration` | Удалил вычисление типа вагона по `sort`/длине и типа КТК только по длине. Вход теперь передаёт готовые `type_id`, `container_type` и `ISO`; DTO, сервис и integration test изменены. Поэтому причина из исторического документа дефекта (источник недоступен; [реестр](../research/unavailable-sources.md)) больше не описывает текущий код. |
| `42eee4eefbb32bf8be1124f7cb88f20ed0efcb18`, `KIS-4368 fix meta filtering and nested frame issues` | Изменил пользовательскую фильтрацию/сортировку WRC/WC и `WaybillService`: тип вагона теперь отделён от `sort`, добавлен контейнерный meta по ETSNG. |

| `90f71f39` / `1c97f92d`, 03.09.2026, `KIS-4665` / `KIS-4664` | Существующие RailwayCarriage/Container больше не перезаписываются; обязательные поля только для нового вагона; find-or-create модели вагона; `ContainerType.UNKNOWN`. |
| `978ba888`, 14.09.2026, `KIS-4690` | Удалены materialized view `grouped_waybill` и async refresh после импорта; добавлен `Waybill.creationSource=ETRAN`. |
| `3bcf0113`, 22.09.2026, `KIS-4716` | Bulk-связь накладных проверяет статус заявки и проставляет собственника КТК по умолчанию; endpoint собственников WC. |

Импорт не lookup-only: он создаёт отсутствующие RailwayCarriage/Container/модели вагонов, stations/payer/ETSNG.

Специализированные импорты тех же глобальных справочников разобраны отдельно: [вагоны и КТК ЭТРАН](etran-reference-imports-as-is.md). В отличие от импорта накладной они выполняют patch-update существующих объектов через общие `RailwayCarriageService`/`ContainerService`.

## Тестовая трассировка

[WaybillDatareonServiceIntegrationTest](../../../web-layer/src/integrationTest/java/ru/korusconsulting/alis/service/datareon/WaybillDatareonServiceIntegrationTest.java) подтверждает:

- создание корня, одного WRC, WC и Product;
- использование подготовленного типа вагона и готовых container type/ISO в test fixture;
- seed классификатора опасных грузов и его индексы;
- известный/пустой/неизвестный danger code, включая HTTP `400`;
- ровно один lookup danger code при создании;
- повтор существующей накладной с обновлением status; поздние сценарии также проверяют связь досылочных и обновление товаров;
- отказ по неизвестному danger code даже для существующей накладной.

В просмотренных тестах не найдены отдельные проверки nested Bean Validation, всех null-list/date случаев, product/container validator через HTTP, station/payer/ETSNG creation, повторного использования существующего физического вагона/КТК, ZPU mismatch, конкурентного первого импорта, bulk link/relink/unlink, смены связи после финального статуса заявки и физического legacy-delete WRC. Найденные тесты не запускались.

Источники: [DatareonController](../../../web-layer/src/main/java/ru/korusconsulting/alis/controller/datareon/DatareonController.java), [WaybillIntegrationDto.java](../../../web-layer/src/main/java/ru/korusconsulting/alis/dto/datareon/inbound/WaybillIntegrationDto.java), [WaybillDatareonService](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/datareon/WaybillDatareonService.java), [WaybillService](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/waybill/WaybillService.java), [WaybillDaoService](../../../db-layer/src/main/java/ru/korusconsulting/alis/model/waybill/WaybillDaoService.java), [waybill_view SQL](../../../db-layer/src/main/resources/db/changelog/rerunnable/view_waybill.sql), [initial Waybill migration](../../../db-layer/src/main/resources/db/changelog/v.1.33.0/v.1.33.0_20260127_KIS-2273_add_waybill_tables.sql) и [ExceptionAdvice](../../../web-layer/src/main/java/ru/korusconsulting/alis/exception/ExceptionAdvice.java).

## Дополнение 11.11.2026: связанные документы

[Основные и досылочные накладные](waybill-supplementary-as-is.md): новый GET /waybill/{id}/related-documents, типы связи 45/47, children в группировке, excluded и повторный импорт. Основной текст и схемы сверены с текущим кодом 12.11.2026; исполнение интеграции не проверялось.
