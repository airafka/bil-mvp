# Импорт товаров заявки из Excel (Авто СК): AS-IS

> Сверено с backend `dev`, commit `3d3899d5d` (11.11.2026). Учтены `8ee1ab684` (batchUnknown) и последующий возврат формы пяти warehouse-шаблонов в `c0724fd89`. Это **source-level реконструкция** (`SOURCE_CONFIRMED`, если не указано иное); импорт на стенде и тесты парсеров не запускались.

Документ покрывает загрузку товарных строк в существующую заявку склада (Авто СК) из Excel-шаблона. Правила товарной строки, которые применяются после разбора файла, описаны в [физической модели поставки](../database/receiving-order-good-as-is.md) и [вывоза](../database/shipping-order-good-as-is.md); проверка партии — в [валидации заявок](order-validation.md#партия-товарной-строки-уровень-3).

## HTTP-контур и шаблоны

| Действие | Endpoint | Право |
|---|---|---|
| Скачать шаблон | `GET /template/{uuid}/download?type=<TemplateReportType>` | `RECEIVING_ORDER:CREATE` или `SHIPPING_ORDER:CREATE` |
| Загрузить в поставку | `POST /template/receiving-order/upload` (multipart: `docType`, `id` заявки, `content`) | `RECEIVING_ORDER:WRITE` или `:CREATE` |
| Загрузить в вывоз | `POST /template/shipping-order/upload` | `SHIPPING_ORDER:CREATE` |

Источник: [`TemplateController`](../../../web-layer/src/main/java/ru/korusconsulting/alis/controller/template/TemplateController.java), [`ExcelTemplateCommonFileParsingService`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/parsing/order/ExcelTemplateCommonFileParsingService.java). Заявка должна быть в `DRAFT` или `ON_REVIEW`, иначе `IllegalArgumentException`.

Затрагиваемые шаблоны (`TemplateReportType`, файлы в [`templates/`](../../../web-layer/src/main/resources/templates/)):

| `TemplateReportType` | Название | Листы с данными | Парсер |
|---|---|---|---|
| `RECEIVING_ORDER_AUTO_WAREHOUSE_NOMENCLATURE` | Заявка на поставку Авто СК по номенклатуре | «Номенклатура» | [`ReceivingOrderAutoWarehouseNomenclatureParser`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/parsing/order/parser/impl/ReceivingOrderAutoWarehouseNomenclatureParser.java) |
| `RECEIVING_ORDER_AUTO_WAREHOUSE_WITHOUT_DETAIL` | … без детализации | «Номенклатура» | [`ReceivingOrderAutoWarehouseWithoutDetailParser`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/parsing/order/parser/impl/ReceivingOrderAutoWarehouseWithoutDetailParser.java) |
| `RECEIVING_ORDER_AUTO_WAREHOUSE_WITH_DETAIL` | … с детализацией | «Номенклатура», «Контейнеры» | [`ReceivingOrderAutoWarehouseWithDetailParser`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/parsing/order/parser/impl/ReceivingOrderAutoWarehouseWithDetailParser.java) |
| `SHIPPING_ORDER_AUTO_WAREHOUSE_NOMENCLATURE` | Заявка на вывоз Авто СК по номенклатуре | «Номенклатура» | [`ShippingOrderAutoWarehouseNomenclatureParser`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/parsing/order/parser/impl/ShippingOrderAutoWarehouseNomenclatureParser.java) |
| `SHIPPING_ORDER_AUTO_WAREHOUSE_WITH_DETAIL` | Заявка на вывоз Авто СК с детализацией | «Номенклатура», «Контейнеры» | [`ShippingOrderAutoWarehouseWithDetailParser`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/parsing/order/parser/impl/ShippingOrderAutoWarehouseWithDetailParser.java) |

Общая логика листа «Номенклатура» — [`NomenclatureParserSupport`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/parsing/order/parser/NomenclatureParserSupport.java), «Контейнеры» — [`AbstractAutoWarehouseWithDetailParser`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/parsing/order/parser/AbstractAutoWarehouseWithDetailParser.java). Шаблоны «по контейнерам» (`*_AUTO_WAREHOUSE_CONTAINER`) этим документом не покрываются.

## Порядок обработки

1. Структура файла ([`ValidateUtil.excelFileStructureValidate`](../../../web-layer/src/main/java/ru/korusconsulting/alis/utils/ValidateUtil.java)): лист «Инструкция» с типом шаблона, наличие листов, заголовки строки 1. Каждый заголовок должен входить в список допустимых колонок листа, иначе `Column.<Лист>.NotFound` (например, `Column.Nomenclature.NotFound`). С 13.10.2026 (`8ee1ab68`, KIS-4841) заголовок сначала сравнивается целиком и только при промахе — после отрезания хвоста по regex `[,*].*$` (раньше — сразу после отрезания; поэтому «Количество всего, план» превращалось бы в «Количество всего» и не распознавалось). Наличие **обязательных** колонок отдельно не проверяется (см. риски).
2. `validate` собирает ошибки всех строк; при непустом списке — один `ValidationException` (HTTP 400) с кодами через запятую, нормализованными `ValidateUtil.normalize` (сегменты `UPPER_SNAKE` → `CamelCase`).
3. `save` (`@Transactional` на парсере) создаёт строки через обычный `ReceivingOrderGoodService.add`/`ShippingOrderGoodService.add`, поэтому срабатывают статусная проверка, `OrderGoodBatchValidator` и пересчёт totals. `totalPrice = price × plannedQuantity` считает парсер. Ошибка любой строки откатывает весь импорт.

## Две ветки листа «Номенклатура»

Сверка 11.11.2026: ветка определяется наличием колонки «Номенклатура», а не возрастом файла. 8ee1ab684 ввёл восьмиколоночный шаблон с этой колонкой; c0724fd89 через два дня вернул пять warehouse-шаблонов к форме без неё, добавив «Партия неизвестна». Называть ветки просто «старой» и «новой» теперь вводит в заблуждение.

| Свойство | Без колонки «Номенклатура» (текущие пять warehouse XLSX) | С колонкой «Номенклатура» (шаблоны 8ee1ab684) |
|---|---|---|
| Поля | Артикул, Наименовании партии, Дата партионного учета, Штрихкод партии, Партия неизвестна, Количество план, Цена за 1 ед. изм. | №, Артикул, Номенклатура, Ед. изм., Партия, Партия неизвестна, Цена за 1 ед. изм., Количество всего план |
| Строка 2 | Подсказки, пропускается | Считалась примером данных, обрабатывается как данные |
| ClientGood | По combined item_code из «Артикул» | По «Артикул» + «Номенклатура» |
| Обязательные значения | Артикул, количество, цена | Дополнительно Номенклатура |
| Количество | TOTAL_COUNT_PLAN при наличии, иначе COUNT_PLAN | То же правило выбора колонки |
| Поле партии | BATCH при наличии, иначе BATCH_NAME | То же правило выбора колонки |
| Известная партия не найдена | Может создаться Batch с переданной датой; без валидной даты ошибка | Batch.NotFound, новая партия не создаётся |
| batchUnknown | Читается из BATCH_UNKNOWN, если колонка есть; иначе false | То же правило |

Парсер ищет активную номенклатуру клиента заявки, findFirst. Полностью пустые строки пропускаются. У helper getRowsBySheet собственная нумерация; код ошибки нельзя без проверки считать физическим Excel row number. Точные заголовки и внешние формулы текущих файлов — [бинарная сверка](../traceability/excel-template-diff-2026-11-11.md).

## Правила партии в обеих ветках

Партионный учёт в парсере означает `batchAccountingType != NOT_USED`. BatchUnknown принимает пусто, Да, Нет без учёта регистра. Да при отключённом учёте даёт BatchUnknown.NotValid; Да вместе с названием/датой/штрихкодом партии даёт ошибки соответствующих колонок. Без учёта и без Да заполненная партия игнорируется. При включённом учёте и без Да имя партии обязательно.

При Да строка сохраняется с batch=null, batchUnknown=true. Иначе партия ищется по коду/ClientGood/клиенту; наличие колонки «Номенклатура» запрещает её создание. В ветке без колонки при создании одна дата записывается и в manufactureDate, и в expirationDate, syncId генерируется. Это поведение кода, не подтверждение бизнес-смысла дат.

Общий OrderGoodBatchValidator строже формулирует допустимые типы: batchUnknown разрешён только для MANUFACTURE_DATE/EXPIRATION_DATE; одновременно batchUnknown и batch запрещены; для этих двух типов без batchUnknown партия обязательна. Таким образом `!= NOT_USED` в парсере и точный enum-набор валидатора нельзя считать одинаковым условием для будущих enum-значений.

## Лист «Контейнеры» (шаблоны с детализацией)

Лист содержит `Контейнеры* | Артикул* | Наименовании партии | Упаковка | Количество упаковок`, строка 2 — подсказки (пропускается), обязательны «Контейнеры» и «Артикул». Строка связывается с товаром по конкатенации «Артикул» + «Наименовании партии», без разделителя между этими двумя частями. Ключ должен совпасть с листом «Номенклатура»: при наличии одноимённой колонки это `<Артикул>_<Номенклатура>` + «Партия»; без неё — «Артикул» + «Наименовании партии». Несовпадение → `Containers.BatchName.NotValid.N` после нормализации.

Описанная ранее несогласованность ссылок на A/B относится к восьмиколоночной форме 8ee1ab684. После c0724fd89 в текущей форме A снова «Артикул», B — «Наименовании партии»; нельзя представлять прежний сдвиг как подтверждённый дефект текущих пяти файлов. Внешние формулы двух shipping-файлов остаются отдельным открытым риском — см. бинарную сверку.

AbstractAutoWarehouseWithDetailParser сначала сохраняет номенклатуру, затем строки грузов. Непустая «Упаковка» должна находиться как активная GoodPackage активной номенклатуры клиента заявки; иначе ошибка ClientGood/Package. Для поставки отсутствующий Cargo создаётся по коду, для вывоза выбирается первый найденный, отсутствие приводит к исключению. Обе реализации записывают packageQuantity из Excel, а totalQuantity, габариты, объём и вес первоначально задают нулём. Эти поля не вычисляются данным парсером из упаковок.

В отличие от номенклатуры, цикл «Контейнеры» не пропускает пустую строку отдельной проверкой isNotEmptyRow. Ключи товаров сохраняются в Map: повторный ключ заменяет ссылку для последующих грузов, хотя ранее добавленная товарная строка этим не удаляется. Коллизии конкатенации и повторные строки требуют проверки реальным импортом.

## Коды ошибок

Шаблоны до нормализации — `clientGoods.<КОЛОНКА>.<Тип>.<N>` ([`ConstantsMsg`](../../../web-layer/src/main/java/ru/korusconsulting/alis/utils/ConstantsMsg.java)); в ответе сегмент колонки в `CamelCase`.

| Код (после нормализации) | Условие | Форма |
|---|---|---|
| `clientGoods.Article.IsEmpty.N`, `.Nomenclature.IsEmpty.N`, `.TotalCountPlan.IsEmpty.N` / `.CountPlan.IsEmpty.N`, `.PriceForOne.IsEmpty.N` | Пустое обязательное поле; число `0` тоже считается пустым | обе; Nomenclature только при наличии колонки |
| `clientGoods.BatchUnknown.NotValid.N` | Недопустимое значение «Партия неизвестна» или `Да` без партионного учёта | обе |
| `clientGoods.Batch.NotValid.N` / `.BatchName.NotValid.N`, `.DateBatchAccounting.NotValid.N`, `.BatchBarcode.NotValid.N` | `Да` при заполненных данных партии | обе, по наличию колонки |
| `clientGoods.Batch.IsEmpty.N` / `clientGoods.BatchName.IsEmpty.N` | Учёт есть, партия не указана | по выбранной batch-колонке |
| `clientGoods.Batch.NotFound.N` / `.BatchName.NotFound.N` | Партия не найдена | с колонкой Номенклатура |
| `clientGoods.DateBatchAccounting.NotValid.N` | Партия не найдена и нет валидной даты для её создания | без колонки Номенклатура |
| `Column.<Лист>.NotFound` | Неизвестный заголовок колонки | обе |
| `OrderGood.*` | Срабатывание `OrderGoodBatchValidator` при сохранении (см. [каталог ошибок](order-errors.md)) | обе |

## Риски и вопросы

1. **Строка-пример импортируется в форме с колонкой «Номенклатура».** Подсказки текущих пяти файлов пропускаются; прежняя строка-пример в файле 8ee1ab684 проверяется как данные, если её не удалили.
2. **Форма с колонкой «Номенклатура» не создаёт партии.** Указанное имя несуществующей партии даёт ошибку поиска; завести её нужно заранее или указать «Партия неизвестна» при допустимом типе учёта. Текущая форма без колонки допускает создание партии по дате.
3. Коллизии ключа товара и поведение пустых строк «Контейнеры» — см. выше.
4. Отсутствие обязательной колонки (например, «Цена» в новой форме) структурной проверкой не ловится; ожидаемый итог — `NullPointerException` при `cells[columns.get(...)]` и HTTP 500 (`INFERENCE`).
5. Колонки «№» и «Ед. изм.» распознаются, но не читаются; единица измерения не сверяется с номенклатурой.
6. Парсер содержит обе ветки формы; срок поддержки каждого формата не определён.

## Целевая сверка бизнес-изменений 11.11.2026

Импорт справочника номенклатуры — отдельный контур, не описанный выше импорт товаров заявки. Его новая клиентская привязка: [ClientGood Excel](client-good-excel-import-as-is.md). Бинарные изменения пяти warehouse-шаблонов c0724fd89 проверены отдельно (ссылка ниже).

## Целевая сверка справочников и шаблонов 11.11.2026

Пять warehouse XLSX и три container/shipping XLSX сверены по OOXML. [Результат, колонки и внешние формулы](../traceability/excel-template-diff-2026-11-11.md).

## Границы тестового подтверждения KIS-4841

В 8ee1ab684 integration fixtures receiving/shipping goods начали создавать Batch и сохранять её ID при update. Два прежних generateDto-теста ItemReceivingTaskExportService/ItemShippingTaskExportService удалены вместе с assertions старого batch-контракта; это не новое покрытие batchUnknown. Все пять конкретных warehouse-парсеров передают batchUnknown в creation DTO, а ValidateUtil учитывает наличие колонки Номенклатура и при определении первой строки, и при проверке непустого файла. Новые parser/POI runtime-проверки в рамках аудита не выполнялись.

## Инкапсуляция сервисов (45e6620a1)

ExcelTemplateCommonFileParsingService теперь получает ReceivingOrderDaoService/ShippingOrderDaoService напрямую вместо getDaoService у бизнес-сервисов; загрузка getById и проверка статуса перед parser сохраняются. BasePageableService стал абстрактным классом с protected mapper/dao/filterEnrich, а page по-прежнему добавляет user restriction перед DAO-запросом. Удалён EntityTypeDaoServiceMapper. Новый публичный import-контракт этим рефакторингом не добавлен; не следует делать вывод о расширении client scope по смене DI.
