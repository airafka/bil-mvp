# Excel-импорт номенклатуры: привязка к клиенту

Сверено на `3d3899d5d`, 11.11.2026; AS_IS / SOURCE_CONFIRMED. Изменение 976343904 от 04.11.2026. Это импорт справочника ClientGood, а не импорт товаров в заявку. Среда и Java-тесты не запускались.

## Получение шаблона

`GET /template/{clientUuid}/client-good?type=CLIENT_GOOD_TEMPLATE` передаёт ID клиента в ReportService. Достаточно одного права CLIENT_GOOD/CREATE или CLIENT_GOOD/WRITE (`requireAll=false`). После JXLS-генерации ReportService открывает XLSX через Apache POI, создаёт лист `_alis_client`, записывает UUID клиента в A1 и делает лист VERY_HIDDEN. Для этого типа отчёта ID обязателен; прямой вызов без ID даёт IllegalArgumentException с текстом `Client ID is required for nomenclature template`. Ошибка записи metadata оборачивается в UncheckedIOException.

## Приём файла

`POST /template/client-good`, multipart ModelAttribute ExcelParsingFileDto, имеет те же альтернативные права. Выбранный клиент — parseDto.id. Последовательность: проверка структуры файла → ClientGoodExcelClientBinding.validate → проверка данных строк → save. При ошибке metadata до save дело не доходит.

| Metadata | Результат |
|---|---|
| Нет листа, первой строки, первой ячейки; значение null/blank | ValidationException: «В Excel-файле отсутствует информация о клиенте. Скачайте новый шаблон номенклатуры.» |
| A1 не совпадает с выбранным UUID без учёта регистра | ValidationException: «Excel-файл номенклатуры скачан для другого клиента. Выберите исходного клиента или скачайте новый шаблон.» |
| A1 совпадает | Продолжение прежней проверки и сохранения данных |

Строка metadata сравнивается с UUID.toString через equalsIgnoreCase: отдельного parse UUID нет; ExcelFileReader предварительно trim-ит STRING-ячейку. Старые шаблоны без листа отклоняются даже при корректных товарных строках; нужно скачать новый шаблон для выбранного клиента.

## Границы гарантии

Привязка защищает от случайной загрузки шаблона другого клиента. VERY_HIDDEN и незаверенная строка UUID не являются подписью или доказательством доступа пользователя к клиенту. Metadata можно изменить программно; client scope нужно подтверждать отдельной проверкой прав/фильтров. Эти изменения не доказывают атомарность всего импорта, дедупликацию товарных строк или обновление frontend.

В ClientGoodParsingServiceTest существующие сценарии успешного импорта/валидации адаптированы: helper записывает metadata выбранного клиента. Отдельных отрицательных тестов отсутствующего листа, чужого ID и проверки VERY_HIDDEN в просмотренном изменении нет. Исходники прочитаны без запуска. Контроль на стенде: новый шаблон того же клиента; старый шаблон; шаблон другого клиента; повреждённая metadata; отказ без новых записей в БД.

## Источники

- [TemplateController.java](../../../web-layer/src/main/java/ru/korusconsulting/alis/controller/template/TemplateController.java)
- [ReportService.java](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/report/ReportService.java)
- [ClientGoodExcelClientBinding.java](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/template/ClientGoodExcelClientBinding.java)
- [ClientGoodParsingService.java](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/parsing/nomenclature/ClientGoodParsingService.java)
- [ClientGoodParsingServiceTest.java](../../../web-layer/src/test/java/ru/korusconsulting/alis/service/parsing/nomenclature/ClientGoodParsingServiceTest.java)
