# Модель ошибок HTTP API: `AlisException` и `ApiErrorDto` AS-IS

> **Сверено:** backend `3d3899d5d` (12.11.2026) · **Основание:** `SOURCE_CONFIRMED` — исходный код, миграции и тесты (тесты не запускались); БД и стенд не проверялись.

Иерархия введена коммитами ce272f3e (KIS-4683), 8e9b494b/d24879c6 (KIS-4682), 575ae6b9 (KIS-4724) в сентябре 2026. Текущие advice/utils и классы исключений сверены отдельно; старый DbErrorContext overload удалён cleanup-коммитом 74c11bf96.

## Главный вывод: контракт ответа на wire не изменился

Обработчики возвращают ApiErrorDto с полями contextObject/errorMessage/errorCode через единый [ExceptionAdvice](../../../web-layer/src/main/java/ru/korusconsulting/alis/exception/ExceptionAdvice.java). Большинство использует [prepareErrorDto](../../../wms-layer/src/main/java/ru/korusconsulting/wms/controller/exception/ExceptionAdviceUtils.java); DataIntegrityViolationException создаёт DTO напрямую и заполняет только errorMessage. Новая иерархия AlisException не заменяет DTO массивом ErrorDetails, но меняет правила заполнения его полей и выбора HTTP-статуса. Наличие свойства в DTO не обещает непустое значение в каждом ответе.

## Два параллельных исключения-дерева

| Дерево | Базовый класс | С какого времени | Типичные представители | Как строится `ApiErrorDto` |
|---|---|---|---|---|
| Старое | [`WmsEntityException`](../../../wms-layer/src/main/java/ru/korusconsulting/wms/exception/WmsEntityException.java) (март 2025) | До этого периода | `IllegalStateWithCodeException` — используется повсеместно, включая `INVALID_STATUS` в `ReceivingOrderService.accept/reject`, `ShippingOrderService.accept/reject` | `errorCode = errorMessage = exception.getMessage()`; `contextObject` — из `exception.getContextObject()` |
| Новое | [`AlisException`](../../../wms-layer/src/main/java/ru/korusconsulting/wms/exception/AlisException.java) (KIS-4683, 9 сентября 2026) | Этот период | См. таблицу категорий ниже | См. раздел «Заполнение `ApiErrorDto`» |

Обе ветки не связаны наследованием и обрабатываются в `ExceptionAdviceUtils.fillDetails` раздельными `if/else`-ветками по типу исключения. Единой миграции старых `IllegalStateWithCodeException`-мест на новую иерархию в этом периоде не было — это два сосуществующих механизма, а не замена одного другим.

## Новая иерархия: категория → HTTP-статус

[`AlisException`](../../../wms-layer/src/main/java/ru/korusconsulting/wms/exception/AlisException.java) — абстрактный класс с обязательным непустым списком `List<ErrorDetails> errors` (`ErrorDetails` = `code` из `ApiErrorCode` + опциональные `field`/`params`) и абстрактным `getCategory(): ErrorCategory`. `ExceptionAdvice.resolveHttpStatus` мапит категорию на статус:

| `ErrorCategory` | HTTP-статус | Конкретный класс-исключение | Используется в production-коде? |
|---|---|---|---|
| `INVALID_REQUEST` | 400 | `InvalidRequestException` | **Нет** — класс существует, нигде не создаётся (`grep` по `new InvalidRequestException` не даёт совпадений в бизнес-коде) |
| `ACCESS_DENIED` | 403 | `AccessDeniedException` | Да — рефакторинг существовавшего класса; deprecated-конструкторы (`Secure`/`Secure[]`/`String context`) сохранены ради обратной совместимости вызывающего кода |
| `NOT_FOUND` | 404 | `NotFoundException` | Да — аналогично, рефакторинг существовавшего класса, deprecated-конструкторы (`Class+UUID`, `Class+String`, `String message`) сохранены |
| `CONFLICT` | 409 | `ConflictException` | **Нет** — не создаётся; фактический 409 для дублей по-прежнему идёт через отдельный `@ExceptionHandler({UniqueViolationException.class, DuplicateEntityException.class})`, не через `ConflictException` |
| `BUSINESS_RULE_VIOLATION` | **422** (`UNPROCESSABLE_ENTITY`) | `BusinessRuleViolationException` | **Нет** — класс существует, нигде не создаётся |
| `TECHNICAL` | 500 | `TechnicalException` | **Нет** — класс существует, нигде не создаётся |

**Вывод для ТЗ:** из шести подклассов `AlisException` реально бросаются только `AccessDeniedException` и `NotFoundException` — оба являются рефакторингом уже существовавших классов, поведение (403/404) не изменилось для их текущих вызывающих мест. Остальные четыре, включая единственный новый HTTP-статус `422`, — заготовка на будущее: ни один endpoint сейчас не возвращает `422` через этот механизм. Если ТЗ описывает бизнес-ошибки как `422`, нужно явно проверять, реализовано ли это на момент проверки, а не полагаться на факт существования класса.

## HTTP-статус типовых исключений заявок

`ExceptionAdvice` наследует ResponseEntityExceptionHandler: стандартные MVC-исключения проходят через его обработчики, а явные application handlers перечислены ниже. Остальные исключения попадают в `handleFallback` → **500**.

| Исключение | Где возникает в заявках | HTTP | `errorCode` / `errorMessage` |
|---|---|---|---|
| `jakarta.validation.ValidationException` | Accept-валидаторы, `OrderCombinationValidator`, consignee, партии, ЖД-поля поставки, accept заявки на услугу | 400 | `errorMessage` = текст (коды через `", "`), `errorCode` не заполняется |
| `MethodArgumentNotValidException` / `HandlerMethodValidationException` | Bean Validation request DTO | 400 | см. раздел Bean Validation ниже |
| `wms.AccessDeniedException` (`AlisException`, `ACCESS_DENIED`) | `@Secure`, `checkOrderStatusForUpdate` («Order can't be updated in status …»), `checkServiceOrderStatusForModification` | 403 | код `ErrorDetails` (по умолчанию `AccessDenied`) |
| Spring Security `AccessDeniedException` | фильтры безопасности | 403 | сообщение исключения |
| `NotFoundException` (`AlisException`, `NOT_FOUND`) | `findById` | 404 | код `ErrorDetails` (по умолчанию `NotFound`) |
| `UniqueViolationException`, `DuplicateEntityException` | дубли | 409 | сообщение исключения |
| `IllegalStateWithCodeException` (`WmsEntityException`) | `ReceivingOrder.InvalidStatus`, `ShippingOrder.InvalidStatus`, `ShippingOrder.RejectNotAllowed` | **500** (обработчика нет, fallback) | `errorCode = errorMessage = <код>`, `contextObject` из исключения |
| `IllegalStateException`, `IllegalArgumentException`, `InvalidParameterException`, `InvalidShippingOrderFillingTypeException`, NPE | accept заявки на услугу не из `DRAFT`, неверный `fillingType` для безномерных операций, несовпадение path/body id, переход рейса, update с `currency=null` | **500** | `errorMessage` = сообщение, `errorCode` пуст |
| `DataIntegrityViolationException` | нарушение constraint БД | 500 | `errorMessage = InternalError`, `errorCode` и `contextObject` не заполняются; детали только в логе |

Следствие для ТЗ: бизнес-ошибка недопустимого статуса транспортной заявки (`X.InvalidStatus`, `ShippingOrder.RejectNotAllowed`) приходит клиенту как HTTP 500, хотя содержит стабильный код. При accept через рейс она дополнительно оборачивается в `ValidationException` рейса и приходит как 400.

## Заполнение `ApiErrorDto` из `AlisException` — асимметрия при нескольких ошибках

[`ExceptionAdviceUtils.fillFromException(AlisException, ApiErrorDto)`](../../../wms-layer/src/main/java/ru/korusconsulting/wms/controller/exception/ExceptionAdviceUtils.java):

- **Один `ErrorDetails`** (частый случай): `errorMessage = errorCode = error.getCode()` — оба поля получают **один и тот же** код ошибки (например `"AccessDenied"`), а не человекочитаемое сообщение; `contextObject` собирается из `error.getParams()` и, если задан, `error.getField()`.
- **Несколько `ErrorDetails`** (`errors.size() > 1`): `errorMessage` = коды через `", "`, а **`errorCode` не устанавливается вовсе** (остаётся значением по умолчанию из конструктора `ApiErrorDto`, то есть `null`) — метод делает `return` раньше строки `dto.setErrorCode(...)`. `contextObject` в этом случае также не заполняется. Клиент API, ожидающий `errorCode` для программной обработки, для multi-error `AlisException` его не получит.

Это наблюдаемая асимметрия в текущем коде, не задокументированный явно контракт — открытый вопрос, ожидаемое ли это поведение для API-потребителей.

## Bean Validation (KIS-4724) — тоже не мигрировано на новую иерархию

Коммит `575ae6b9` («unify Spring Validation handling to legacy ApiErrorDto») правит [`ExceptionAdviceUtils.fillFromValidationErrors`](../../../wms-layer/src/main/java/ru/korusconsulting/wms/controller/exception/ExceptionAdviceUtils.java) для `MethodArgumentNotValidException`/`HandlerMethodValidationException`: берётся **последняя** ошибка из списка (`validationErrors.get(size - 1)`), `errorMessage` — её default message, `errorCode` — первый Spring validation code или тот же default message. Существует параллельный enum [`ValidationErrorCode`](../../../wms-layer/src/main/java/ru/korusconsulting/wms/error/code/ValidationErrorCode.java) (`Validation.NotNull`, `Validation.Size` и т.д., тоже добавлен в этот период) — он **нигде не используется** (`grep` не находит ссылок за пределами собственного файла). Bean Validation продолжает отдавать Spring-овские default messages/codes, а не эти новые коды.

## Каталог кодов: `CommonErrorCode` vs `order-errors.md`

[`CommonErrorCode`](../../../wms-layer/src/main/java/ru/korusconsulting/wms/error/code/CommonErrorCode.java) (`InternalError`, `InvalidRequest`, `AuthenticationRequired`, `AccessDenied`, `NotFound`, `MethodNotAllowed`, `Conflict`, `BusinessRuleViolation`) — это HTTP-уровневые generic-коды новой иерархии. Это **отдельный, не связанный** механизм от предметных бизнес-кодов заявок, описанных в [каталоге бизнес-ошибок](order-errors.md) (`X.MissingTransport`, `XContainer.MissingOwnerContainer` и т.п. — строковые константы `IllegalStateWithCodeException`/`ValidationException`, не реализующие `ApiErrorCode`). Не путать одно с другим при проверке ТЗ на конкретный код ошибки.

## Открытые вопросы

1. Планы по миграции `IllegalStateWithCodeException`/`ValidationException`-мест (включая весь `order-errors.md`) на `AlisException` — не source-level вопрос, нужен ответ у разработчиков.
2. Осознанность отсутствия `errorCode` для multi-error `AlisException`.
3. Судьба неиспользуемых `InvalidRequestException`/`ConflictException`/`BusinessRuleViolationException`/`TechnicalException`/`ValidationErrorCode` — заготовка для конкретной будущей задачи или общий рефакторинг «на будущее» без привязки к тикету.
4. Тесты (`*ExceptionAdvice*`, если есть) в рамках этой сверки не запускались.
5. [АНАЛИТИК] `IllegalStateWithCodeException` (коды `X.InvalidStatus`, `ShippingOrder.RejectNotAllowed`) и `IllegalStateException`/`IllegalArgumentException` отдаются как HTTP 500 — нужен ли для них 400/409/422?

## Целевая сверка безопасности и инфраструктуры 11.11.2026

Целевые файлы advice/utils повторно сверены. SecurityExceptionResolver сначала вызывает Bearer handler, затем MVC resolver: authentication→401, access denied→403 с legacy ApiErrorDto. [Точный путь и ограничения](security-and-integration-boundaries-as-is.md).

Общий BaseService с d24879c6e не оборачивает DataIntegrityViolationException в UniqueViolationException. Это существенно для конкурентных дублей и SQL constraints: 409 прикладной проверки и 500 SQL-конфликта не взаимозаменяемы.

## Контроль MVC и удаления старых исключений (d24879c6e)

handleExceptionInternal сохраняет statusCode и headers, переданные MVC-обработчиком, но заменяет body на legacy ApiErrorDto через prepareErrorDto. Наличие HTTP 406 в старом OpenAPI не означает прежнюю предметную ошибку ObjectNotModifiable/ObjectNotRemovable: эти классы и отдельный handler 406 удалены. Стандартная MVC-ошибка согласования представления — самостоятельный путь, который этим удалением не отменён.

Удалены также CupsClientException, NoInventoryFoundForNeedException и обе старые UnknownUserAuthorization-версии. Service/BaseService больше не обещают общий UniqueViolationException для каждой DB-ошибки; локальные application-проверки дублей остаются отдельными. ValidationException с cause строит ответ по непосредственной cause, а не обязательно по сообщению внешнего исключения. В ветке DataIntegrityViolationException prepareErrorDto не вызывается: конструктор ApiErrorDto(String) задаёт только errorMessage, поэтому errorCode нельзя считать равным InternalError.

Источники: [ExceptionAdvice](../../../web-layer/src/main/java/ru/korusconsulting/alis/exception/ExceptionAdvice.java), [ApiErrorDto](../../../wms-layer/src/main/java/ru/korusconsulting/wms/dto/ApiErrorDto.java), [BaseService](../../../wms-layer/src/main/java/ru/korusconsulting/wms/service/BaseService.java).

## Контроль иерархии ce272f3ee на 11.11.2026

AlisException требует непустой список errors и сохраняет List.copyOf; null/пустой список не являются допустимым экземпляром ошибки. ErrorDetails требует непустой code, field либо NULL либо непустой, params копируется в Map.copyOf. DTO HTTP не заменён на ErrorDetails-массив — прежнее преобразование в ApiErrorDto остаётся отдельным слоем. Продуктовые коды строковых ValidationException от этого автоматически не становятся ApiErrorCode.
