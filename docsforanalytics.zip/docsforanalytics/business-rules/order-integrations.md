# Интеграционные эффекты заявок

> **Сверено:** backend `3d3899d5d` (13.11.2026) · **Основание:** `SOURCE_CONFIRMED` — исходный код, миграции и тесты (тесты не запускались); БД и стенд не проверялись.

При успешном accept транспортной заявки (вызывается из accept рейса) формируются строки `OutboundData` по конфигурации `OutboundConfigService` (хранится в Java-коде), если для заявки не включён route chain package. Конкретный набор корневых объектов зависит от `MessageType`.

| Сторона | Route chain package включён (outbound заявки **не** пишется), когда |
|---|---|
| Поставка | `CONTAINER + RAILWAY` и `RECEIVING_AND_SHIPPING_RAILWAY_ROUTE_CHAIN_PACKAGE_ENABLED=true`; `CONTAINER + VEHICLE` и `RECEIVING_AUTO_ROUTE_CHAIN_PACKAGE_ENABLED=true` |
| Вывоз | `CONTAINER` (любой транспорт, в т.ч. авто) и `RECEIVING_AND_SHIPPING_RAILWAY_ROUTE_CHAIN_PACKAGE_ENABLED=true` |

Оба флага по умолчанию `false` (`application.yaml`); значения на стендах не проверялись (`OPEN_QUESTION` [ОКРУЖЕНИЕ]). Для `WAREHOUSE` route chain package не применяется. Полный разбор четырёх типов route chain package (что собирают, по какому крону, известные дефекты) — в [route-chain-package-export-as-is.md](route-chain-package-export-as-is.md).

## Поставка

До формирования исходящих сообщений ЖД-состав поставки может быть загружен через публичный `POST /datareon/waybill`. Новая накладная создаёт Waybill/WRC/WC/Product/ZPU и находит существующие справочные вагоны/КТК без изменения либо создаёт отсутствующие; повтор существующего `waybill_identifier` обновляет status, непустой type, связи и товары (сверка 11.11.2026 — [досылочные](waybill-supplementary-as-is.md)). `MessageId` не используется для дедупликации, а текущая read model — обычная waybill_view без async refresh. Полный разбор: [Waybill и входящий ЭТРАН](waybill-etran-as-is.md).

Отдельные публичные `POST /datareon/etran_railway` и `/etran_container` выполняют пакетный patch-upsert глобальных справочников вагонов и КТК. Их DTO, обязательность, разрешение type/model/ISO, повтор, транзакция и ошибки описаны в [актуальном backend AS-IS справочников ЭТРАН](etran-reference-imports-as-is.md). Преобразования на стороне Datareon этим репозиторием не подтверждаются.

Публичные `POST /datareon/container-remain` и `/railway-carriage-remain` загружают отдельные клиентские снимки остатков. Они не являются справочным импортом и не создают `ContainerMovement`: ключи, частичный успех, журналы, ручной delete-and-reload и read views разобраны в [актуальном inbound AS-IS остатков](remain-inbound-as-is.md).

`POST /datareon/remain` аналогично загружает остатки номенклатуры, но разрешает `ClientGood`, производную упаковку, Batch, Cargo, zone и фиксированную площадку, не создавая `GoodMovement`. Фактическая обязательность полей, partial success, full sync и read model описаны в [AS-IS остатков товаров](good-remain-inbound-as-is.md).

Используемые остатками Batch заранее создаются/обновляются через `POST /datareon/batch`. Этот endpoint ищет партию по ClientGood+code, способен заменить её `syncId`, игнорирует входной `active` и коммитит каждый элемент отдельно; полный разбор — [Партии товаров и Datareon](batch-datareon-as-is.md).

Отдельный контур занятости склада запускается через `GET /cell-occupancy/update`, очищает прежний снимок после успешного запроса Datareon и затем принимает строки через `POST /datareon/cell-occupancy`. Это не update по ключу и не атомарный replace; DTO, VGH, состояние, повторы и physical table описаны в [AS-IS занятости складских ячеек](cell-occupancy-datareon-as-is.md).

`POST /datareon/contractor` преобразует контрагента ЭДО в Client, ищет его по case-insensitive `edoId` и при create ставит Client в обратную outbound-очередь `CONTRACTOR`. Текущий повтор существующего ID не является успешным upsert: неполный update mapping передаёт `code=null` и откатывается на physical `NOT NULL`. Полная трассировка — [Контрагенты ЭДО и Datareon](contractor-edo-datareon-as-is.md).

Следующий отдельный `POST /datareon/contract` разрешает Client/Company по `edoId`, Currency по code и всегда создаёт новый Contract: lookup/update по `_id` отсутствует, поэтому точный повтор создаёт дубль. Даты, create transaction, physical constraints, ошибки и отличие от проектного объединённого метода описаны в [Договоры ЭДО и Datareon](contract-edo-datareon-as-is.md). Company/Currency доступны в backend только для чтения; отсутствие обнаруженного загрузчика, duplicate/blank semantics и зависимость договора раскрыты в [AS-IS prerequisites справочников](company-currency-contract-prerequisites-as-is.md).

| MessageType | Площадка | Объекты для исходящей обработки |
|---|---|---|
| `RECEIVING_TRANSPORT_MANIFEST` | любая | **Обновлено KIS-4093** (24.09.2026, `ReceivingOrderTransport` удалена — см. [DEPRECATED-заметку](../database/receiving-order-transport-as-is.md)): корневая `ReceivingOrder` (если `TransportType=VEHICLE` и заявка привязана к `Route`) + уникальные `WaybillRailwayCarriage` |
| `CARGO_RECEIVING_TASK` | `WAREHOUSE` | корневая `ReceivingOrder` |
| `CARGO_RECEIVING_TASK` | `CONTAINER` | неудалённые `ReceivingOrderContainer` |
| `ITEM_RECEIVING_TASK` | `WAREHOUSE` | корневая `ReceivingOrder`. Блок `items[].batch` ([`ItemReceivingTaskExportService.getBatchDto`](../../../web-layer/src/main/java/ru/korusconsulting/alis/datareon/service/receiving/itemreceivingtask/ItemReceivingTaskExportService.java)) с 13.10.2026 (`8ee1ab68`, KIS-4841): у товара с `batchAccountingType=NOT_USED` — `{"batchUnknown": false}` без данных партии, даже если в строке есть партия; у строки `batchUnknown=true` — `syncId=00000000-0000-0000-0000-000000000000`, `type` из `ClientGood`, `number`/`issueDate`/`expirationDate`/`barcode` = `""`, `batchUnknown: true`; иначе данные партии + `batchUnknown: false`, причём партия обязательна (`Objects.requireNonNull`): старая строка с учётом, но без партии, роняет экспорт NPE. Раньше: нет партии → `{}`, иначе данные партии без признака. |
| `ITEM_RECEIVING_TASK` | `CONTAINER` | ничего — сообщение не требуется |
| `CONFIRM_DOCS` | применимый сценарий | все `ReceivingOrderContainer` поставки (`findAllByReceivingOrder`); строки пишутся напрямую сервисом, минуя `OutboundConfigService` |

Вагоны transport manifest берутся через накладные и схлопываются по `railwayCarriage.id`: в outbound попадает одна репрезентативная строка на уникальный вагон.

`CONFIRM_DOCS` создаётся не при accept, а после однократного `confirm-document`/`unconfirm-document`.

Входящие `TOS_RECEIVING_RESULT`, `WMS_RECEIVING_RESULT`, `CARRIAGE_ARRIVED`, `STATUS_IN_WORK` и `STATUS_COMPLETED` сведены в [карту действий поставки](receiving-inbound-actions.md). Она различает прямые контейнеры и задачи Waybill, фактическое время, товары/услуги, смену владельца и три независимых способа получить `DONE`.

## Вывоз

| MessageType | Площадка | Объекты для исходящей обработки |
|---|---|---|
| `SHIPMENT_TRANSPORT_MANIFEST` | любая | **Обновлено KIS-4093** (24.09.2026, `ShippingOrderTransport` удалена — см. [DEPRECATED-заметку](../database/shipping-order-transport-as-is.md)): корневая `ShippingOrder` (если `TransportType=VEHICLE` и заявка привязана к `Route`) + неудалённые `ShippingOrderRailwayCarriage` |
| `CARGO_SHIPMENT_TASK` | `CONTAINER` | неудалённые `ShippingOrderContainer`. Прямой `addConfig(SHIPPING_ORDER_CONTAINER, CARGO_SHIPMENT_TASK)` в `OutboundConfigService` закомментирован — строка активна только потому, что триггерится через `EntityType.SHIPPING_ORDER`, а `getListOfEntitiesToOutbound` для этого `MessageType`+`CONTAINER` сам подгружает `ShippingOrderContainer` как sibling-строки. `ownerContainerId` в параллельном route chain package для той же заявки был всегда `null` с 22.09 по 08.10.2026; KIS-4830 стал заполнять `ShippingOrderContainer.ownerContainer` снимком из registry — см. [регистр остатков и владельца КТК](container-remains-and-owner-as-is.md#владелец-на-строке-вывоза-kis-4830); в `CargoShipmentTaskDto` поля владельца КТК нет. |
| `CARGO_SHIPMENT_TASK` | `WAREHOUSE` | пустой список; в коде помечено «на проработке аналитиками» |
| `ITEM_SHIPMENT_TASK` | `WAREHOUSE` | корневая `ShippingOrder`. Блок партии товара ([`ItemShippingTaskExportService.getBatch`](../../../web-layer/src/main/java/ru/korusconsulting/alis/datareon/service/shipping/itemshippingtask/ItemShippingTaskExportService.java), DTO `ShipmentTaskItemBatchDto`) с 13.10.2026 (`8ee1ab68`, KIS-4841) формируется по тем же трём веткам, что у `ITEM_RECEIVING_TASK`: `NOT_USED` → `{"batchUnknown": false}`; `batchUnknown=true` → нулевой UUID, `type` из `ClientGood`, пустые строки, `batchUnknown: true`; иначе данные партии + `false`, а отсутствие партии у товара с учётом — NPE экспорта. Раньше: нет партии → `{}`. |
| `ITEM_SHIPMENT_TASK` | `CONTAINER` | ничего — сообщение не требуется |

Пустой warehouse cargo shipment — зафиксированный пробел текущей реализации. Новое ТЗ должно явно определить, нужен ли этот пакет и его гранулярность.

Входящий сценарий `POST /datareon/event` с действием `CARRIAGE_ARRIVED`, который завершает вагонную задачу ЖД-вывоза, разобран отдельно: [завершение порожнего ЖД-вывоза без КТК](shipping-railway-empty-completion.md). В нём различены HTTP-успех, статус журнала события и статус самой заявки.

Остальные shipping-actions того же endpoint — `TOS_SHIPMENT_RESULT`, `WMS_SHIPMENT_RESULT`, `VH_DEPARTURE` и `STATUS_COMPLETED` — сведены в [карту входящих действий вывоза](shipping-inbound-actions.md). Там зафиксированы их разные условия `DONE`, изменения движений/владельцев и конфликты нескольких config-строк для одного события.

## Заявка на услугу

После успешной смены владельцев формируется `SERVICE_ORDER_CHAIN_PACKAGE` с корневой `ServiceOrder`.

Строка outbound создаётся в той же транзакции, что владельцы, история, `DONE` и `completionAt`. Отдельный планировщик строит пакет из актуальных на момент отправки ServiceOrder/ServiceOrderContainer/Container/Client и отправляет его в `${datareon.base.url}/serviceOrder`; доступны до пяти попыток. Полный AS-IS и риск повторной внешней обработки разобраны в [lifecycle сервисной заявки](service-order-lifecycle.md#outbound-пакет).

## События изменения статуса

Полный основной lifecycle рейса — создание, назначение/снятие заявок, review/accept/reject, автоматическая агрегация статуса и выбор route outbound — описан в [AS-IS рейсов](route-lifecycle-as-is.md). В частности, повторный accept может повторно поставить outbound, а assign/unassign не защищают принадлежность заявки другому рейсу.

DAO транспортных заявок сравнивает текущий статус с закэшированным `previousStatus` и публикует `ReceivingOrderStatusChangedEvent` или `ShippingOrderStatusChangedEvent`. Слушатели:

- синхронизируют статус связанного маршрута до commit;
- передают изменение в контур уведомлений;
- при отсутствии route ID пропускают синхронизацию маршрута. ReceivingOrderListener до этого guard и вне catch пересчитывает category накладных; ошибка category может прервать commit.

## Что обязательно определить в новом ТЗ

- момент постановки в outbound: до/после commit;
- root object и гранулярность строк;
- ключ идемпотентности и правила повторной доставки;
- поведение при пустом наборе дочерних объектов;
- взаимодействие обычного outbound с route chain package;
- влияние отмены или повторного accept на ранее созданные строки.

Связанные модели: [OutboundData](../entities/catalog/entities/outbounddata/OutboundData.md), [типы заявок](order-types.md), [статусы](order-statuses.md).

## Уведомление о неизвестном номере КТК

[ApplicationStatusNotificationListener](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/notification/ApplicationStatusNotificationListener.java) обрабатывает status changed events AFTER_COMMIT. Условие — точный переход DRAFT→ACCEPTED; ON_REVIEW→ACCEPTED сюда не подходит. Это изменение 9a05f552e: прежний триггер DRAFT→ON_REVIEW заменён вместе с удалением review mappings.

Для обеих сторон дополнительно требуются ktkNumberUnknown=true у заявки, площадка CONTAINER, VEHICLE и непустой набор прямых неудалённых строк с ktkNumberUnknown=true. При отсутствующем номере заявки отправка пропускается. Listener создаёт ApplicationNotificationDto с id, number, typeRequest=receiving_order/shipping_order и typeNotice=without_container_number. Собранные UUID дочерних строк в этот DTO не включаются: параметр containerIds используется для logging count. Все Exception в обработке/отправке ловятся и логируются; уже завершённую транзакцию заявки ошибка отправки не откатывает. Фактическая доставка и повторы внешнего сервиса этим чтением не проверены.

## Отмена поставки и вывоза

> Этот раздел отдельно сверен на `3d3899d5d` (11.11.2026); дата в шапке относится к остальным разделам.

С 22.10.2026 отмена из `ACCEPTED` на `CONTAINER` сохраняет JSON в `outbound_data.payload` и создаёт `RECEIVING_ORDER_CANCEL` / `SHIPPING_ORDER_CANCEL`. Отправка использует этот снимок. Из `IN_PROGRESS`/`DONE` требуется дополнительное право, сообщение отмены не создаётся. Условия, транзакции, retry, resend и открытые вопросы — [полный AS-IS отмены](../integrations/order-cancellation-outbound-as-is.md).
