# Route chain package export: 4 пакета в Datareon AS-IS

> **Сверено:** backend `3d3899d5d615ae4ec1edb10bfa7a8a8bd0f2dcde` (13.11.2026) · **Основание:** `SOURCE_CONFIRMED` — исходный код, миграции и тесты (тесты не запускались); БД и стенд не проверялись.

Документ описывает отправляющую сторону четырёх пакетов: выбор пакета — в [lifecycle рейса](route-lifecycle-as-is.md), обычный outbound — в [интеграционных эффектах](order-integrations.md), отмена со снимком — в [отмене заявок](../integrations/order-cancellation-outbound-as-is.md).

**Каталожный пробел:** все четыре DTO (`ShippingRouteChainPackageDto`, `ReceivingAutoRouteChainPackageDto`, `ReceivingRailwayRouteChainPackageDto`, `ServiceOrderChainPackageDto`) находятся в пакете `ru.korusconsulting.alis.datareon.dto.*`, а не `ru.korusconsulting.alis.dto.*`. Генератор [`generate_dto_docs.py`](../scripts/generate_dto_docs.py) сканирует только `DTO_ROOTS = web-layer/.../ru/korusconsulting/alis/dto` — весь пакет `datareon.dto` (включая эти четыре DTO и другие outbound-контракты Datareon) исключён из автогенерируемого каталога `dto/catalog/`. Это касается не только route chain package — стоит сообщить мейнтейнеру генератора отдельно.

## Общий движок: `BaseExportService` + `OutboundData`

Все четыре типа (и вообще все outbound-сообщения Datareon, не только route chain package) используют один [`BaseExportService.exportNextEntity`](../../../web-layer/src/main/java/ru/korusconsulting/alis/datareon/service/BaseExportService.java):

1. Выбирается **одна** строка `OutboundData` с `success != TRUE`, `attempts < 5`, сортировка `createdAt DESC` — то есть **сначала обрабатывается самая новая** неотправленная строка, а не FIFO. При постоянном потоке новых строк одного `messageType` старая застрявшая строка теоретически может годами не доходить до головы очереди — открытый вопрос, а не подтверждённый инцидент.
2. Для найденной строки ищутся **все прочие** строки с тем же `(messageType, rootObjectId)`, `success != TRUE`, `attempts < 5` и прошедшим backoff — то есть все готовые к отправке сообщения того же корневого объекта того же типа схлопываются в одну попытку.
3. Предпринимается блокировка найденных UUID через `findAndLockSkipLocked`: далее участвуют только реально заблокированные строки. SQL `SKIP LOCKED` может вернуть подмножество или пустой список без ожидания чужих блокировок.
4. Строится DTO из первой реально заблокированной строки (`toDto(outboundData)`). Для четырёх обычных пакетов ниже это текущее состояние DAO по `rootObjectId`. Обобщать правило на все `BaseExportService` нельзя: cancellation читает сохранённый `OutboundData.payload`. У группы нет сравнения payload и гарантии порядка строк; нюансы схлопывания снимков — в [описании outbound_data](../database/outbound-data-as-is.md).
5. Один HTTP POST в Datareon (`entityDatareonRestService.getContent(entityDto)`); ответ ожидается как **голый UUID** в теле (`UUID.fromString(response.getBody())`) — записывается как `messageId`.
6. После HTTP для каждой заблокированной строки выставляются `success=true`, response code/message ID и вызывается `updateAttempt`; затем выполняется `postExport`. В `catch Throwable` для реально заблокированных строк устанавливаются `success=false`, `errorMessage=e.getMessage()` и снова вызывается `updateAttempt`. Поэтому ошибка до первого update даёт одно увеличение attempts, а ошибка `postExport` после него — два вызова увеличения в одной попытке. Успешно принятый Datareon пакет может отправиться повторно; итог сохранения при ошибке зависит также от состояния транзакции. Это вывод по коду, не воспроизведение стенда.
7. Backoff линейный: [`ExpiredCondition`](../../../db-layer/src/main/java/ru/korusconsulting/alis/filter/outbounddata/ExpiredCondition.java) — строка становится «просроченной» (готовой к retry), когда `(минут с last_attempt_at) > 5 × attempts`. Максимум 5 попыток (`MAX_ATTEMPT_NUMBER`), дальше строка навсегда остаётся `success=false` без дальнейших попыток и без отдельного алертинга (см. также снятый в этом периоде datareon-мониторинг, [integrations/README.md](../integrations/README.md#обновление-29-сентября-2026-мониторинг-datareon-удалён-появился-stub-контур)).

Модель — `OutboundData`: `messageType`, `entityType`, `rootObjectId`, `payload`, `success`, `messageId`, `responseCode`, `errorMessage`, `attempts`, `lastAttemptAt`. `payload` — nullable TEXT со снимком JSON отмены; для обычных live-build пакетов ниже он не используется. [Физическая схема и жизненный цикл](../database/outbound-data-as-is.md).

## Планировщики: fixed delay 5 секунд, drain-цикл

Каждый из четырёх типов запускается собственным `Scheduled*ExportService` с `@Scheduled(fixedDelayString = ...)` (не cron-выражение, а простой fixed delay — следующий запуск через N мс **после завершения** предыдущего, не по расписанию). Все четыре интервала в [`application.yaml`](../../../web-layer/src/main/resources/application.yaml) одинаковы — **5000 мс**:

```yaml
datareon:
  cron:
    shippingRouteChainPackage: 5000
    receivingRailwayRouteChainPackage: 5000
    receivingAutoRouteChainPackage: 5000
    serviceOrderChainPackage: 5000
```

Каждый тик — `while (exportNextEntity(type) != null) {}` (с комментарием `// todo` в shipping- и receiving-railway-планировщиках) — то есть один тик вычерпывает **всю** очередь данного `MessageType` до пустого результата, а не одну строку за раз.

## Четыре типа: root-объект, endpoint, что собирается

| Тип | `MessageType` | Root-объект | REST endpoint (`${datareon.base.url}` + …) | Условие срабатывания |
|---|---|---|---|---|
| Shipping | `SHIPPING_ROUTE_CHAIN_PACKAGE` | `Route` | `/shippingOrderContainer` | `CONTAINER` + `SHIPPING` + `receivingAndShippingRailwayRouteChainPackageEnabled` |
| Receiving Railway | `RECEIVING_RAILWAY_ROUTE_CHAIN_PACKAGE` | `Route` | `/receivingOrderContainer` | `CONTAINER` + `RECEIVING` + `RAILWAY` + `receivingAndShippingRailwayRouteChainPackageEnabled` |
| Receiving Auto | `RECEIVING_AUTO_ROUTE_CHAIN_PACKAGE` | `Route` | `/receivingOrderAutoContainer` | `CONTAINER` + `RECEIVING` + `VEHICLE` + `receivingAutoRouteChainPackageEnabled` |
| Service order | `SERVICE_ORDER_CHAIN_PACKAGE` | **`ServiceOrder`**, не `Route` | `/serviceOrder` | после успешной смены владельцев (см. [lifecycle сервисной заявки](service-order-lifecycle.md#outbound-пакет)) |

**Название endpoint'а не соответствует имени Java-класса**: `ShippingRouteChainPackageDatareonRestService` шлёт на `/shippingOrderContainer`, `ReceivingRailwayRouteChainPackageDatareonRestService` — на `/receivingOrderContainer` (без «Railway» в пути), `ReceivingAutoRouteChainPackageDatareonRestService` — на `/receivingOrderAutoContainer`. При чтении access/error логов Datareon по URL это стоит держать в уме — путь не подсказывает, какой из трёх «receiving/shipping»-вариантов это был.

Условия срабатывания (feature flags, `TerminalArea`/`RouteType`/`TransportType`) подробно разобраны в [route-lifecycle-as-is.md](route-lifecycle-as-is.md#outbound-после-accept) — здесь не дублируются.

### Shipping (`ShippingRouteChainPackageExportService`)

Собирает все найденные `ShippingOrder` рейса (`shippingOrderDaoService.findAllByRoute`) и по каждой — `ShippingOrderRailwayCarriageQty`, `ShippingOrderRailwayCarriage`, `ShippingOrderContainerQty`, `ShippingOrderContainer`, `ShippingOrderContainerItem`, `ShippingOrderEtsngCode` (через qty КТК). Выбор модели по `fillingType` здесь не выполняется: сохранённые строки обеих моделей могут войти в один пакет. Справочники дедуплицируются по non-null UUID. `Client[]` собирается только из `ShippingOrder.client`; владельцы номерных КТК и `ownerClient` qty отдельно в него не добавляются. Если владелец не является клиентом какой-либо заявки рейса, его UUID есть в задачах, а карточки в `Client[]` нет. `clientDriver`/`clientVehicle` берутся только с `Route`.

`postExport`: **все** `ShippingOrderRailwayCarriage` и `ShippingOrderContainer` **всех** заявок рейса переводятся в `TaskStatus.UPLOADED` одним циклом — безусловно, без проверки текущего статуса: уже `UPLOADED` и даже уже `FINISHED` (после TOS-результата) задачи при повторной отправке пакета рейса получат `UPLOADED` (`INFERENCE`: откат завершённой задачи, если пакет рейса повторно ставится в очередь после начала исполнения). Точечного различения «что реально нового в этом пакете» нет. То же относится к `postExport` receiving-пакетов.

**Владелец номерного КТК (`containerOwnerId`).** Текущее поле пакета берётся из `ShippingOrderContainer.containerOwner`, снимка `Client`. Исторически в сентябре–октябре 2026 оно не заполнялось, затем было исправлено KIS-4830; позднее переименовано. Снимок также синхронизируется при смене владельца для DRAFT/ON_REVIEW, поэтому утверждение «только после смены КТК в строке» уже неверно. Для qty отдельное поле `containerOwner` заполняется `ownerClient.getId()` без null-guard: legacy NULL может сорвать сборку. [Текущие правила владельцев](shipping-container-owners-as-is.md).

#### Поля (JSON-контракт `ShippingRouteChainPackageDto`)

Источник: [`ShippingRouteChainPackageDto.java`](../../../web-layer/src/main/java/ru/korusconsulting/alis/datareon/dto/routechainpackage/ShippingRouteChainPackageDto.java). Корневые поля сериализуются с `@JsonProperty` в PascalCase (`Route`, `ShippingOrder`, `ShippingOrderContainer` и т.д.) — это буквальные ключи JSON, который получает Datareon; вложенные поля — как есть (camelCase), кроме отдельно отмеченных.

| `Route` (объект, 1) | Тип | |
|---|---|---|
| `id` | UUID | |
| `number` | Long | |
| `routeType` | enum `RouteType` | |
| `dataTime` | Instant | |
| `terminalArea` | String | код площадки |
| `transportType` | enum `TransportType` | |
| `clientRelatedEntityId` | UUID | перевозчик |
| `clientDriverId` | UUID | |
| `clientVehicleId` | UUID | |
| `comment` | String | |
| `status` | enum `RouteStatus` | |

| `ShippingOrder[]` | Тип | |
|---|---|---|
| `id`, `number`, `orderStatus` | UUID, Long, enum `OrderStatus` | |
| `clientId`, `contractId`, `currencyId` | UUID | |
| `terminalArea` | String | |
| `transportType` | enum `TransportType` | |
| `plannedShippingDateTime`, `actualShippingDateTime` | Instant | |
| `contactName`, `contactPhone`, `contactEmail` | String | из `shippingOrder.getContact()`, `null` если контакт не задан |
| `comment` | String | |
| `totalSKUQuantity` | Long | `@JsonProperty("totalSKUQuantity")` — историческое имя с капс `SKU` |
| `totalWeight`, `totalGoodsPrice`, `totalRequestedServicePrice` | BigDecimal | |
| `totalCargoQuantity`, `totalPalletQuantity`, `totalNotPalletQuantity`, `totalRequestedServiceQuantity`, `totalContainerQuantity` | Long | |
| `deliveryType` | enum `ShippingOrderDeliveryType` | |
| `routeId` | UUID | |
| `needTransport` | Boolean | |
| `consigneeAddress` | String | |
| `ktkNumberUnknown` | Boolean | |
| `fillingType` | enum `ShippingOrderFillingType` | |

| `ShippingOrderRailwayCarriageQty[]` | Тип |
|---|---|
| `id`, `shippingOrderId`, `typeId` | UUID |
| `quantity` | Integer |

| `ShippingOrderRailwayCarriage[]` | Тип |
|---|---|
| `id`, `etranInvoiceId`, `railwayCarriageId`, `shippingOrderId`, `customerServiceId`, `ownerRailwayCarriageId` | UUID |
| `status` | enum `TaskStatus` |
| `dataTimeKrugloyePole` | Instant |

| `ShippingOrderContainerQty[]` | Тип |
|---|---|
| `id`, `shippingOrderId`, `containerOwner` | UUID; `containerOwner` из qty.ownerClient |
| `quantity` | Integer |
| `type` | String (`.name()` enum'а типа контейнера) |
| `empty` | Boolean |

| `ShippingOrderContainer[]` | Тип | |
|---|---|---|
| `id`, `shippingOrderId`, `containerId`, `shippingOrderRailwayCarriageId`, `sealTypeId`, `dangerClassId`, `customerServiceId`, `ownerRailwayCarriageId` | UUID | |
| `containerOwnerId` | UUID | снимок `Client` из `ShippingOrderContainer.containerOwner`; nullable |
| `empty`, `customsClearance`, `random`, `ktkNumberUnknown` | Boolean | |
| `weight`, `actualQuantity` | BigDecimal | |
| `status` | enum `TaskStatus` | |
| `dataTimeKrugloyePole` | Instant | |

| `ShippingOrderContainerItem[]` | Тип |
|---|---|
| `id`, `shippingOrderId`, `shippingOrderContainerId`, `etsngCodeId` | UUID |
| `description` | String |
| `price`, `weightGross`, `weightNet`, `quantityPlace` | BigDecimal |

| `ShippingOrderEtsngCode[]` | Тип |
|---|---|
| `id`, `shippingOrderContainerQtyId`, `etsngCodeId` | UUID |
| `weight` | BigDecimal |

| `Client[]` | Тип |
|---|---|
| `id`, `syncId` | UUID |
| `code`, `name`, `inn`, `kpp`, `okpo`, `ogrn`, `edoId`, `addressLegal`, `addressFact`, `signatoryName`, `signatoryPosition`, `email`, `phoneNumber` | String |
| `active` | Boolean |

| `Contract[]` | Тип | |
|---|---|---|
| `id`, `syncId`, `clientId`, `companyId`, `currencyId` | UUID | |
| `code`, `name`, `edoId`, `contractNumber` | String | `contractNumber` заполняется значением `Contract.code` (отдельная колонка номера удалена KIS-4162) |
| `active` | Boolean | |
| `contractDate`, `validFrom`, `validTo` | Instant | |
| `contractType` | enum `ContractType` | |

| `RailwayCarriage[]` | Тип |
|---|---|
| `id`, `typeId`, `modelId` | UUID |
| `code` | String |
| `active` | Boolean |
| `liftingCapacity` | BigDecimal |
| `dateDepotRepair` | Instant |

| `Container[]` | Тип |
|---|---|
| `id`, `standardSizeId`, `containerTypeIso` | UUID; последнее поле ссылается на `ContainerTypeIso[]` |
| `code` | String |
| `active`, `refrigerator` | Boolean |
| `containerType` | String (`.name()`) |
| `weight`, `liftingCapacity` | BigDecimal |

| `EtsngCode[]` | Тип |
|---|---|
| `id` | UUID |
| `code`, `name` | String |
| `active` | Boolean |

| `RailwayCarriageType[]` | Тип |
|---|---|
| `id` | UUID |
| `code` | String |
| `active` | Boolean |
| `teu` | Integer |

| `ClientDriver[]` (0 или 1 элемент, только с `Route`) | Тип | |
|---|---|---|
| `id`, `syncId`, `clientId` | UUID | |
| `code`, `phoneNumber`, `passportNumber`, `passportIssuedBy`, `drivingLicenseNumber` | String | |
| `active` | Boolean | |
| `passportIssuedDate`, `drivingLicenseIssuedDate` | Instant | |
| `POANumber` | String | `@JsonProperty("POANumber")`, не `poaNumber` |
| `POAValidTo` | Instant | `@JsonProperty("POAValidTo")` |

| `ClientVehicle[]` (0 или 1, только с `Route`) | Тип |
|---|---|
| `id`, `syncId`, `clientId`, `vehicleBrandId`, `vehicleTypeId`, `loadingTypeId` | UUID |
| `code`, `trailerNumber`, `insuranceNumber` | String |
| `active`, `refrigerator`, `withTrailer` | Boolean |
| `typeOwnershipTransport` | enum `OwnershipType` |

| `VehicleType[]` | Тип |
|---|---|
| `id` | UUID |
| `code`, `name`, `codeVehicleType` | String |
| `active` | Boolean |

### Receiving Auto (`ReceivingAutoRouteChainPackageExportService`)

Собирает `ReceivingOrder` рейса (`ReceivingOrderFilter.route`), по каждой — `ReceivingOrderContainer` и items. Waybill/ЖД-сущности не входят. `Client[]` собирается из четырёх источников: заявки, `ClientDriver.client`, `ClientVehicle.client`, `ReceivingOrderContainer.ownerContainer`; владелец КТК явно учтён.

`postExport`: все `ReceivingOrderContainer` заявок рейса → `TaskStatus.UPLOADED`.

`ownerContainerId` в `ReceivingOrderContainerDto` берётся из nullable `ReceivingOrderContainer.ownerContainer`. Это правило mapping, а не гарантия наличия владельца в каждой исторической строке.

#### Поля (JSON-контракт `ReceivingAutoRouteChainPackageDto`)

Источник: [`ReceivingAutoRouteChainPackageDto.java`](../../../web-layer/src/main/java/ru/korusconsulting/alis/datareon/dto/routechainpackage/ReceivingAutoRouteChainPackageDto.java). `Client`/`ClientDriver`/`ClientVehicle`/`VehicleType`/`EtsngCode` структурно идентичны Shipping-варианту (см. таблицы выше), кроме `RouteDto` (здесь `terminalAreaId: UUID`, а не `terminalArea: String`, и добавлено `deleted: Boolean`) и отсутствия `RailwayCarriage*`/`Contract`/`ShippingOrderEtsngCode`-аналогов — это чисто автомобильный пакет без ЖД-сущностей.

| `Route` (объект, 1) | Тип | Отличие от Shipping |
|---|---|---|
| `terminalAreaId` | UUID | здесь ID, не код-строка |
| `deleted` | Boolean | есть только в этом варианте |
| остальные поля | — | как в Shipping |

| `ReceivingOrder[]` | Тип | |
|---|---|---|
| `id`, `number`, `orderStatus`, `clientId`, `contractId`, `terminalAreaId`, `currencyId` | UUID/Long/enum | |
| `transportType` | enum `TransportType` | |
| `contactName`, `contactPhone`, `contactEmail` | String | |
| `planReceivingDateTime`, `actualReceivingDateTime` | Instant | |
| `storagePeriod`, `totalWeight`, `totalGoodsPrice`, `totalRequestedServicePrice` | BigDecimal | |
| `comment`, `waybill` | String | |
| `totalSKUQuantity`, `totalCargoQuantity`, `totalPalletQuantity`, `totalNotPalletQuantity`, `totalRailwayCarriageQuantity`, `totalContainerQuantity`, `totalRequestedServiceQuantity` | Long | |
| `deliveryType` | enum `ReceivingOrderDeliveryType` | |
| `routeId`, `shipperId` | UUID | |
| `needTransport`, `documentConfirmed`, `ktkNumberUnknown` | Boolean | |

| `ReceivingOrderContainer[]` | Тип | |
|---|---|---|
| `id`, `receivingOrderId`, `containerId`, `dangerClassId`, `sealTypeId` | UUID | |
| `ownerContainerId` | UUID | из nullable ссылки на владельца |
| `ktkNumberUnknown`, `empty`, `customsClearance` | Boolean | |
| `sealNumbers` | `List<String>` | |
| `weight`, `actualQuantity` | BigDecimal | |
| `status` | enum `TaskStatus` | |

| `ReceivingOrderContainerItem[]` | Тип |
|---|---|
| `id`, `receivingOrderId`, `receivingOrderContainerId`, `etsngCodeId` | UUID |
| `description` | String |
| `price`, `weightGross`, `weightNet`, `quantityPlace` | BigDecimal |

| `VehicleBrand[]` (нет в Shipping-варианте) | Тип |
|---|---|
| `id` | UUID |
| `code`, `name`, `codeVehicleBrand` | String |
| `active` | Boolean |

| `DangerClass[]` (нет в Shipping-варианте) | Тип |
|---|---|
| `id` | UUID |
| `code`, `codeDangerClass`, `groupName` | String |
| `active` | Boolean |

| `Container[]` | Тип | |
|---|---|---|
| `containerType` | Java-тип поля — enum `ContainerType` напрямую (у Shipping/ReceivingRailway то же значение приходит уже как `String` через `.name()` в export-сервисе); итоговый JSON, вероятно, одинаков (Jackson по умолчанию сериализует enum через `.name()`), не проверялось отдельно | |
| остальные поля | — | как в Shipping |

### Receiving Railway (`ReceivingRailwayRouteChainPackageExportService`)

Собирает `ReceivingOrder` рейса и по каждой — `Waybill`, `WaybillRailwayCarriage`, `WaybillContainer`, `WaybillProduct`, `WaybillZpu` (ЗПУ — по `WaybillContainer.id`). Дополнительно `RailwayStation` — департура/дестинация **заявки** (`receivingOrder.getDepartureStation/getDestinationStation`), а не станции самой накладной.

`ownerContainerId` берётся из nullable `WaybillContainer.ownerContainer`. В отправляемые списки не включаются excluded-вагоны и КТК, а также КТК excluded-вагона; `Client[]` включает владельцев отправляемых КТК.

**Особенность сборки `WaybillProductDto`:** `toWaybillProductDtos` строит строки продукта с асимметричной логикой:

- если у накладной **2 и более** `WaybillProduct` — каждый продукт даёт одну DTO-строку, `waybillContainerId` у всех — ID первого `WaybillContainer` накладной (`containers.get(0)`), вес — из `WaybillProduct.weight`. Импорт накладной (`WaybillDatareonService.validateWaybillDto`) для 2+ товаров требует **ровно один** КТК, поэтому при наличии этого КТК в отправляемом списке «первый» — единственный. Правило импорта не гарантирует его сохранение после фильтрации excluded. Если после фильтра excluded у такой накладной КТК нет (в том числе после исключения единственного КТК/вагона), `get(0)` даст `IndexOutOfBoundsException` и пакет рейса не отправится;
- если у накладной **ровно 1** `WaybillProduct` — продукт **дублируется** на каждый `WaybillContainer` (по одной DTO-строке на КТК с **одинаковым** `id` продукта), вес — из `WaybillContainer.netWeight`;
- если у накладной 1 товар и **нет КТК** (порожний/без КТК вагон — импорт это допускает), строка товара в пакет **не попадает** вовсе.

`postExport`: найденные `WaybillRailwayCarriage` и `WaybillContainer` заявок рейса → `TaskStatus.UPLOADED`; здесь excluded-фильтр builder не повторяется (не `ReceivingOrderContainer` — для railway-варианта контейнеры живут в `WaybillContainer`).

#### Поля (JSON-контракт `ReceivingRailwayRouteChainPackageDto`)

Источник: [`ReceivingRailwayRouteChainPackageDto.java`](../../../web-layer/src/main/java/ru/korusconsulting/alis/datareon/dto/routechainpackage/ReceivingRailwayRouteChainPackageDto.java). `ClientDriver`/`ClientVehicle`/`VehicleType`/`Client`/`Contract`/`EtsngCode`/`RailwayCarriageType` структурно идентичны Shipping-варианту. `RouteDto` здесь ближе к Shipping (`terminalArea: String`, а не `terminalAreaId`), но с добавленным `deleted: Boolean` и **`clientRelatedEntity: String`** (имя перевозчика текстом, а не `clientRelatedEntityId: UUID`, как у двух других вариантов) — единственный из трёх пакетов, отдающий перевозчика по имени, а не по ID.

| `ReceivingOrder[]` | Тип | |
|---|---|---|
| `id`, `number`, `orderStatus`, `clientId`, `contractId` | UUID/Long/enum | |
| `terminalArea` | String | |
| `transportType` | enum `TransportType` | |
| `currencyId` | UUID | **`@JsonProperty("currencyID")`** — заглавные `ID`, единственное поле среди всех трёх пакетов с такой capitalization (у Shipping/ReceivingAuto — `currencyId`, обычный casing) |
| `contactName`, `contactPhone`, `contactEmail` | String | |
| `planReceivingDateTime`, `actualReceivingDateTime` | Instant | |
| `storagePeriod`, `totalWeight`, `totalGoodsPrice`, `totalRequestedServicePrice` | BigDecimal | |
| `comment` | String | |
| `totalSKUQuantity`, `totalCargoQuantity`, `totalPalletQuantity`, `totalNotPalletQuantity`, `totalRailwayCarriageQuantity`, `totalContainerQuantity`, `totalRequestedServiceQuantity` | Long | |
| `deliveryType` | enum `ReceivingOrderDeliveryType` | |
| `routeId`, `shipperId`, `departureStationId`, `destinationStationId` | UUID | |
| `needTransport`, `documentConfirmed`, `ktkNumberUnknown` | Boolean | |
| `waybill` | — | **отсутствует** в этой версии (в отличие от ReceivingAuto) — номер накладной здесь не дублируется на уровне заявки, так как есть отдельный блок `WaybillProduct`/`WaybillContainer` |

| `WaybillRailwayCarriage[]` | Тип |
|---|---|
| `id`, `receivingOrderId`, `railwayCarriageId` | UUID |
| `ownership`, `renter`, `previouslyTransported` | String |
| `grossWeight`, `netWeight` | BigDecimal |
| `placeCount` | Integer |

| `WaybillContainer[]` | Тип | |
|---|---|---|
| `id`, `waybillRailwayCarriageId`, `containerId` | UUID | |
| `ownerContainerId` | UUID | из nullable ссылки на владельца |
| `supplyRequestNumber`, `sendingRequestNumber` | Integer | |
| `owner` | String | строковый «владелец» с самой накладной (не FK, дублирует смысл `ownerContainerId`) |
| `length`, `netWeight` | BigDecimal | |

| `WaybillProduct[]` | Тип | |
|---|---|---|
| `id`, `receivingOrderId`, `waybillContainerId`, `etsngCodeId` | UUID | `waybillContainerId` — см. находку про «первый контейнер» выше |
| `gngCode`, `packagesCount`, `placesCount` | Integer | |
| `cargoFullName`, `additional`, `packagingType`, `marksStampsShipper`, `isDangerous`, `emergencyCardNumber`, `customsDeclarationNumber`, `customsDeclarationProductNumber` | String | `isDangerous` — именно `String`, не `Boolean` |
| `signDanger` | String | |
| `volume`, `weight`, `weightLoaded`, `netWeight`, `grossWeight`, `length`, `width`, `height` | BigDecimal | `weight` — либо из продукта (2+ товаров), либо из `WaybillContainer.netWeight` (1 товар), см. находку выше |

| `WaybillZpu[]` | Тип |
|---|---|
| `id`, `waybillContainerId` | UUID |
| `zpu` | String |

| `RailwayStation[]` (нет в двух других вариантах) | Тип |
|---|---|
| `id` | UUID |
| `code`, `name`, `esrCode` | String |
| `active` | Boolean |

| `RailwayCarriage[]` | Тип | Отличие от Shipping |
|---|---|---|
| `model` | String (код модели) | у Shipping — `modelId: UUID`; здесь сразу код, без ID |
| остальные поля | — | как в Shipping |

| `Container[]` | Тип | Отличие от Shipping |
|---|---|---|
| `standardSize` | String (код типоразмера) | у Shipping/ReceivingAuto — `standardSizeId: UUID` |
| остальные поля | — | как в Shipping |

### Service order (`ServiceOrderChainPackageExportService`)

Самый простой из четырёх: root — **`ServiceOrder`** (не `Route`), без `postExport`-переопределения (наследует no-op базового класса — здесь нет собственного статуса КТК/вагона, который нужно было бы перевести в `UPLOADED`). Пакет — сама заявка на услугу, её `ServiceOrderContainer[]`, связанные `Container[]` и `Client` (единственный, из `serviceOrder.getClient()`). Триггер — не route accept, а **смена владельцев КТК** в рамках сервисной заявки (транзакционно вместе с историей и `DONE`/`completionAt`) — подробности в [lifecycle сервисной заявки](service-order-lifecycle.md#outbound-пакет).

#### Поля (JSON-контракт `ServiceOrderChainPackageDto`)

Источник: [`ServiceOrderChainPackageDto.java`](../../../web-layer/src/main/java/ru/korusconsulting/alis/datareon/dto/routechainpackage/ServiceOrderChainPackageDto.java) — четыре корневых ключа: `ServiceOrder` (объект), `ServiceOrderContainer[]`, `Container[]`, `Client[]`.

| `ServiceOrder` (объект, 1) | Тип |
|---|---|
| `id`, `clientId` | UUID |
| `number` | Long |
| `service` | enum `ServiceOrderType` |
| `comment` | String |
| `status` | enum `ServiceOrderStatus` |
| `completionAt` | Instant |

| `ServiceOrderContainer[]` | Тип |
|---|---|
| `id`, `serviceOrderId`, `containerId` | UUID |

| `Container[]` | Тип | |
|---|---|---|
| `id`, `standardSizeId` | UUID | |
| `code` | String | |
| `active`, `refrigerator` | **примитив `boolean`**, не `Boolean` | единственный из четырёх пакетов, где эти поля не boxed-типы (несущественно для JSON, но отличается на уровне Java-контракта) |
| `containerType` | enum `ContainerType` | |
| `weight`, `liftingCapacity` | BigDecimal | |

| `Client[]` | Тип |
|---|---|
| структура идентична `Client[]` остальных трёх пакетов (16 полей: id/code/name/active/syncId/inn/kpp/okpo/ogrn/edoId/addressLegal/addressFact/signatoryName/signatoryPosition/email/phoneNumber) | — |

## Отдельно: `GET /routes/{id}/cargo-chain` — не то же самое

Синхронный read-only endpoint `RouteService.getCargoChainByRouteId` → [`RouteToCargoChainPackageDto`](../dto/catalog/routetocargochainpackage/RouteToCargoChainPackageDto.md) (упомянут в [route-lifecycle-as-is.md](route-lifecycle-as-is.md)) — это **не** тот же механизм, что четыре export-сервиса выше. Он не создаёт `OutboundData`, не шлёт ничего в Datareon и не имеет `postExport`-побочных эффектов; это HTTP-запрос по требованию для показа состава рейса в UI. DTO лежит в `ru.korusconsulting.alis.dto` (не `datareon.dto`) и присутствует в автогенерируемом каталоге. Глубокий разбор этого read-пути не входит в объём данного документа.

## Открытые вопросы

1. «Newest-first» порядок обработки очереди (`createdAt DESC`) — осознанное решение (приоритет свежих операций) или недосмотр, из-за которого старые застрявшие строки могут никогда не дойти до retry при постоянном потоке новых сообщений того же `messageType`.
2. Проверить исторические пустые снимки shipping и контракты получателя при owner UUID без карточки в `Client[]`; текущая синхронизация DRAFT/ON_REVIEW уже реализована.
3. ~~Логика «первый контейнер накладной» теряет распределение товаров~~ — правило импорта «2+ товара ⇒ ровно 1 КТК» ограничивает распределение, но последующая фильтрация excluded может удалить единственный КТК и вызвать ошибку сборки. Открыто: товар накладной без КТК не попадает в пакет; при 1 товаре и нескольких КТК в пакете несколько строк `WaybillProduct` с одинаковым `id` — допустимо ли это для Datareon/1С.
4. `getContent`/`response.getBody()` в `BaseExportService` не проверяет `null` явно (`Objects.requireNonNull` бросит NPE, которое будет проглочено общим `catch (Throwable)` и осядет как малоинформативный `errorMessage`) — не проверено, возвращает ли Datareon когда-либо пустое тело при `2xx`.
5. Постоянный список `datareon.cron.*` = 5000 мс для всех четырёх типов не проверялся на предмет реальной нагрузки на Datareon при одновременном срабатывании всех четырёх сразу (совпадающие по времени тик и drain-цикл).
6. Не проверены production-значения feature flags (`receivingAndShippingRailwayRouteChainPackageEnabled`, `receivingAutoRouteChainPackageEnabled`) на конкретной среде — этот документ реконструирует только code-level поведение при включённом флаге.
7. `postExport` безусловно ставит `UPLOADED` всем задачам рейса, включая `FINISHED`; ошибка `postExport` после успешного HTTP вызывает повторную отправку. Нужно ли защищать завершённые задачи и разделять успех отправки и пост-обработку.

## Граница охвата: сторона Datareon — отдельный документ

Этот документ и весь репозиторий `backend` содержат только **отправляющую** сторону (ALIS → Datareon); source-level здесь зафиксирована исключительно она. Как именно Datareon разбирает `PascalCase`-ключи JSON выше, сопоставляет их со своей моделью и валидирует — задокументировано (не source-level, а по предоставленному аналитиком материалу — скриптам трансформации Datareon) в отдельном документе: [route-chain-package-datareon-processing.md](../integrations/route-chain-package-datareon-processing.md). Покрыты 3 из 4 пакетов (`SERVICE_ORDER_CHAIN_PACKAGE` не предоставлен), shipping-скрипт получен не полностью.

## Связанные документы

- [Собственник КТК в исходящих пакетах — справка для 1С](../integrations/container-owner-outbound-contract.md)
- [Обработка на стороне Datareon (внешний материал)](../integrations/route-chain-package-datareon-processing.md)
- [Регистр остатков и владельца КТК](container-remains-and-owner-as-is.md)
- [Интеграционные эффекты заявок](order-integrations.md)
- [AS-IS рейсов](route-lifecycle-as-is.md#outbound-после-accept)
- [Lifecycle сервисной заявки](service-order-lifecycle.md#outbound-пакет)
- [database/shipping-order-container-as-is.md](../database/shipping-order-container-as-is.md#outbound-route-chain-package-и-ownercontainerid)
- [Журнал сверки документации](../traceability/repository-change-log.md)

## Общий справочник ISO

В трёх транспортных пакетах есть `ContainerTypeIso[]`, в ServiceOrder его нет. Поля элемента: `id: UUID`, `containerTypeCode: String`. Источник — non-null `Container.containerTypeISO` отправляемых физических КТК, дедупликация по UUID с сохранением первого элемента. `Container.containerTypeIso` ссылается на UUID этого справочника. [Java helper](../../../web-layer/src/main/java/ru/korusconsulting/alis/datareon/service/routechainpackage/BaseRouteChainPackageExportService.java).

## Граница сверки 13.11.2026

Основные таблицы приведены к текущим DTO, включая `containerOwnerId` и qty `containerOwner`; эти имена нельзя механически переносить на уже сохранённые cancellation payload. Внешний документ Datareon описывает ранее предоставленный материал: оригинальные скрипты в текущем checkout отсутствуют, его соответствие работающей Datareon/1С этой сверкой не подтверждено. HTTP, задачи scheduler и интеграционные тесты не запускались.
