# Владельцы номерных и безномерных КТК вывоза

Срез backend `dev` `3d3899d5d`, 11.11.2026; `AS_IS / SOURCE_CONFIRMED`. Целевая сверка изменений октября–ноября по коду, миграциям и исходникам тестов; runtime и тесты не запускались. Дополняет [регистр владельцев](container-remains-and-owner-as-is.md).

## Три разных представления

| Объект | Поле Java / SQL | Назначение |
|---|---|---|
| ContainerOwner | client / client_id | Текущий владелец физического КТК и его статус в регистре |
| ShippingOrderContainer | containerOwner / container_owner_id | Client в номерной строке вывоза; колонка переименована из owner_container_id |
| ShippingOrderContainerQty | ownerClient / owner_client_id | Выбранный Client для безномерного количества, FK → client(id), nullable по SQL |

Миграция с фактическим именем `v.1.35.0_202610120_KIS-4870_add_client_owner_for_unnumbered_orders.sql` добавляет nullable owner_client_id без backfill/default и переименовывает колонку номерной строки. В JPA ownerClient имеет @ManyToOne(optional=false), хотя БД разрешает NULL, а creation DTO объявляет @Nullable ClientDto. Это расхождение слоёв, а не подтверждение возможности любого INSERT через Hibernate.

## Номерные строки и синхронизация

При добавлении строки с container сервер получает Client через ContainerOwnerDaoService.findClientByContainerId; переданный клиентом владелец не применяется mapper-ом к entity. При смене КТК владелец читается заново, при очистке КТК — NULL.

После changeOwners сервисной заявки, сохранения перехода ContainerStatusService и восстановления владельца при отмене вызывается synchronizeOwnersForUnacceptedOrders. Он обновляет владельца неудалённых строк тех же КТК только в заявках DRAFT/ON_REVIEW. Для ACCEPTED/IN_PROGRESS/DONE этого обновления нет. Прямое произвольное изменение DAO регистра не означает автоматическую синхронизацию: проверены перечисленные вызовы.

Миграция `20261102_KIS-4927_sync_unaccepted_shipping_container_owners` дозаполняет/исправляет неудалённые DRAFT/ON_REVIEW строки при наличии соответствующей ContainerOwner, если client отличается. Runtime-метод при отсутствии владельца в найденном регистре ставит NULL, SQL backfill без совпавшей строки регистра ничего не меняет.

## Безномерные строки

ownerClient есть в creation DTO и наследуется update DTO; возвращается в DTO и сохраняется при add/update/merge. Update присваивает ownerClient из DTO без условия «только если непусто»; mapper merge явно переносит ownerClient. Поле не добавлено в сигнатуру дубликата qty-строки: она состоит из type, empty и отсортированного набора ЕТСНГ/вес. Строки разных владельцев с одинаковой этой сигнатурой могут конфликтовать при merge.

ShippingOrderAcceptValidator выполняет проверку владельца для fillingType=NONE_CONTAINER: если все ownerClient пустые — ShippingOrderContainerQty.MissingOwnerClient; для каждой строки требуется хотя бы один ContainerOwner выбранного клиента со статусом ON_TERMINAL, затем хотя бы один с подходящим ContainerType. Ошибки: OwnerHasNoOnTerminalContainers и MissingOwnerClientWithNeededContainerType. Проверка не сравнивает количество доступных КТК с quantity, не проверяет empty и не резервирует конкретный КТК этой проверкой. Для других fillingType эта функция сразу возвращает пустой список ошибок.

`INFERENCE`: для старых qty-строк с NULL остаётся риск отправки — экспортёр вызывает getOwnerClient().getId() без null guard, даже если fillingType не NONE_CONTAINER. Смешанный список строк с NULL также не защищён проверкой allMatch, если дойдёт до цикла; допустимость такого набора требует отдельного анализа оркестрации/валидации.

## API выбора владельца и счётчика

3b356429b заменил GET на POST и добавил body-фильтр; последующий 127231712 обернул его в FilterWithPaging. В том же 3b356429b update qty-строки начал явно переносить ownerClient, а creation/response DTO заменили JPA Client на ClientDto. Это часть контракта записи/merge, а не только изменение счётчика.

`POST /container-owner/countcontaineronterminal`, CONTAINER_OWNER/READ, принимает FilterWithPaging<ContainerOwnerFilter>, возвращает List<ContainerOwnerCodeNameDto>. Сервис читает filter и pageInfo без null defaults. По отфильтрованным ContainerOwner считает ON_TERMINAL, группирует по Client и сортирует по code; затем добавляет **всех остальных Client** из clientDaoService.findAll() с count=0, тоже отсортированных по code. Пагинация применяется к объединению в памяти, сначала положительные группы, затем нулевые. Это не Page с total и не глобальная сортировка двух групп.

`INFERENCE`: метод не вызывает filterEnrichService.addUserRestriction, а добавленные клиенты с нулём не ограничены входным фильтром регистра. Видимость клиентов и client scope требуют проверки прав/runtime; доступ к endpoint по method permission не доказывает изоляцию клиентов.

## Исходящие поля: несовместимое переименование

| Пакет/блок | Текущее поле | Источник |
|---|---|---|
| ShippingRouteChainPackageDto.ShippingOrderContainer | containerOwnerId (UUID) | ShippingOrderContainer.containerOwner |
| ShippingRouteChainPackageDto.ShippingOrderContainerQty | containerOwner (UUID) | ShippingOrderContainerQty.ownerClient.id, без null guard |
| ShippingOrderContainerChainPackageDto | containerOwnerId | mapping containerOwner.id |
| Поставка: ReceivingOrderContainer / WaybillContainer | ownerContainerId | Их собственные ownerContainer; переименование вывоза их не меняет |

У вывоза прежнее ownerContainerId переименовано в containerOwnerId: нельзя считать их взаимозаменяемыми JSON-именами. Нужна сверка внешнего потребителя. У cancellation payload структура берётся из того же builder, но уже сохранённые JSON строки не переписываются переименованием класса. Сборщик Client[] использует только ShippingOrder.client, без добавления containerOwner/ownerClient. Если владелец не совпал с клиентом какой-либо заявки пакета, его карточки в Client[] нет; это source-level состав, без внешней доставки.

## Проверки и открытые вопросы

В ShippingOrderContainerServiceIntegrationTest есть проверки владельца, смены через service order и сохранения принятой строки, в том числе фактического значения в DAO; исходники изучены без запуска. Для nullable ownerClient, каждого fillingType, merge разных владельцев, исчерпания остатков и client scope счётчика нужны дополнительные проверки.

`OPEN_QUESTION`: согласована ли nullable SQL/DTO с optional=false JPA, требуется ли backfill qty; достаточно ли проверки существования одного КТК и как учитывать конкуренцию/резервирование; поддерживает ли Datareon новое имя containerOwnerId. Фактическую внешнюю доставку нельзя вывести из кода экспортёра.

## Фильтры владельца: ограничения текущей реализации

ShippingOrderContainerQtyFilter содержит ownerClient: ClientFilter, но его isNotEmpty не учитывает ownerClient (shippingOrder проверяется дважды). Predicate вызывает ownerClientPredicate.in(filter.getOwnerClient()) без пути qty.ownerClient. ClientPredicate.in использует корневой QClient.client, а BaseIdentifierPredicate строит ID IN подзапрос относительно переданного пути. `INFERENCE`: это не подтверждённая корректная корреляция с владельцем qty-строки; фильтр только по ownerClient может также распознаваться как пустой. Необходимо проверить запрос на БД; наличие DTO-поля не является доказательством работающей фильтрации.

ContainerOwnerFilter.status участвует в isNotEmpty, но ContainerOwnerPredicate не читает это поле. Поэтому общий DAO-фильтр status сам по себе не задаёт WHERE по статусу. Текущий countcontaineronterminal отдельно применяет status==ON_TERMINAL в Java; именно эта ветка обеспечивает его положительные счётчики. Исторический helper getAllContainerOwnerAndCountContainerByStatus из 7d92a3277 не следует использовать как описание HEAD.

fe843b900 дополнительно сверен по всем изменённым DAO/service/mapper и исходникам тестов: проверены DRAFT/ON_REVIEW propagation, принятый snapshot, различие со вложенным Container.ownerContainer, meta/preview/filter assertions и SQL-backfill. Тесты не запускались; отсутствие registry→NULL в runtime и пропуск несовпавших строк в backfill остаются разными правилами.

Источники: [qty filter](../../../db-layer/src/main/java/ru/korusconsulting/alis/model/shippingordercontainerqty/ShippingOrderContainerQtyFilter.java), [qty predicate](../../../db-layer/src/main/java/ru/korusconsulting/alis/model/shippingordercontainerqty/ShippingOrderContainerQtyPredicate.java), [ClientPredicate](../../../db-layer/src/main/java/ru/korusconsulting/alis/predicate/client/ClientPredicate.java), [ContainerOwnerPredicate](../../../db-layer/src/main/java/ru/korusconsulting/alis/predicate/containerowner/ContainerOwnerPredicate.java), [BaseIdentifierPredicate](../../../wms-layer/src/main/java/ru/korusconsulting/wms/predicate/BaseIdentifierPredicate.java).

## Завершение сверки 401bbea3d: Excel и тестовые сценарии

У трёх shipping parsers удалены KTK_OWNER из структуры, чтение ClientRelatedEntity-владельца и ownerContainer в creation builder. Общий KtkParserSupport проверяет обязательность владельца только при наличии такой колонки; отдельный filling-type-container validator больше её не требует. AbstractRailwayCarriageParser при чтении владельца вагона выбирает KTK_OWNER для receiving и RAILWAY_OWNER для shipping. Это разные колонки и роли владельца.

ReceivingOrderAutoContainerYardTemplateDataCollector выдаёт partners из ClientDaoService/clientFilter; ShippingOrderRailwayCarriageTemplateDataCollector выдаёт consignees из ClientRelatedEntity с partnerFilter(clientId) и isConsignee=true. Остальные ветви методов сверены по токенам без форматирования. Три XLSX сопоставлены отдельно по OOXML: [изменения шаблонов](../traceability/excel-template-diff-2026-11-11.md).

Исходники тестов проверяют snapshot из registry вопреки переданному owner DTO, сохранение snapshot после прямого изменения DAO, возврат предыдущих receiving/shipping связей после двух циклов и сохранение первой registry-записи при отмене. History controller test исключает DRAFT и проверяет две DONE-записи; template tests заменяют ClientRelatedEntity mock на Client и удаляют прежний ClientService mock грузополучателей. Они не доказывают правильность каждого фильтра dropdown: в mock используется any(Filter.class). Поздняя синхронизация DRAFT/ON_REVIEW описана выше и меняет прежние границы snapshot. Исходники прочитаны, Java/POI/HTTP не запускались.

## Исходные файлы

- [v.1.35.0_202610120_KIS-4870_add_client_owner_for_unnumbered_orders.sql](../../../db-layer/src/main/resources/db/changelog/v.1.35.0/v.1.35.0_202610120_KIS-4870_add_client_owner_for_unnumbered_orders.sql)
- [v.1.35.0_20261102_KIS-4927_sync_unaccepted_shipping_container_owners.sql](../../../db-layer/src/main/resources/db/changelog/v.1.35.0/v.1.35.0_20261102_KIS-4927_sync_unaccepted_shipping_container_owners.sql)
- [ShippingOrderContainerQty.java](../../../db-layer/src/main/java/ru/korusconsulting/alis/model/shippingordercontainerqty/ShippingOrderContainerQty.java)
- [ShippingOrderContainerQtyCreationDto.java](../../../web-layer/src/main/java/ru/korusconsulting/alis/dto/shippingordercontainerqty/ShippingOrderContainerQtyCreationDto.java)
- [ShippingOrderContainerQtyService.java](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/shippingordercontainerqty/ShippingOrderContainerQtyService.java)
- [ShippingOrderContainerQtyMapper.java](../../../web-layer/src/main/java/ru/korusconsulting/alis/mapper/shippingordercontainerqty/ShippingOrderContainerQtyMapper.java)
- [ShippingOrderAcceptValidator.java](../../../web-layer/src/main/java/ru/korusconsulting/alis/dto/shippingorder/validator/ShippingOrderAcceptValidator.java)
- [ShippingOrderContainerDaoService.java](../../../db-layer/src/main/java/ru/korusconsulting/alis/service/shippingordercontainer/ShippingOrderContainerDaoService.java)
- [ContainerOwnerService.java](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/containerowner/ContainerOwnerService.java)
- [ContainerStatusService.java](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/containerstatus/ContainerStatusService.java)
- [ShippingOrderContainerService.java](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/shippingordercontainer/ShippingOrderContainerService.java)
- [ShippingOrderContainerMapper.java](../../../web-layer/src/main/java/ru/korusconsulting/alis/mapper/shippingordercontainer/ShippingOrderContainerMapper.java)
- [ShippingRouteChainPackageExportService.java](../../../web-layer/src/main/java/ru/korusconsulting/alis/datareon/service/routechainpackage/ShippingRouteChainPackageExportService.java)
- [ShippingRouteChainPackageDto.java](../../../web-layer/src/main/java/ru/korusconsulting/alis/datareon/dto/routechainpackage/ShippingRouteChainPackageDto.java)
- [ShippingOrderContainerServiceIntegrationTest.java](../../../web-layer/src/integrationTest/java/ru/korusconsulting/alis/service/shippingordercontainer/ShippingOrderContainerServiceIntegrationTest.java)

## Промежуточные изменения DTO и итоговый контракт

Серия 7c7d4ec90 → 2a9bc32f5 → 3ea781dde → 156bcd48b последовательно перемещала владельца между ContainerDto и ShippingOrderContainerDto и дополняла list/detail/merge mappings. Это история, не несколько одновременно актуальных способов записи. После KIS-4830 и переименования итоговый ShippingOrderContainerDto.containerOwner берётся из entity.containerOwner; ContainerDto.ownerContainer описывает текущий registry-владелец. 050d52ee8 переименовал также creation/response DTO с ownerContainer на containerOwner, хотя название коммита говорит про тест. Алиас старого JSON-имени этим diff не добавлен.

156bcd48b удалил проверку MissingOwnerContainer у номерных строк вывоза из accept-validator; это не отменяет требований ContainerStatusService к состоянию/владельцу регистра. Проверки ownerClient у qty/NONE_CONTAINER — отдельный сценарий, описанный выше.

## Точное имя meta владельца

В текущем ShippingOrderContainerService alias `owner`/`containerowner` преобразуется в строковый путь `containerowner.code` (именно так в коде). 42ee5f7e6 меняет тестовый вызов с ownerContainer на containerOwner. Совместимость прежнего ownerContainer meta-имени не гарантирована. Корректность разрешения регистра property-path требует запуска соответствующего integration test; имя JSON DTO containerOwner отдельно подтверждено исходником.
