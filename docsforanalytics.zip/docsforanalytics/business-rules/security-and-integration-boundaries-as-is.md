# Безопасность и границы интеграций: сверка сентября 2026

Срез backend 3d3899d5d, 11.11.2026. AS_IS / SOURCE_CONFIRMED по исходникам; окружение, браузер и внешние сервисы не проверялись. Этот документ уточняет контракт, но не подтверждает конфигурацию deployed-среды.

## CORS управляется backend

02d91d5a4 заменяет прежний wildcard-default на `cors.origin-patterns: ${CORS_ORIGIN_PATTERNS:}`. CorsProperties по умолчанию содержит пустой список. ResourceServerSecurity активен при наличии issuer-uri; шаблоны origin trim-ятся, пустые убираются, повторы удаляются. Если список пуст, этот метод не регистрирует явную CORS-конфигурацию (это не доказательство состояния иных конфигураций среды).

При непустом списке заданы GET/HEAD/POST/PUT/DELETE, headers Authorization, Content-Type, X-Timezone, allowCredentials=true и maxAge=5 минут. PATCH не включён. OPTIONS не перечислен как разрешённый фактический метод: работу preflight нельзя оценивать как обычный controller mapping, нужна проверка браузером/Spring filter chain. CORS ограничивает браузерные cross-origin запросы, не служит аутентификацией внешнего HTTP-клиента.

Security chain permitAll для /actuator/**, /swagger-ui/**, /v3/api-docs/** и /datareon/**; остальные пути требуют authenticated. Это правило HTTP-фильтра не отменяет method-level @Secure. Session STATELESS, CSRF disabled. Внешний gateway, network policy и фактические JWT-настройки исходниками не подтверждены.

## Ошибки безопасности

d24879c6e подключает SecurityExceptionResolver к authenticationEntryPoint/accessDeniedHandler. Сначала вызывается стандартный Bearer handler (в том числе его статус/заголовки), затем HandlerExceptionResolver с исключением. Advice обрабатывает AuthenticationException как 401 и Spring AccessDeniedException как 403, строя ApiErrorDto. Это расширяет единый legacy JSON-контракт на filter-level ошибки; детали реально отданных заголовков/тела требуют HTTP-теста.

AlisException и Bean Validation сверены с текущими ExceptionAdvice/ExceptionAdviceUtils: JSON остаётся {contextObject,errorMessage,errorCode}, один ErrorDetails переносит code/params/field, несколько дают объединённый errorMessage без отдельного errorCode/context; Bean Validation выбирает последнюю ошибку. Категория BUSINESS_RULE_VIOLATION мапится в 422, но наличие enum не доказывает такой ответ конкретного endpoint. Подробная таблица 400/403/404/409/500 — [модель ошибок](error-model-as-is.md).

## Keycloak SPI: служебный токен отдельно от Datareon

20e4f8a72 создаёт именованный keycloakRestTemplate с rootUri `{keycloak.url}/realms/{realm}` и Bearer-токеном Keycloak tokenManager. Admin client использует CLIENT_CREDENTIALS с clientId/clientSecret. KeycloakExtendedApi получает этот bean через @Qualifier; пользовательский JWT не является источником SPI-токена. Ошибка получения service token оборачивается в KeycloakException.

Общий RestTemplateConfiguration.restTemplate помечен @Primary, имеет timeouts и не содержит этого token interceptor. Следовательно, DI для обычных Datareon REST-сервисов не должен переносить Keycloak Bearer; BaseDatareonRestService задаёт собственный Basic Authorization. Наличие двух bean не доказывает права service account, endpoint SPI или доступность Keycloak на среде. Секреты при этой сверке не читались.

## contract_with_contractor — приём без сохранения

f11ff7ba9 добавляет POST /datareon/contract_with_contractor, a912531c5 меняет body на JsonNode и логирует payload. Текущий метод не вызывает бизнес-сервис и не сохраняет договор. HTTP 200 означает прохождение этого метода, не успешную синхронизацию договора. OpenAPI-описания 400/406 не являются доказательством предметной валидации/уникальности в этом пустом обработчике. Общая /datareon permitAll-политика описана выше.

## Удаление старого Datareon-monitoring

a5a40f94e удаляет MonitorClient и отправку inbound/outbound/incident в отдельный мониторинг, связанные config/feature flags и зависимости. Это не удаляет outbound_data, inbound_event, GoodRemainLog или обычное логирование. GoodRemainTransactionService продолжает log.warn и накопление error details; отдельное monitorClient.logIncident больше не выполняется. Ранее описанный вызов удалённого мониторинга не следует использовать как свидетельство доставки/наблюдаемости.

Завершение сверки 12.11.2026: удалены также MONITORING_SERVICE_URL из CI/Helm/localtest, datareon-monitoring-enabled из application/FeatureFlags и monitor-пакет из ComponentScan. Конструкторы REST-подклассов потеряли MonitorClient; POST URL/Basic headers/RestTemplate exchange сохранены. getContent больше не отправляет копию успешного ответа/пакета в monitor. UserInfoController.all больше не создаёт incident для пустого набора ролей, но возвращает тот же userInfoService.getUserInfoWithPermissions. Это удаление побочного мониторинга, а не отмена аутентификации/авторизации. Сверены все группы diff; фактическое наличие иной системы наблюдаемости не проверено.

## Проверки и открытые вопросы

Изучены источники advice, CORS, REST DI и endpoint; Java/HTTP-тесты не запускались. Открыты: фактические origin patterns, права service account, результат preflight и WWW-Authenticate, внешнее ограничение /datareon, замена удалённого мониторинга в эксплуатации. Отдельные тесты не заменены предположениями о deployed-среде.

## Источники

- [CorsProperties.java](../../../web-layer/src/main/java/ru/korusconsulting/alis/config/CorsProperties.java)
- [ResourceServerSecurity.java](../../../web-layer/src/main/java/ru/korusconsulting/alis/config/ResourceServerSecurity.java)
- [SecurityExceptionResolver.java](../../../web-layer/src/main/java/ru/korusconsulting/alis/exception/SecurityExceptionResolver.java)
- [ExceptionAdvice.java](../../../web-layer/src/main/java/ru/korusconsulting/alis/exception/ExceptionAdvice.java)
- [ExceptionAdviceUtils.java](../../../wms-layer/src/main/java/ru/korusconsulting/wms/controller/exception/ExceptionAdviceUtils.java)
- [KeycloakAdminClientConfig.java](../../../wms-layer/src/main/java/ru/korusconsulting/wms/config/keycloak/KeycloakAdminClientConfig.java)
- [KeycloakExtendedApi.java](../../../wms-layer/src/main/java/ru/korusconsulting/wms/service/keycloak/impl/KeycloakExtendedApi.java)
- [RestTemplateConfiguration.java](../../../web-layer/src/main/java/ru/korusconsulting/alis/config/RestTemplateConfiguration.java)
- [BaseDatareonRestService.java](../../../web-layer/src/main/java/ru/korusconsulting/alis/datareon/service/BaseDatareonRestService.java)
- [DatareonController.java](../../../web-layer/src/main/java/ru/korusconsulting/alis/controller/datareon/DatareonController.java)
- [GoodRemainTransactionService.java](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/goodremain/GoodRemainTransactionService.java)

## Снятый общий перехват DB violations

d24879c6e также удаляет из BaseService.add/update/remove общий catch DataIntegrityViolationException → UniqueViolationException. Поэтому конфликт SQL constraint, не перехваченный конкретным сервисом, идёт в advice как 500/InternalError; application DuplicateEntityException/UniqueViolationException по-прежнему дают 409. Декларация 406 в OpenAPI не меняет runtime mapping. Специальные локальные catch (например inbound-event insert) нужно проверять отдельно; правило не распространяется на них автоматически.
