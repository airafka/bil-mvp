# Регистр остатков и владельца КТК: `ContainerOwner`/`ContainerOwnerHistory` AS-IS

Проверено по checkout `3d3899d5d615ae4ec1edb10bfa7a8a8bd0f2dcde` (12.11.2026): Java entity/service/validator source. Это **source-level реконструкция**, а не проверка применённой БД или прогон тестов. Вся описанная ниже машина статусов (`ContainerStatusService`) — новый код этого периода (KIS-4661, «KTK remains», первый коммит `9a05f552` от 21 сентября 2026); модель владельца (`ContainerOwner`/`ContainerOwnerHistory`) существовала раньше, но получила поле `status` и связи с заявками той же серией коммитов, плюс замену типа `owner`-полей с `ClientRelatedEntity` на `Client` в KIS-4716 (24–25 сентября 2026).

> **Актуализация 14.10.2026 (`729c9a17`, KIS-4830, коммиты `401bbea3`, `143d3a43`, `a1238ba1`).** Изменились: отмена поставки больше не удаляет строку `ContainerOwner`; при отмене поставки/вывоза ссылка `receivingOrder`/`shippingOrder` возвращается на предыдущую заявку, а не обнуляется; `ShippingOrderContainer.ownerContainer` переведён на `Client` и заполняется снимком из registry — дефект `ownerContainerId = null` в route chain package закрыт; API истории владельцев ограничивает receiving/shipping выполненными заявками и переходом в `ON_TERMINAL`/`DEPARTED`; SERVICE_ORDER обходит эту статусную группу и отдаёт `newClient` вместо `orderClient`. Ниже текст обновлён по этим коммитам.

## Модель: один регистр на КТК, а не поле на заявке

[`ContainerOwner`](../entities/catalog/entities/containerowner/ContainerOwner.md) — `@OneToOne` с `Container` (до KIS-4661 было `@ManyToOne`; однако первоначальная SQL-миграция уже задавала `UNIQUE(container_id)`, поэтому несколько owner-строк одного КТК она не допускала. UUID `id` — отдельный PK). Строка хранит:

- `client` — текущий владелец;
- `status` — [`ContainerStatus`](../../../db-layer/src/main/java/ru/korusconsulting/alis/model/container/ContainerStatus.java): `EXPECTED` (ожидает поставки) / `ON_TERMINAL` (в остатках) / `RESERVED_OUT` (ожидает вывоза) / `DEPARTED` (нет в остатках);
- `receivingOrder`/`shippingOrder` — какая заявка определила текущее состояние.

[`ContainerOwnerHistory`](../entities/catalog/entities/containerownerhistory/ContainerOwnerHistory.md) — append-only лог: `oldClient/newClient`, `oldStatus/newStatus`, `container`, полиморфная `order` (`@Any` на `ReceivingOrder`/`ShippingOrder`/`ServiceOrder` через `order_type` discriminator). В ContainerStatusService.transition пишется только при изменении client/status; restorePreviousOwner записывает историю отдельно. Сервисная смена владельца также имеет свой writer; единое правило «только transition» ко всей истории неприменимо.

Миграция [`v.1.35.0_..._KIS-4661_add_container_owner_status.sql`](../../../db-layer/src/main/resources/db/changelog/v.1.35.0/v.1.35.0_20260915_KIS-4661_add_container_owner_status.sql) при накатке проставила всем существующим строкам `status='ON_TERMINAL'` — то есть все ранее созданные `container_owner` считаются «в остатках» по умолчанию, задним числом, без реальной истории EXPECTED/RESERVED_OUT для них.

## Состояния и переходы (`ContainerStatusService`)

```mermaid
stateDiagram-v2
    [*] --> EXPECTED: reserveForReceivingOrder (accept поставки)
    EXPECTED --> ON_TERMINAL: markReceived (TOS receiving result)
    EXPECTED --> DEPARTED: cancelReceivingOrder (reject/cancel поставки)
    ON_TERMINAL --> RESERVED_OUT: reserveForShippingOrder (accept вывоза)
    ON_TERMINAL --> DEPARTED: cancelReceivingOrder (отмена DONE-поставки, см. риск ниже)
    RESERVED_OUT --> DEPARTED: markShipped (TOS shipment result)
    RESERVED_OUT --> ON_TERMINAL: cancelShippingOrder (reject/cancel вывоза)
    DEPARTED --> EXPECTED: reserveForReceivingOrder (повторная поставка того же КТК)
```

| Метод | Вызывается из | Что делает | Ключевые проверки (иначе `ValidationException`, коды `ContainerStatus.*`) |
|---|---|---|---|
| `reserveForReceivingOrder` | [`ReceivingOrderService.accept`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/receivingorder/ReceivingOrderService.java) | Владелец для каждого КТК заявки — из `ReceivingOrderContainer.ownerContainer` **и** связанных `WaybillContainer.ownerContainer`; переход в `EXPECTED` | Владелец обязателен и должен совпадать между строками одного КТК (`ContainerStatus.ReceivingAlreadyReserved/InRemains/InShipping`, если КТК уже трекается в другом статусе, кроме `DEPARTED`) |
| `markReceived` | [`TosReceivingResultAction`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/datareon/inbound/action/TosReceivingResultAction.java) (inbound TOS-событие) | `EXPECTED → ON_TERMINAL`, владелец не меняется | Не проверяет входной статус явно — просто перезаписывает |
| `cancelReceivingOrder` | `ReceivingOrderService.reject` | Не выполняется для `DRAFT`/`ON_REVIEW` (там ещё не было `reserveForReceivingOrder`). Для остальных статусов: если предыдущий статус был `DONE`, требует `ON_TERMINAL` именно от этой заявки, иначе — восстановление предыдущего владельца (см. ниже) | `CancelReceivingInShipping/Departed/ReservedLater`, если КТК уже не в ожидаемом состоянии |
| `reserveForShippingOrder` | `ShippingOrderService.accept` | Требует `owner != null && status == ON_TERMINAL`; переход в `RESERVED_OUT`, владелец **не выбирается заново** — берётся из текущей строки registry | `ShippingMissingInRemains` (нет владельца/уже `DEPARTED`), `ShippingNotReceived` (ещё `EXPECTED`), `ShippingAlreadyReserved` (уже `RESERVED_OUT`) |
| `markShipped` | [`TosShipmentResultAction`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/datareon/inbound/action/TosShipmentResultAction.java) | `RESERVED_OUT → DEPARTED` | — |
| `cancelShippingOrder` | `ShippingOrderService.reject`/отмена | Не выполняется для `DRAFT`/`ON_REVIEW`. Для `DONE` требует, чтобы КТК сейчас был `DEPARTED` именно от этой заявки; иначе `CancelShippingExpected/Received/ReservedLater`. Возврат в `ON_TERMINAL`, владелец не меняется; `shippingOrder` с 08.10.2026 (KIS-4830) — предыдущая неотклонённая заявка на вывоз этого КТК по истории (`findPreviousShippingOrder`: запись истории раньше первой записи отменяемой заявки, статус заявки ≠ `REJECTED`), если её нет — `null` (до KIS-4830 всегда `null`) | — |

## Риск: восстановление владельца при отмене поставки всегда даёт `DEPARTED`, а не прежний статус

`cancelReceivingOrder` → `restorePreviousOwner` ищет в `ContainerOwnerHistory` запись `findReceivingReservation(containerId, orderId)` и берёт из неё `oldClient` (владельца **до** этой поставки). Дальше:

- если `oldClient == null` (у контейнера не было владельца до этой поставки, то есть это была первая регистрация) — с 08.10.2026 (KIS-4830, `401bbea3`) строка `ContainerOwner` **сохраняется**: статус `DEPARTED`, владелец остаётся тем, кого указала отменённая поставка; в историю пишется запись `oldClient = newClient =` этот владелец, меняется только статус. До KIS-4830 строка удалялась целиком (`containerOwnerDaoService.remove`) и КТК выходил из регистра;
- если `oldClient` есть — строка обновляется: `client = oldClient`, но **статус жёстко ставится `DEPARTED`**, а не восстанавливается прежний статус до этой поставки;
- в обоих случаях `receivingOrder` с KIS-4830 указывает на предыдущую неотклонённую поставку этого КТК по истории (`findPreviousReceivingOrder`), а при её отсутствии — `null` (до KIS-4830 всегда `null`).

То есть отмена/reject поставки, у которой КТК уже был `ON_TERMINAL` (реально принят складом, затем заявку отменили как `DONE`), не возвращает КТК в `ON_TERMINAL` под старым владельцем — он помечается как выбывший (`DEPARTED`) вне зависимости от того, был ли он физически кем-то вывезен. Отдельно физическое перемещение (`good_movement`/warehouse) этим методом не проверяется и не корректируется. **Вопрос для ТЗ:** осознанное упрощение (отмена = импорт-исправление, а не физическое движение) или дефект.

## Два уровня «владельца» и их рассинхронизация (KIS-4716)

До KIS-4716 поле-владелец на строке заявки (`ReceivingOrderContainer.ownerContainer`, `ShippingOrderContainer.ownerContainer`/`ownerRailwayCarriage`, `WaybillContainer.ownerContainer`) было типизировано как `ClientRelatedEntity`. Миграции [`add_owner_client_columns.sql`](../../../db-layer/src/main/resources/db/changelog/v.1.35.0/v.1.35.0_20260921_KIS-4716_add_owner_client_columns.sql) + [`migrate_owner_client_data.sql`](../../../db-layer/src/main/resources/db/changelog/v.1.35.0/v.1.35.0_20260921_KIS-4716_migrate_owner_client_data.sql) переводят это на прямую ссылку на `Client` — но **не единообразно**:

| Сущность | Поле | Колонка | Текущий тип |
|---|---|---|---|
| `ReceivingOrderContainer` | `ownerContainer` | `owner_container_id` | `Client` (мигрировано KIS-4716) |
| `WaybillContainer` | `ownerContainer` | `owner_container_id` | `Client` (мигрировано KIS-4716) |
| `ShippingOrderContainer` | `containerOwner` | `container_owner_id` | `Client` — мигрировано **KIS-4830** (08.10.2026), заполняется сервером снимком из registry, см. [раздел ниже](#владелец-на-строке-вывоза-kis-4830). С 22.09 по 08.10.2026 было `ClientRelatedEntity` и всегда `null` у новых строк |
| `ShippingOrderContainer` | `ownerRailwayCarriage` | `owner_railway_carriage_id` | **`ClientRelatedEntity`** (НЕ мигрировано) |

**Уточнение текущей схемы 11.11.2026:** ранний cleanup действительно откатывался, но `82c91f46d` вновь включил `v.1.35.0_20260922_KIS-4716_cleanup_receiving_order_container_owner.sql`. Он удаляет старую owner_container_id, переименовывает owner_container_id_new в owner_container_id и FK. Текущее поле receiving ownerContainer хранится в owner_container_id → client; имя _new относится к промежуточной истории.

С 22.09 по 08.10.2026 мапперы `/list`-, detail- и merge-эндпоинтов вывоза (коммиты `7c7d4ec9`…`156bcd48`: `toDto`, `toDetailedDto`, `mapToContainerDto`, `mapToUnnumberedOrderContainerMergeDto` в [`ShippingOrderContainerMapper`](../../../web-layer/src/main/java/ru/korusconsulting/alis/mapper/shippingordercontainer/ShippingOrderContainerMapper.java)) заполняли `ownerContainer` из `container.containerOwner.client` (live-registry), минуя поле строки. KIS-4830 убрал эти `@Mapping` — теперь они отдают поле строки (снимок); live-значение registry осталось только в `toContainerDto` (DTO самого КТК). В период KIS-4716 из [`ShippingOrderAcceptValidator`](../../../web-layer/src/main/java/ru/korusconsulting/alis/dto/shippingorder/validator/ShippingOrderAcceptValidator.java) убрана проверка `container.getOwnerContainer() == null → MISSING_OWNER_CONTAINER` — на вывозе владелец больше не выбирается и не валидируется на уровне строки заявки, единственная проверка владельца при accept вывоза теперь происходит через `ContainerStatusService.reserveForShippingOrder` (требование `status == ON_TERMINAL`, владелец берётся из registry).

### Владелец на строке вывоза (KIS-4830)

Коммит `401bbea3` (08.10.2026):

- **Схема.** Миграция [`v.1.35.0_20261006_KIS-4830_shipping_container_owner_client.sql`](../../../db-layer/src/main/resources/db/changelog/v.1.35.0/v.1.35.0_20261006_KIS-4830_shipping_container_owner_client.sql) переводит FK `shipping_order_container.owner_container_id` с `client_related_entity` на `client`. Значения перемаплены по таблице соответствия из KIS-4716 (`3bcf0113`); значения, которых нет в таблице, становятся `NULL`.
- **Заполнение.** Значение из DTO игнорируется (`modelCreation` и `modelUpdate` — `ignore = true`). [`ShippingOrderContainerService`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/shippingordercontainer/ShippingOrderContainerService.java) записывает в строку текущего владельца из registry (`container.containerOwner.client`) при создании строки и при смене КТК в `PUT`; [`TosShipmentResultAction`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/datareon/inbound/action/TosShipmentResultAction.java) делает то же для строк, которые создаёт или перепривязывает по результату отгрузки из TOS. Без КТК или без строки registry — `NULL`.
- **Чтение.** `toDto`/`toDetailedDto`/merge-DTO и route chain package (`toChainPackageDto` → `ShippingRouteChainPackageExportService`, `.containerOwnerId(id(shippingOrderContainer.getContainerOwner()))`) читают **одно и то же** поле строки. Дефект «`ownerContainerId` в пакете вывоза всегда `null`» (22.09–08.10.2026) этим закрыт.
- **Excel-загрузка вывоза.** Из трёх шаблонов загрузки (`templates/shipping_order_auto_container_yard.xlsx`, `shipping_order_railway_carriage.xlsx`, `shipping_order_railway_carriage_filling_type_container.xlsx`) удалена колонка «Собственник КТК*» вместе с выпадающим списком на лист «Контрагенты»; остальные колонки сдвинулись на одну влево. Парсеры (`ShippingOrderAutoContainerYardParser`, `ShippingOrderRailwayCarriageParser`, `ShippingOrderRailwayCarriageFillingTypeContainerParser`) владельца не читают и не проверяют — пропала ошибка `Container.KtkOwner.IsEmpty.N`. Файл **старого образца** с этой колонкой отклоняется проверкой структуры (`ValidateUtil.validateColumn`, ошибка `Column.<Лист>.NotFound`). Для поставки проверка колонки сохранена (`KtkParserSupport` проверяет её только при наличии).
- **Собственник вагона в ЖД-шаблоне вывоза.** До KIS-4830 `AbstractRailwayCarriageParser` записывал в `ownerRailwayCarriage` значение колонки «Собственник КТК», а колонку «Собственник вагона» игнорировал. Теперь для вывоза берётся «Собственник вагона» (поиск по `ClientRelatedEntity` клиента заявки, при отсутствии — `NotFoundException`).
- **Выпуск шаблонов.** В ЖД-шаблоне вывоза лист «Грузополучатель» теперь заполняется `ClientRelatedEntity` клиента заявки с признаком грузополучателя (раньше — все активные `Client`), то есть ровно тем, что ищет импорт. В авто-шаблоне поставки (`ReceivingOrderAutoContainerYardTemplateDataCollector`) лист «Контрагенты» теперь заполняется всеми активными `Client` (раньше — `ClientRelatedEntity` клиента), в соответствии с поиском владельца при импорте поставки.
- **Фильтр/сортировка.** `ShippingOrderContainerFilter.ownerContainer` стал `ClientFilter` (было `ClientRelatedEntityFilter`); сортировка и общий поиск по владельцу идут по `client.code`.

**Уточнение 11.11.2026:** прежнее ограничение о неизменном снимке снято для неудалённых DRAFT/ON_REVIEW строк: при штатной смене владельца/статуса они синхронизируются с регистром, миграция также исправляет такие строки при наличии registry. ACCEPTED и последующие статусы этой синхронизацией не меняются. Java поле теперь containerOwner, SQL — container_owner_id, outbound — containerOwnerId. [Точный алгоритм и безномерные qty](shipping-container-owners-as-is.md).

[`Каталог ошибок`](order-errors.md) уже разделяет поставку и вывоз: ReceivingOrderContainer.MissingOwnerContainer остаётся активным; ShippingOrderContainer.MissingOwnerContainer помечен как не вызываемый с KIS-4716. Требования регистра при резервировании и ownerClient для NONE_CONTAINER — отдельные проверки.

## Связь с приёмкой заявки (WaybillContainer как альтернативный источник владельца)

Уточнение TOS: обычная подмена КТК читает owner из registry с NULL fallback, но создание законченной строки в NONE_CONTAINER требует registry-запись и выбрасывает IllegalArgumentException с TosShipmentResult.ContainerOwnerNotFound при её отсутствии. Общее правило «без registry — NULL» к этой ветке не относится.

`ContainerStatusService.getContainers(ReceivingOrder)` объединяет КТК из **двух** источников: собственных `ReceivingOrderContainer` заявки **и** `WaybillContainer`, связанных через `receivingOrderId` (то есть КТК, пришедшие по железнодорожной накладной и привязанные к этой поставке). `getRequiredReceivingOwners` требует владельца от **обоих** источников и явно проверяет, что они не противоречат друг другу (`Для КТК указаны разные собственники`, если `ReceivingOrderContainer.ownerContainer` и `WaybillContainer.ownerContainer` для одного физического КТК различаются). Обе модели должны согласоваться при accept. С 545a1ebfd смена defaultContainerOwner автоматически переписывает найденные дочерние владельцы; отдельное редактирование строк требует проверки согласованности.

## API истории владельцев (`/container/{id}/owner-history`)

[`ContainerOwnerHistoryService`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/containerownerhistory/ContainerOwnerHistoryService.java) для `POST /page` и `POST /meta/{fieldName}` принудительно добавляет к фильтру клиента (с 08.10.2026, KIS-4830, `401bbea3` и `143d3a43`):

- `orderStatus IN (DONE)` — ограничение receiving/shipping; SERVICE_ORDER с 1db3d70b3 обходит статусную группу;
- `newStatus IN (ON_TERMINAL, DEPARTED)` — только переходы «принят на терминал» и «выбыл»; для receiving/shipping записи EXPECTED/RESERVED_OUT скрыты; SERVICE_ORDER проходит независимо от newStatus.

Физически `ContainerOwnerHistory` по-прежнему пишет все переходы — ограничение только на чтение через API.

С 12.10.2026 (`a1238ba1`) в [`ContainerOwnerHistoryDto`](../dto/catalog/containerownerhistory/ContainerOwnerHistoryDto.md) поле `orderClient` («Клиент заявки», клиент заявки) **заменено** на `newClient` («Новый владелец КТК», `history.newClient`). Из фильтра удалён `orderClient` (поиск по коду клиента заявки); meta по `newClient` отдаёт значения `newClient.code`. Для клиентов API это несовместимое изменение контракта.

## Передача владельца во внешние системы

Куда и в каком виде `ownerContainerId` уходит в исходящих пакетах Datareon (по сценариям поставки/вывоза, включая закрытый KIS-4830 дефект на вывозе) — сведено отдельно, как справка для аналитика 1С: [container-owner-outbound-contract.md](../integrations/container-owner-outbound-contract.md).

## Открытые вопросы

1. Осознанность DEPARTED-заглушки при отмене принятой поставки (см. раздел про восстановление владельца) — нужен ответ разработчика/продукта, не source-level вопрос.
2. Временное имя owner_container_id_new устранено cleanup-коммитом 82c91f46d. Унификация ownerRailwayCarriage с Client остаётся отдельным открытым вопросом.
3. Каталог ошибок уже разделяет ReceivingOrderContainer.MissingOwnerContainer и неактивный ShippingOrderContainer.MissingOwnerContainer; отдельные проверки registry и qty сохраняются.
4. Тесты в этом периоде (`ContainerStatusServiceIntegrationTest`) не прогонялись в рамках этой сверки; поведение на реальной БД (constraint `chk_container_owner_status`, параллельные accept двух заявок на один КТК через `findAndLock`) не проверено сверх чтения source.
5. ~~`ownerContainerId` в outbound route chain package для вывоза с 22.09.2026 всегда `null`~~ — **закрыто KIS-4830** (`401bbea3`, 08.10.2026). Новые вопросы: (а) нужно ли дозаполнить `owner_container_id` у строк вывоза, созданных 22.09–08.10.2026; (б) закрыто кодом для DRAFT/ON_REVIEW — обновляется; для принятых заявок остаётся снимком.
6. После KIS-4830 отмена первой поставки КТК оставляет в registry строку `DEPARTED` с владельцем из отменённой заявки (раньше строка удалялась). Подтвердить, что это ожидаемо: такой КТК в справочнике выглядит «выбывшим» с владельцем, хотя на терминал фактически не поступал.
7. История владельцев в UI скрывает переходы `EXPECTED`/`RESERVED_OUT` и записи невыполненных заявок — подтвердить, что аналитикам и пользователям не нужна полная история (в БД она есть).
8. `ShippingOrderContainerMergeDto.ShippingOrderContainerDto.ownerContainer` по-прежнему помечен `@NotNull`, хотя сервер значение игнорирует: клиент `PUT /merge` обязан прислать владельца, который ни на что не влияет. Уточнить у разработчиков, нужно ли снять ограничение.

## Актуальные границы описания владельца

Исторические сведения о KIS-4830 выше относятся к октябрьскому контракту. Переименование полей, backfill, NONE_CONTAINER и счётчик владельцев сверены отдельно: [правила на 11.11.2026](shipping-container-owners-as-is.md).

## Уточнение истории и default владельца на 11.11.2026

Услуги — исключение из статусных фильтров истории. Смена defaultContainerOwner у поставки переписывает найденные дочерние владельцы, а не только пустые. [Условия и границы](reference-contract-changes-oct-nov-2026.md).

## Статус КТК в DTO и meta: контроль сентябрьских исправлений

ContainerStatusResolver возвращает DEPARTED для отсутствующего Container или отсутствующей записи ContainerOwner; иначе — owner.status. Это вычисляемая read-семантика, не INSERT записи регистра. Отдельные mapper-методы toContainerDto не создают искусственный непустой nested Container для отсутствующей ссылки.

Текущие DAO meta выбирают ID строки заявки и owner.status через LEFT JOIN, затем группируют в Java: NULL превращается в DEPARTED, остальные значения — status.name(). И отсутствующий owner, и явный DEPARTED попадают в одну группу. TreeMap сортирует коды лексикографически по sortingDirection, HashSet удаляет повторяющиеся ID, UUID внутри группы сортируются. PageInfo применяется после группировки в памяти: страница содержит группы статусов, а не строки КТК. CASE-helper из промежуточного исправления 2cead392a сохранился в ReceivingOrderContainerDaoService, но текущий meta-метод его не вызывает.

Сортировка строк по containerStatus/container.containerStatus — отдельный SQL-подзапрос к регистру с COALESCE(..., DEPARTED). Фильтр родительской заявки в predicates привязан к receivingOrder/shippingOrder соответствующей строки; текущие meta-запросы также явно соединяют родителя. Фильтр, сортировка, DTO и meta — разные механизмы. Сентябрьские промежуточные изменения владельца при accept не заменяют текущую семантику selectedOwners, введённую позднее.

Исходники DAO-тестов 3786e33b2/e63fd99d7 проверяют порядок DEPARTED→EXPECTED→ON_TERMINAL, объединение отсутствующего owner с явным DEPARTED и страницу групп PageInfo.of(1,1)→EXPECTED. Это свидетельство предусмотренного поведения, без запуска тестов в рамках аудита.

## Формат ошибок перехода регистра

ContainerStatusService собирает нарушения до изменения регистра и группирует их по паре (код, номер конфликтующей заявки). Внутри группы коды КТК сортируются; сообщение имеет вид `ContainerStatus.<Code>: [<номер>; <КТК1>, <КТК2>]`, группы соединяются через `, `. При отсутствии номера перед `;` остаётся пустая строка. Выбрасывается один ValidationException. Это текст сообщения, а не массив структурированных ErrorDetails; прежние русские многострочные заголовки с маркерами не являются текущим контрактом.

Сентябрьский bfc92911d синхронизировал обратную ссылку Container.containerOwner при создании/удалении registry. Позднейший restore больше не удаляет registry при отсутствии предыдущего клиента: текущая семантика DEPARTED описана выше. Нельзя переносить историческую ветку удаления в описание HEAD.

## Целевая сверка read model 11.11.2026

Движения — отдельный контур: [основная строка и meta view](../database/container-movement-meta-as-is.md), active не равен ContainerOwner.status.

## Импорт и массовая запись выбранного владельца поставки

KIS-4716 заменил поиск собственника через ClientRelatedEntity клиента заявки на Client по коду. Авто- и ЖД-парсеры receiving при пустом коде возвращают NULL, при непустом используют ReceivingOrderContainerService.findOwnerByCode → clientDaoService.findByCode(...).orElseThrow(); явного ограничения client заявки или active в этом helper нет. При создании WaybillContainer из прямой receiving-строки ЖД-парсер копирует ownerContainer; существующая найденная строка этой веткой не перезаписывается.

ReceivingOrderContainerFilter.ownerContainer теперь ClientFilter; WaybillContainerFilter и ReceivingOrderWaybillContainerFilter также поддерживают ownerContainer как ClientFilter. Поле owner (строка внешней накладной) остаётся отдельным фильтром и не является UUID выбранного Client. Устаревшие in-memory toCarriagePredicate/toContainerPredicate удалены; актуальную фильтрацию выполняют DAO/predicates.

PUT /receivingorder/{id}/waybill-containers/owners сначала проверяет статус заявки через OrderServiceUtils, затем уникальность ID в списке. Пустой список после статусной проверки возвращается без изменений; дубликаты дают IllegalArgumentException, ID вне накладных заявки — NotFoundException. Все ненулевые Client ID разрешаются до записи; NULL ownerContainer очищает выбранного владельца. Обновляется модель WaybillContainer, а не текущий ContainerOwner registry. В этой выборке setOwners нет отдельного excluded=false: нельзя автоматически переносить сюда фильтрацию активных контейнеров из lifecycle.

Receiving route chain package включает выбранных владельцев в Client[]: для auto из прямых строк, для railway из WaybillContainer. Railway DTO передаёт ownerContainerId отдельно от текстового owner. Тестовое изменение 3bcf01137 заменяет fixture владельца ClientRelatedEntity на Client и проверяет selectedOwner вместо orderClient в lifecycle; тесты не запускались.

Источники: [ReceivingOrderContainerService](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/receivingordercontainer/ReceivingOrderContainerService.java), [WaybillContainerService](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/waybillcontainer/WaybillContainerService.java), [ReceivingOrderRailwayCarriageParser](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/parsing/order/parser/impl/ReceivingOrderRailwayCarriageParser.java), [ReceivingOrderAutoContainerYardParser](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/parsing/order/parser/impl/ReceivingOrderAutoContainerYardParser.java).

## Полная последовательность registry-переходов: сверка 11.11.2026

Поставка собирает уникальные физические КТК из прямых строк и активных Waybill-контейнеров, отбрасывает NULL, сортирует по UUID, блокирует через ContainerDaoService.findAndLock и загружает registry. В reserve выбранные владельцы обеих моделей обязательны и должны совпадать для одного КТК. Все нарушения собираются до выполнения переходов; сообщение группирует code/orderNumber и отсортированные коды КТК.

При reserveReceiving текущий status, отличный от DEPARTED, блокирует новую резервацию; переход в EXPECTED использует selectedOwners, не обязательно клиента заявки. markReceived сам по себе не проверяет прежний status: при существующем owner сохраняет его client, при отсутствии использует выбранного. ReserveShipping требует ON_TERMINAL, переводит в RESERVED_OUT с тем же владельцем. markShipped может создать registry при отсутствии записи, client тогда из shipping order, status DEPARTED.

Отмена из DRAFT/ON_REVIEW пропускает registry. Дополнительные проверки связи с конкретной отменяемой заявкой выполняются при previousOrderStatus=DONE; нельзя переносить их на все ранние статусы. Отмена поставки всегда сохраняет DEPARTED, прошлый client берётся из receiving reservation history; при его отсутствии сохраняется текущий client, registry больше не удаляется. Previous receiving/shipping order ищется до первой history отменяемой заявки, исключая REJECTED. History пишется при изменении status/client в transition, но restorePreviousOwner пишет собственную запись явно.

Переходы синхронизируют owner в неудалённых DRAFT/ON_REVIEW строках вывоза через уже описанный helper. Проверка блокировок/concurrency и полного rollback всех side-effects не проводилась. Исходная серия 9a05f552e и последующая смена selected owner/отмены читаются как история: текущую семантику задаёт HEAD.

## Завершение сверки 9a05f552e: вызывающие пути и тесты

Accept обеих заявок сначала выполняет validator, затем reserve регистра, затем сохраняет ACCEPTED. Reject передаёт в cancel регистра прежний статус до записи REJECTED. В TOS receiving markReceived вызывается после проверки завершения всех строк и сохранения DONE; shipping вызывает markShipped для обычного и дополнительного пути фактических КТК. Это завершение заявки, а не произвольное подтверждение одной незаконченной строки. ServiceOrder сохраняет отдельный ContainerOwnerService.changeOwners.

FeatureFlags и прежние receiving/shipping ContainerAlreadyInUse checks удалены из accept validators; конфликты теперь проверяет registry reserve. В ContainerService списки по остаткам/справочнику явно ставят excludeUsedInActiveOrders=false: наличие КТК в dropdown само по себе не обещает успешное резервирование. ContainerStatusResolver возвращает DEPARTED при NULL Container/registry; при существующей registry возвращает её status без дополнительного NULL fallback.

Review mappings заявок/рейса удалены, OrderStatusController исключает ON_REVIEW из списка, но enum и исторические значения остаются; RouteService допускает changeStatus только из DRAFT/ACCEPTED. RouteControllerTest ожидает 404 для прежнего review path. Уведомление перенесено на DRAFT→ACCEPTED: [точные условия listener](order-integrations.md).

В исходном ContainerStatusServiceIntegrationTest семь сценариев: отсутствие registry→DEPARTED, полный receiving/shipping цикл с history, смена клиента при приёмке, восстановление прежнего владельца, отмена первой завершённой/зарезервированной поставки и агрегирование двух конфликтов без изменения history. Первоначальные ожидания удаления registry при отмене и владельца-клиента заявки позднее заменены сохранением registry и selected owner; текущие правила выше. ContainerOwnerServiceIntegrationTest оставляет service-order owner change и NULL old/new status в его history. Unit tests TOS проверяют вызов markShipped вместо removeOwners; прежний accept usage-test удалён, а не доказывает новое reserve-покрытие. Java/SQL/HTTP/TOS-запуски и concurrency не проверялись.
