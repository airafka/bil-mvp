# Каталог бизнес-ошибок заявок

> **Сверено:** backend `3d3899d5d` (12.11.2026) · **Основание:** `SOURCE_CONFIRMED` — исходный код, миграции и тесты (тесты не запускались); БД и стенд не проверялись.

Эта таблица — про бизнес-коды `X.Что-то`, собираемые в один `ValidationException` при review/accept (источники: `ReceivingOrderAcceptValidator`, `ShippingOrderAcceptValidator`, `OrderCombinationValidator`, `ReceivingOrderService`, `ShippingOrderService`). Generic HTTP-уровневые коды иерархии `AlisException` (`AccessDenied`, `NotFound`, `Conflict` и т.д.) описаны в [модели ошибок HTTP API](error-model-as-is.md).

Ошибки accept собираются списком и объединяются через `", "`. В таблице `X` означает префикс `ReceivingOrder` или `ShippingOrder`. При accept через рейс каждая ошибка заявки дополнительно оборачивается в `Route.OrderService.Accept.<номер заявки>.<сообщение>` (см. [статусы](order-statuses.md#допустимые-переходы-orderstatus)).

## Общие для поставки и вывоза

| Код/шаблон | Когда возникает | Типы заявок |
|---|---|---|
| `X.InvalidStatus` | Недопустимый переход review/accept; у поставки также reject и confirm/unconfirm документа | транспортные |
| `X.MissingCurrency` | Не задана валюта | все варианты поставки/вывоза |
| `X.MissingPlannedReceivingDateTime` / `X.MissingPlannedShippingDateTime` | Не задана плановая дата | все варианты |
| `X.MissingTransport` | Заявка не назначена в рейс (`route == null`) | `WAREHOUSE+VEHICLE`, `CONTAINER+VEHICLE` |
| `X.MissingGoods` | Нет товаров при `deliveryType` ≠ `BY_CARGO` | склад |
| `XGood.MissingPlannedQuantity` | Плановое количество товара ≤ 0 | склад с товарами |
| `XGood.MissingPrice` | Цена товара ≤ 0 | склад с товарами |
| `XGood.MissingTotalPrice` | Общая цена товара ≤ 0 | склад с товарами |
| `X.MissingCargos` | Нет детальных грузовых мест | `BY_GOOD_WITH_CARGO_WITH_DETAILS` |
| `X.MissingCargo` | В строке груза нет ссылки на `Cargo` | детальный груз |
| `XCargo.MissingPackageQuantity` | Фактически: количество упаковок < 0 (`null` и 0 проходят) | детальный груз |
| `XCargo.MissingConversionQuantity` | Фактически: коэффициент < 0 | детальный груз |
| `XCargo.MissingTotalQuantity` | Фактически: итоговое количество < 0 | детальный груз |
| `X.MissingBlackbox` | `BY_CARGO` без blackbox; у поставки также `BY_GOOD_WITH_CARGO_WITHOUT_DETAILS` с `totalCargoQuantity = 0` | недетализированный груз |
| `X.MissingContainers` | Нет контейнеров | `CONTAINER+VEHICLE` (у вывоза — кроме `NONE_CONTAINER`) |
| `ReceivingOrderContainer.MissingOwnerContainer` | У КТК (кроме `ktkNumberUnknown=true`) нет владельца | контейнерная площадка поставки |
| ~~`ShippingOrderContainer.MissingOwnerContainer`~~ | Константа осталась, проверка не вызывается: с KIS-4716 (`156bcd48`, 25.09.2026) владелец у строки вывоза не валидируется — см. [регистр остатков и владельца КТК](container-remains-and-owner-as-is.md) | — |
| `<код КТК>.X.ItemsMissingForContainers` | Непорожний КТК (известный, не `ktkNumberUnknown`) не содержит items | контейнерная площадка |
| `<код КТК>.X.EmptyContainerCantHaveItems` | Порожний КТК содержит items | контейнерная площадка |
| `<номер заявки>.XContainer.KtkNumberUnknown` | Accept авто-заявки, где есть КТК с `ktkNumberUnknown=true` | `CONTAINER+VEHICLE` |
| `X.MissingRailwayCarriages` | Поставка: нет `WaybillRailwayCarriage`; вывоз: нет конкретных вагонов, а при `fillingType` `CONTAINER`/`NONE` — нет количественных | `CONTAINER+RAILWAY` |
| `X.MissingEtranInvoice` | Поставка: нет ЖД-накладной (`Waybill`); вывоз: нет ЭТРАН при `fillingType=ALL` | `CONTAINER+RAILWAY` |

Вес КТК (`null` или ≤ 0): у вывоза — `ShippingOrderContainer.Container.<код КТК>[.Railway.<код вагона>].MissingWeight` (только для известных КТК), у поставки — `ReceivingOrderContainer.MissingWeight` без идентификатора (для всех строк, кроме `ktkNumberUnknown=true`).

~~`X.ContainerAlreadyInUse`~~ — проверка занятости КТК удалена 21.09.2026 (`9a05f552`, KIS-4661); занятость теперь определяется регистром остатков, см. [регистр остатков](container-remains-and-owner-as-is.md).

## Только поставка

| Код | Условие |
|---|---|
| `ReceivingOrder.MissingShipper` | На контейнерной площадке не задан грузоотправитель |
| `ReceivingOrder.UndefinedRailwayCarriageType` | Accept (`RAILWAY`/`VEHICLE`): найден вагон накладной с типом `UNDEFINED`; выбрасывается сразу |
| `ReceivingOrder.UndefinedContainerType` | Accept на `CONTAINER`: КТК накладной (ЖД) или строки заявки (авто) имеет тип `UNKNOWN`; выбрасывается сразу |
| `ReceivingOrderContainerItem.MissingDescription` | Метод проверки существует, но не включён в карту вызовов |
| `payerId, departureStationId и destinationStationId обязательны …` | Create `CONTAINER+RAILWAY` без плательщика/станций (текст, не код) |

## Только вывоз

| Код | Условие |
|---|---|
| `ShippingOrder.MissingConsignee` | На контейнерной площадке не задан грузополучатель |
| `ShippingOrder.MissingRailwayCarriageEtranInvoice` | При `fillingType=ALL` вагон не связан с ЭТРАН |
| `ShippingOrder.InvalidNoneContainerData` | `NONE_CONTAINER`: не ровно одна `ShippingOrderContainerQty` с `quantity=1`, `empty=true` и без ЕТСНГ |
| `ShippingOrderContainerQty.InvalidNoneContainerData` | То же нарушение при сохранении строк безномерных КТК |
| `ShippingOrderContainerQty.MissingOwnerClient` | NONE_CONTAINER: все ownerClient пусты; смешанный список NULL/не-NULL не защищён этой allMatch-проверкой |
| `ShippingOrderContainerQty.OwnerHasNoOnTerminalContainers` | У выбранного ownerClient нет registry КТК со статусом ON_TERMINAL |
| `ShippingOrderContainerQty.MissingOwnerClientWithNeededContainerType` | ON_TERMINAL КТК есть, но нет нужного типа |
| `ShippingOrder.RejectNotAllowed` | Недопустим переход в `REJECTED` |
| `ShippingOrder.InvalidConsigneeClient` | Грузополучатель не принадлежит клиенту заявки (create/update) |
| `ShippingOrder.InvalidConsigneeRole` | Связанное лицо не имеет роли грузополучателя (create/update) |
| `ShippingOrderContainerItem.MissingDescription` | Константа существует, проверка не вызывается |

## Ошибки сохранения товарной строки (не review/accept)

С 13.10.2026 (`8ee1ab68`, KIS-4841) отдельный `ValidationException` с одним кодом (без префикса заявки) выбрасывается при add/update `ReceivingOrderGood`/`ShippingOrderGood`, HTTP 400. Подробнее — [валидация заявок](order-validation.md#партия-товарной-строки-уровень-3).

| Код | Условие |
|---|---|
| `OrderGood.BatchUnknownNotAllowed` | `batchUnknown=true` у номенклатуры без партионного учёта |
| `OrderGood.BatchUnknownWithBatch` | `batchUnknown=true` и одновременно передана партия |
| `OrderGood.MissingBatch` | Партионный учёт (`MANUFACTURE_DATE`/`EXPIRATION_DATE`), партии нет и `batchUnknown=false` |

Коды Excel-импорта номенклатуры (`clientGoods.*`) описаны в [импорте товаров Авто СК](order-goods-excel-import-as-is.md#коды-ошибок).

## Ошибки комбинаций

| Код | Условие |
|---|---|
| `ReceivingOrder.InvalidTerminalAreaTransportType` / `ShippingOrder.InvalidTerminalAreaTransportType` | ЖД выбрано не для контейнерной площадки (также `Route.InvalidTerminalAreaTransportType` для рейса) |
| `*.MissingDeliveryType` | Для склада + авто не задан `deliveryType` |
| `ShippingOrder.InvalidFillingType` | `NONE_CONTAINER` выбран не для контейнерной площадки + авто |

Связано: [типы заявок](order-types.md), [поставка](receiving-orders.md), [вывоз](shipping-orders.md), [статусы](order-statuses.md).

## Ошибки отмены (сверка 11.11.2026)

`Order.CancelRouteRequired` — контейнерная заявка из ACCEPTED отменяется без связанного рейса. Недостаточное право RejectAfterStart/DELETE для IN_PROGRESS/DONE даёт AccessDeniedException до изменения состояния. Ошибки чтения сохранённого payload фиксируются в outbound_data.error_message и расходуют попытку отправки, а не возвращаются из уже завершившегося reject. См. [контракт отмены](../integrations/order-cancellation-outbound-as-is.md).
