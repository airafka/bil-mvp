# Бизнес-правила заявки на поставку

> **Сверено:** backend `3d3899d5d` (12.11.2026) · **Основание:** `SOURCE_CONFIRMED` — исходный код, миграции и тесты (тесты не запускались); БД и стенд не проверялись.

`ReceivingOrder` специализирует транспортную заявку. Перед чтением этого раздела применяются общие [типы](order-types.md) и [статусные правила](order-statuses.md).

## Контракты и модель

- Сущность: [ReceivingOrder](../entities/catalog/entities/receivingorder/ReceivingOrder.md)
- Входные DTO: [create](../dto/receiving-order/ReceivingOrderCreationDto.md), [update](../dto/receiving-order/ReceivingOrderUpdateDto.md)
- Выходные DTO: [основной](../dto/receiving-order/ReceivingOrderDto.md), [карточка](../dto/receiving-order/ReceivingOrderDetailedDto.md)
- Таблицы: [модель БД заявок](../database/orders.md)
- Копирование: [общие правила копирования](order-copying.md#поставка)
- Интеграции: [исходящие сообщения поставки](order-integrations.md#поставка)
- Входящие результаты и завершение: [сравнение пяти Datareon actions](receiving-inbound-actions.md)
- Накладные ЭТРАН: [актуальный импорт, read API и связь с поставкой](waybill-etran-as-is.md)
- Ошибки: [каталог бизнес-ошибок](order-errors.md#только-поставка)
- Обязательные поля и порядок проверок: [карта валидации поставки](order-validation.md#поставка-корневой-request)
- PDF-отчёты: [MX-1, M-7 и общий availability AS-IS](order-pdf-reports-as-is.md)
- Excel-реестр: [корневые выгрузки V1/V2, фильтры и client scope](order-excel-exports-as-is.md)
- Дочерний Excel, часть 1: [blackbox, cargo, container и container-item V1/V2](receiving-order-child-excel-exports-as-is.md)
- Дочерний Excel, часть 2: [good, requested-service, Waybill и railway-carriage V1/V2](receiving-order-child-excel-exports-part2-as-is.md)

## Создание и редактирование

`POST /receivingorder/` использует [ReceivingOrderCreationDto](../dto/receiving-order/ReceivingOrderCreationDto.md), `PUT /receivingorder/{id}` — [ReceivingOrderUpdateDto](../dto/receiving-order/ReceivingOrderUpdateDto.md). Оба наследуют поля [ReceivingOrderBaseDto](../dto/receiving-order/ReceivingOrderBaseDto.md). Полная таблица обязательности create/update и условных требований приведена в [карте валидации](order-validation.md#поставка-корневой-request).

| ID | Правило |
|---|---|
| `BR-RO-001` | Новый объект всегда получает `DRAFT`; номер и UUID генерирует сервер. Если `defaultContainerOwner` не передан, им становится клиент заявки. |
| `BR-RO-002` | Проверяется и нормализуется комбинация площадки, транспорта и `deliveryType` по [матрице](order-types.md#матрица-реализованных-комбинаций). |
| `BR-RO-003` | После создания из условий договора добавляются обязательные `ReceivingOrderRequestedService` (`findRequiredByContractAndOrderType(contract, RECEIVING)`); при методе расчёта `REQUEST` плановое количество равно 1, иначе 0. |
| `BR-RO-004` | Цена обязательной операции без НДС = `plannedQuantity × rate`; цена с НДС вычисляется `VatCalculator`; операция помечается `systemManaged=true`, `actualQuantity=0`. |
| `BR-RO-005` | При update меняются договор, валюта, payer через непустой payerId, defaultContainerOwner (только непустой), контакт (только непустой), плановая дата, срок хранения, комментарий, грузоотправитель и waybill. Смена default owner также обновляет владельцев дочерних прямых/Waybill КТК. Рейс назначается операциями Route. |
| `BR-RO-006` | Клиент, номер, площадка, транспорт (`updatable=false` в `Order`/`TransportOrder`) и `deliveryType` (`updatable=false` в `ReceivingOrder`) неизменяемы после создания. |

Для CONTAINER + RAILWAY create требует payerId, departureStationId, destinationStationId без env-переключателя; иначе ValidationException. Update позволяет сменить payerId, но не станции; отсутствие/NULL payerId не очищает прежнего плательщика.

`GET|POST|PUT /receivingorder/{id}/total-cargo-quantity` читает/задаёт `totalCargoQuantity`; запись разрешена только при `deliveryType=BY_GOOD_WITH_CARGO_WITHOUT_DETAILS` (иначе `IllegalStateException`) и в редактируемом статусе.

## Общая валидация review и accept

Независимо от типа поставки обязательны:

| Условие | Ошибка |
|---|---|
| Задана валюта | `ReceivingOrder.MissingCurrency` |
| Задана `planReceivingDateTime` | `ReceivingOrder.MissingPlannedReceivingDateTime` |
| Для контейнерной площадки задан `shipper` | `ReceivingOrder.MissingShipper` |

## Матрица содержательной валидации

Это не повторная валидация `ReceivingOrderCreationDto`. Accept (вызывается из accept рейса) читает корень и дочерние сущности из БД. Конкретные DTO, которыми предварительно заполняются товары, грузы и КТК, перечислены в [карте DTO дочерних частей](order-validation.md#dto-дочерних-частей-агрегата).

| Площадка | Транспорт | Проверяемые части агрегата (`ReceivingOrderAcceptValidator`) |
|---|---|---|
| `WAREHOUSE` | `VEHICLE` | рейс; товары по `deliveryType`; детальные грузовые места; blackbox/общее количество |
| `CONTAINER` | `VEHICLE` | рейс; наличие контейнеров; вес и владелец КТК; согласованность empty/items |
| `CONTAINER` | `RAILWAY` | наличие накладной; наличие вагона в накладной; вес и владелец имеющихся `ReceivingOrderContainer`; согласованность empty/items |

### Склад + автомобиль

- Заявка назначена в рейс (`route != null`), иначе `ReceivingOrder.MissingTransport`.
- `BY_GOOD`: должна быть хотя бы одна `ReceivingOrderGood`.
- `BY_CARGO`: товарные строки не требуются, но должен существовать `ReceivingOrderBlackbox`.
- `BY_GOOD_WITH_CARGO_WITHOUT_DETAILS`: нужны товары и `totalCargoQuantity != 0`.
- `BY_GOOD_WITH_CARGO_WITH_DETAILS`: нужны товары и хотя бы один `ReceivingOrderCargo`.
- Для каждой требуемой товарной строки `plannedQuantity`, `price`, `totalPrice` должны быть больше 0.
- В детальном грузе обязательна ссылка `cargo`; код отклоняет отрицательные `packageQuantity`, `conversionQuantity`, `totalQuantity`, но допускает 0 и `null` как 0 — название ошибок `Missing*` шире фактической проверки.

### Контейнерная площадка + автомобиль

- Заявка назначена в рейс, иначе `ReceivingOrder.MissingTransport`.
- Нужен минимум один `ReceivingOrderContainer`, иначе `ReceivingOrder.MissingContainers`.
- Для всех строк, кроме `ktkNumberUnknown=true`, нужны вес > 0 и `ownerContainer`.
- Порожний КТК не может иметь items; непорожний должен иметь хотя бы один item (только для строк с известным КТК).
- Только при accept запрещён `ktkNumberUnknown=true`.
- Проверка занятости КТК другой заявкой (feature flag, `ContainerAlreadyInUse`) удалена 21.09.2026 (`9a05f552`, KIS-4661); резервирование выполняет `ContainerStatusService.reserveForReceivingOrder` при accept.

### Контейнерная площадка + ЖД

- Нужна хотя бы одна связанная [Waybill](../entities/catalog/entities/waybill/Waybill.md), иначе `ReceivingOrder.MissingEtranInvoice`.
- Нужен хотя бы один `WaybillRailwayCarriage`, иначе `ReceivingOrder.MissingRailwayCarriages`.
- Проверки веса, владельца и items выполняются по строкам `ReceivingOrderContainer`, а не по `WaybillContainer` (КТК ЖД-поставки живут в накладной) — для ЖД они фактически почти всегда пусты.
- Отдельная проверка наличия хотя бы одного КТК не вызывается. Это **вопрос/возможный пробел** для будущего ТЗ.

## Дополнительные проверки accept

- Для `RAILWAY` и `VEHICLE` наличие вагона накладной с типом `UNDEFINED` даёт `ReceivingOrder.UndefinedRailwayCarriageType` (выбрасывается сразу).
- Для `CONTAINER` наличие КТК с типом `UNKNOWN` (ЖД — в `WaybillContainer`, авто — в `ReceivingOrderContainer.container`) даёт `ReceivingOrder.UndefinedContainerType` (выбрасывается сразу).
- Для `CONTAINER + VEHICLE` неизвестный номер КТК даёт `<номер заявки>.ReceivingOrderContainer.KtkNumberUnknown`.
- Метод `containerItemChecks`, проверяющий пустой `description` item, существует, но не включён в карту валидаторов. Нельзя заявлять это правило действующим без исправления вызова.
- После успешной проверки: `ContainerStatusService.reserveForReceivingOrder`, статус `ACCEPTED`, outbound-строки (если не включён route chain package).

## Отклонение и документы

`PUT /receivingorder/{id}/reject` (permission `RECEIVING_ORDER_REJECT`) переводит заявку в `REJECTED`, отменяет резерв КТК (`ContainerStatusService.cancelReceivingOrder`) и удаляет все связи заявки с накладными. Тот же метод вызывается каскадом из `PUT /routes/{id}/reject`.

`PUT /receivingorder/{id}/confirm-document` и `/unconfirm-document` (permission `RECEIVING_ORDER_CONFIRM_DOCUMENT`) доступны только в `ACCEPTED` или `IN_PROGRESS`, иначе `ReceivingOrder.InvalidStatus`. Они однократно переводят `documentConfirmed` из `null` в `true` либо `false`; повторная смена запрещена (`IllegalStateException("Changing confirmation is not supported")`). Для каждого `ReceivingOrderContainer` заявки создаётся строка `outbound_data` с `CONFIRM_DOCS`.

## Накладные

Контроллер позволяет получить (`POST /receivingorder/{id}/waybills`) и заменить (`PUT …/waybills`) набор связанных накладных, читать сгруппированные по накладным вагоны, контейнеры и товары (`…/waybill-railway-carriages/page`, `…/waybill-containers/page`, `…/waybill-products/page`) и массово задавать владельцев КТК накладной (`PUT …/waybill-containers/owners`). Эти данные являются частью карточки поставки, но физически принадлежат агрегату `Waybill`.

Полный AS-IS, включая `POST /datareon/waybill`, DTO, bulk link/unlink, транзакции и ошибки, вынесен в [документ Waybill/ЭТРАН](waybill-etran-as-is.md). В частности, bulk-замена не проверяет статус заявки и может перепривязать накладную от другой поставки.

Поле фильтра/сортировки вагонов накладной `railwayCarriageType` (alias `sort`) на текущем коде работает по `railwayCarriage.sort` (`WaybillRailwayCarriagePredicate`, `WaybillRailwayCarriageDaoService`, `WaybillDaoService`); по типу вагона `railwayCarriage.type.code` сортирует только alias `type` в групповой сортировке накладных. Ранее упоминавшийся коммит `42eee4ee` (перевод на `type.code`) в историю `dev` не входит.

## Риски проектирования

1. ~~Публичный endpoint accept в `ReceivingOrderController` не найден.~~ Accept выполняется через `POST /routes/{id}/change-status/accept`; отдельного endpoint у заявки нет, review не вызывается.
2. `PUT /receivingorder/{id}` фактически использует `body.id`, не path ID.
3. Станции отсутствуют в update DTO и не меняются через общий update. payerId добавлен и сохраняется при непустой отличающейся ссылке.
4. `contact=null` не очищает текущий контакт из-за условного присваивания; `currency=null` в update приводит к NPE.
5. **Закрыто кодом 4c1cfe13d:** вагонная ветка CARRIAGE_ARRIVED учитывает обе контейнерные модели; WaybillContainer больше не игнорируются. Текущий запрос учитывает excluded. [Сверка](backend-behavior-changes-oct-nov-2026.md).
6. `STATUS_COMPLETED` завершает поставку без проверки вагонов, КТК, товаров и услуг; `WMS_RECEIVING_RESULT` вообще не меняет статус заявки.
7. [АНАЛИТИК] Фильтр `railwayCarriageType` по смыслу «тип вагона», а фактически фильтрует по сортности (`sort`) — нужно решение, какое поле имелось в виду.

Условия, эффекты, конфликты и тестовое покрытие этих веток разобраны в [карте входящих действий поставки](receiving-inbound-actions.md).

## Целевая сверка бизнес-изменений 11.11.2026

CARRIAGE_ARRIVED учитывает наличие прямых и Waybill-контейнеров; прежний риск их полного игнорирования исправлен. [Алгоритм](backend-behavior-changes-oct-nov-2026.md).
