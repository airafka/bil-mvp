# Недоступные исторические источники

Проверено 11.11.2026. В библиотеке было 21 неработающее вхождение ссылок на 13 файлов. Файлы не обнаружены в рабочем дереве, ZIP-архивах docs/docsforanalytics*.zip, доступной истории Git по ожидаемым путям и поиске по именам в соседних Documents/alis и Documents/Codex. Это не доказывает, что источники не существуют во внешнем хранилище.

Сломанные гиперссылки заменены названием с пометкой «источник недоступен» и ссылкой на этот реестр. Ожидаемые пути сохранены ниже. Новые документы с вымышленным содержимым не создавались. Старые утверждения о содержании источников в исследовательском реестре остаются историческими записями прежней сверки; повторно подтвердить их по отсутствующим оригиналам сейчас нельзя.

Материалы в колонке «Доступное описание» покрывают текущую backend-тему и не являются восстановленными копиями оригинала. Они не восстанавливают внешние алгоритмы, исторические схемы, исходное ТЗ или согласования.

| Ожидаемый путь | Вхождений | Где использовался | Доступное описание |
|---|---:|---|---|
| `docs/alis-container-stuffing-unstuffing-as-is.md` | 2 | [research/README.md](README.md) | [container-remains-and-owner-as-is](../business-rules/container-remains-and-owner-as-is.md), [service-order-lifecycle](../business-rules/service-order-lifecycle.md) |
| `docs/alis-empty-railway-shipping-order-event-analysis.md` | 1 | [research/README.md](README.md) | [shipping-railway-empty-completion](../business-rules/shipping-railway-empty-completion.md) |
| `docs/alis-waybill-railway-as-is.md` | 2 | [research/README.md](README.md), [business-rules/waybill-etran-as-is.md](../business-rules/waybill-etran-as-is.md) | [waybill-etran-as-is](../business-rules/waybill-etran-as-is.md), [waybill-supplementary-as-is](../business-rules/waybill-supplementary-as-is.md) |
| `docs/integrations/1c-edo-contract-with-contractor-api.md` | 3 | [research/README.md](README.md), [business-rules/contract-edo-datareon-as-is.md](../business-rules/contract-edo-datareon-as-is.md), [business-rules/contractor-edo-datareon-as-is.md](../business-rules/contractor-edo-datareon-as-is.md) | [contract-edo-datareon-as-is](../business-rules/contract-edo-datareon-as-is.md), [contractor-edo-datareon-as-is](../business-rules/contractor-edo-datareon-as-is.md) |
| `docs/integrations/etran-container-activity.puml` | 1 | [research/README.md](README.md) | [etran-reference-imports-as-is](../business-rules/etran-reference-imports-as-is.md) |
| `docs/integrations/etran-container-sequence.puml` | 1 | [research/README.md](README.md) | [etran-reference-imports-as-is](../business-rules/etran-reference-imports-as-is.md) |
| `docs/integrations/etran-container.md` | 2 | [research/README.md](README.md), [business-rules/etran-reference-imports-as-is.md](../business-rules/etran-reference-imports-as-is.md) | [etran-reference-imports-as-is](../business-rules/etran-reference-imports-as-is.md) |
| `docs/integrations/etran-railway-activity.puml` | 1 | [research/README.md](README.md) | [etran-reference-imports-as-is](../business-rules/etran-reference-imports-as-is.md) |
| `docs/integrations/etran-railway-sequence.puml` | 1 | [research/README.md](README.md) | [etran-reference-imports-as-is](../business-rules/etran-reference-imports-as-is.md) |
| `docs/integrations/etran-railway.md` | 2 | [research/README.md](README.md), [business-rules/etran-reference-imports-as-is.md](../business-rules/etran-reference-imports-as-is.md) | [etran-reference-imports-as-is](../business-rules/etran-reference-imports-as-is.md) |
| `docs/integrations/ktk-lifecycle-as-is.md` | 1 | [research/README.md](README.md) | [container-remains-and-owner-as-is](../business-rules/container-remains-and-owner-as-is.md), [remain-inbound-as-is](../business-rules/remain-inbound-as-is.md) |
| `docs/integrations/tz-1c-edo-contract-with-client-api.md` | 1 | [research/README.md](README.md) | TO-BE источник не восстановлен; подтверждённой замены нет |
| `docs/integrations/waybill-reference-lookup-bug.md` | 3 | [research/README.md](README.md), [business-rules/waybill-etran-as-is.md](../business-rules/waybill-etran-as-is.md), [_meta/PROGRESS.md](../_meta/PROGRESS.md) | [waybill-etran-as-is](../business-rules/waybill-etran-as-is.md) |

## Как восстановить оригиналы

Если будет найден исходный архив или репозиторий, вернуть файлы по ожидаемым путям либо зафиксировать их новое расположение. Перед восстановлением гиперссылок проверить версии, отделить исторический AS-IS от TO-BE и повторно сверить существенные выводы. PlantUML-оригиналы нельзя заменять новой диаграммой без явной пометки о реконструкции.

Нулевая ошибка локальных ссылок после этой правки означает структурную целостность библиотеки, а не восстановление этих 13 источников или полную достоверность прежних исследований.
