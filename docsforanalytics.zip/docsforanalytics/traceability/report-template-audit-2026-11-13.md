# Статическая сверка шаблонов отчётов, 13.11.2026

Локальный commit `3d3899d5d615ae4ec1edb10bfa7a8a8bd0f2dcde`. Сверены controller → collector → DTO/mapper → resource; XLSX прочитаны как ZIP/XML. Проверены root getter expressions 15 действующих root/child order XLSX по полям текущих DTO с наследованием. Это не выполнение JXLS/JasperReports: nested null, синтаксис JEXL, оформление и фактический HTTP-ответ требуют отдельного запуска.

| Resource | Подтверждённое расхождение по исходникам |
|---|---|
| `receiving_order_container.xlsx` | `getCustomClearance()`, `getDangerousCargo()`, `getRefrigerator()` отсутствуют в `ReceivingOrderContainerDto`; актуальное поле таможенного оформления — `customsClearance` |
| `receiving_order_requested_service.xlsx` | `getPriceWithVat()` / `getPriceWithoutVat()` не совпадают с `getPriceWithVAT()` / `getPriceWithoutVAT()`; дополнительно в `getTermOfRequestedService.getCode()` пропущены `()` |
| `shipping_order_container.xlsx` | `getCustomClearance()`, `getDangerousCargo()`, `getRefrigerator()`, `getOwnerContainer()` отсутствуют в `ShippingOrderContainerDto`; актуальные поля — `customsClearance`, `containerOwner` |
| `receiving_order_waybill.xlsx` | Отсутствует в репозитории, хотя `PageReportType.RECEIVING_ORDER_WAYBILL_EXPORT` ссылается на этот путь. Legacy `receiving_order_etran_invoice.xlsx` использует другой parameter и DTO, автоматической замены нет |

Первые три шаблона ожидаемо падают при вычислении соответствующих expressions на непустой выборке; у Waybill ошибка ожидается при открытии отсутствующего resource после mapping. Пустая выборка не подтверждает исправность expressions. Настройки JXLS и общий exception path дают основание ожидать ошибку генерации, но статус HTTP после начала streaming отдельно не воспроизводился.

Совпадение имён getter в остальных 12 проверенных XLSX не доказывает успешную генерацию: например, в `shipping_order_container_item.xlsx` сохранено compound assignment в ЕТСНГ expression. Бинарные шаблоны и Java в этой сверке не исправлялись.

Источник путей: [PageReportType](../../../web-layer/src/main/java/ru/korusconsulting/alis/dto/report/PageReportType.java). Подробности: [receiving 1](../business-rules/receiving-order-child-excel-exports-as-is.md), [receiving 2](../business-rules/receiving-order-child-excel-exports-part2-as-is.md), [shipping 1](../business-rules/shipping-order-child-excel-exports-as-is.md), [shipping 2](../business-rules/shipping-order-child-excel-exports-part2-as-is.md), [матрица доступа](../business-rules/order-report-access-as-is.md). Отдельно сверены исходники [PDF](../business-rules/order-pdf-reports-as-is.md) и [отчётов рейса](../business-rules/route-reports-as-is.md); их runtime-рендеринг также не выполнялся.
