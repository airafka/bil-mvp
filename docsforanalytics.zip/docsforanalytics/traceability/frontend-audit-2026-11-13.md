# Сверка frontend: 13.11.2026

> Первичный обзор последних коммитов. Расширение области до 01.09.2026 и итоговый реестр — [сверка 159 frontend-коммитов](frontend-audit-since-september-2026.md). Границы ниже относятся к первому этапу.

Основание: локальный HEAD `05fc6ddd386570e206e4279520a9caa8638fbeb3`. История после прежнего среза `ab02fa985` просмотрена через `git log ab02fa985..HEAD --no-merges`; это диапазон графа Git, поэтому в нём есть коммиты с датой раньше 14 октября. Remote не запрашивался, runtime и развёрнутая версия не проверялись.

## Подтверждённые изменения последних коммитов

| Коммиты | Изменение и источник |
|---|---|
| `7be8f468e` | Рейс: сохранение даже неизменённой формы проверяет отсутствие `dataTime`, вызывает `validateForm` с alert и прерывается с ошибкой. `src/features/Routes/configs/MainInfo/useMainInfoEdit.tsx`. |
| `09a0473aa` | Настройка knip и очистка неиспользуемых экспортов, адаптеров и старых конфигураций; это также изменения API модулей, а не только конфигурация анализатора. `knip.jsonc`, `src/features/Routes/api/index.ts`, `src/features/ShippingOrder/hooks/useShippingOrderMutations.ts`. |
| `35156ad66` | Исправлена иконка группы номенклатуры в `src/assets/icons/index.tsx`; изменение не доказывает исправление бизнес-правил группы. |
| `abe0e8fae` | Досылочные накладные: запрос связанных документов, условная вкладка, две боковые панели и вложенные записи групповой таблицы. Подробности — в [UI-правилах ЭТРАН](../business-rules/waybill-ui-rules-as-is.md#актуализация-13112026-связанные-накладные). |
| `99ad5bf69`, `800f6fb15` | Приоритет CSS в Preview вывоза и поставки (`UI/Preview/styles.ts`); самостоятельного изменения API нет. |
| `cc115fed6` | Номенклатура: числовые строки преобразуются через `Number`, пустое значение — в `null`, некорректное число отклоняется. Цена nullable, срок годности обязателен; ограничения `>= 0` в схеме нет. `src/features/ClientGood/UI/MainInfo/edit-config/schema.ts`. |
| `7e9ae0390` | Изменён текст ошибки групп пользователей в `public/locales/ru/Shared.json`; серверное поведение этим коммитом не изменяется. |
| `f21b37f57`, `840764c1f` | Удалены старая секция Move карточки КТК и её frontend API/queries; текущая конфигурация карточки содержит MainInfo и Owner. Это не доказательство удаления серверного API или других экранов движения. |
| `d2744a5f0` | Изменён текст в `.gitlab-ci.yml`; пользовательский UI не затронут. |

## Границы актуализации

Детально сверены перечисленные изменения 5–11 ноября и текущие исходники соответствующих экранов. Остальная история ниже — инвентаризация, а не заявление о полной проверке всех UI-паспортов. В ней есть отмена заявок и права отмены, валидация пользователей, собственник КТК, упаковки, создание груза и preview CI. Эти более ранние изменения требуют отдельной сверки соответствующих контрактов; старые даты паспортов сохранены.

## Дополнительная сверка frontend после уточнения области

Проверены diff и текущие исходники отмены заявок/рейсов, пользователя, ОКПО, родительских упаковок, создания груза и фильтров. Результаты внесены только в UI-документы:

- [Заявки](../business-rules/order-ui-rules-as-is.md): `b72ec3b90`, `9c0e958e6`, `f7521f469`, `2adf21a81`, `a27a18dd7`, `d05849cec`, `2340ddd2b`, `800888f73`, `f9a19c706`, `a6824c613`.
- [Рейсы](../business-rules/route-ui-rules-as-is.md): `fba8c97d3`, `2adf21a81`, `7be8f468e`.
- [Администрирование](../business-rules/admin-ui-rules-as-is.md): `2c31a3dbd`.
- [Справочники](../business-rules/dictionary-ui-rules-as-is.md): `50bdb6b45`, `19e6d0fd3`, `1ff36343f`, `ba7163eda`, `f84f097a7`.

Важные уточнения по diff: коммит с названием про дубликат ИНН/КПП добавляет только текст ошибки; ОКПО допускает три конкретные длины; телефон без цифр проходит схему; сообщения про TOS отражают решение UI и не доказывают доставку уведомления. Коммиты backend и backend-документы не проверялись и не изменялись. Остальные коммиты в инвентаризации сохраняют статус неполной предметной сверки.

## Инвентаризация диапазона

| Commit | Дата автора | Сообщение |
|---|---|---|
| `7be8f468e` | 2026-11-11 | KIS-4955 fix section route edit line date |
| `09a0473aa` | 2026-11-11 | knip config |
| `d2744a5f0` | 2026-11-11 | chore: describe changes without internal tracking references |
| `35156ad66` | 2026-11-11 | KIS-4981 fix goodGroup |
| `abe0e8fae` | 2026-11-10 | KIS-4946 Досылочные |
| `800f6fb15` | 2026-11-10 | KIS-4960 add important for another specific update |
| `99ad5bf69` | 2026-11-06 | KIS-4960 add important for specific update |
| `cc115fed6` | 2026-11-06 | KIS-4957 add error for paste string to number input |
| `7e9ae0390` | 2026-11-06 | KIS-4909 fix user-group error |
| `840764c1f` | 2026-11-05 | delete move API |
| `f21b37f57` | 2026-11-05 | delete move |
| `800888f73` | 2026-11-04 | re:fix |
| `2340ddd2b` | 2026-11-04 | add redirect in KP-Vehicle |
| `50a3a28f6` | 2026-11-03 | KIS-4872 fix owner KTK |
| `133bafd57` | 2026-11-02 | Revert "Merge branch 'fix/KIS-4930' into 'dev'" |
| `c018fa559` | 2026-11-02 | KIS-4930 ClientGood schema fix |
| `d05849cec` | 2026-10-29 | KIS-4926 create cargo |
| `2bbd460c1` | 2026-10-29 | fix unknownKTK |
| `cd4fbd811` | 2026-10-29 | regenerate package-lock file |
| `ba7163eda` | 2026-10-28 | KIS-4877 added unsaved packages to the parent package drop-down list |
| `1ff36343f` | 2026-10-28 | KIS-4877 added unsaved packages to the parent package drop-down list |
| `a61315799` | 2026-10-28 | KIS-4872 pre push |
| `659db280f` | 2026-10-28 | ci(preview): developers deploy previews via verified requests |
| `3a36c1f80` | 2026-10-27 | ci(preview): one-button preview environments for MRs |
| `7e06c3a15` | 2026-10-27 | ci: build and package frontend images for preview environments |
| `8664a6b6f` | 2026-10-27 | chore: bump UIKIT to 19.5.3 |
| `a48eae8f2` | 2026-10-27 | fix shippingOrder nameSpace |
| `13075c31c` | 2026-10-27 | update ui-kit |
| `0ddd6fd9c` | 2026-10-27 | fix receivingOrder nameSpace |
| `a202c4dc8` | 2026-10-26 | fix for Linar |
| `19e6d0fd3` | 2026-10-26 | KIS-4915 show alert when a client with INN and KPP already exists |
| `10145348d` | 2026-10-26 | KIS-4914 fic waybill breadcrumbs |
| `d21822026` | 2026-10-26 | KIS-4283 transferr download button on new prop |
| `668137e51` | 2026-10-26 | KIS-4872 proto front wo bnd |
| `fba8c97d3` | 2026-10-26 | fix for permission cancel route |
| `2adf21a81` | 2026-10-23 | fix alert |
| `f7521f469` | 2026-10-23 | KIS-4886 add permission verification process for order cancellation |
| `a27a18dd7` | 2026-10-23 | KIS-4902 Собственник КТК не изменяется при редактировании |
| `9c0e958e6` | 2026-10-22 | cancel orders |
| `59f7da228` | 2026-10-22 | KIS-4886 prettier check |
| `b72ec3b90` | 2026-10-22 | KIS-4886 add cancellation order |
| `f3f1ab725` | 2026-10-22 | KIS-4877 fix bug to sprint |
| `2c31a3dbd` | 2026-10-21 | KIS-4900 validate phoneNumber and email when creating/editing a user |
| `6f21b7161` | 2026-10-20 | KIS-4498 replace native func on typeguarded func translate |
| `45a77f9f6` | 2026-10-19 | Bump other libs |
| `f84f097a7` | 2026-10-19 | Fix railway carriage meta filter search |
| `b6de046f8` | 2026-10-19 | KIS-4847 fix railwaySimpleEdit |
| `aef68b2e7` | 2026-10-19 | KIS-4837: merge dev |
| `a6824c613` | 2026-10-16 | KIS-4842 fix filters name->code |
| `deab89253` | 2026-10-16 | KIS-4881 ref TEXT_AREA in Routes and Orders |
| `b2fd1beac` | 2026-10-15 | KIS-4842 edit column fix |
| `50bdb6b45` | 2026-10-15 | KIS-4868 okpo 8-14 digit |
| `f9a19c706` | 2026-10-15 | KIS-4841 fix field acticle and nomenclature |
| `b78f2255a` | 2026-10-15 | KIS-4863 first selected row fix |
| `6d67f3ce8` | 2026-10-08 | KIS-4844 hiden cancel button for rejected receiving and shipping orders |
| `254c782c1` | 2026-10-08 | KIS-4843 fix Route layout |
| `aab59d2d8` | 2026-10-08 | KIS-4837 linkDrawer to client in the ClientDriver section in the view mode |
| `879718bd5` | 2026-10-08 | KIS-4837,KIS-4836 fix ClientDriver create/edit validation |
| `030cd7185` | 2026-10-07 | KIS-4834_KIS-4835 fix duplicate save requests |
| `14ed28f1b` | 2026-10-06 | KIS-4833 delete OverflowText in the Routes frame for receiving and shipping orders |
| `09fa6099e` | 2026-09-30 | docs: describe frontend stage image release workflow |
| `348550cd3` | 2026-09-30 | test: assert stage environment rejection behavior only |
| `c3e7dd994` | 2026-09-30 | ci: complete frontend image provenance artifact |
| `52193d9ae` | 2026-09-30 | ci: add stage env validator behavioral regression test to unit-test |
| `b419661c6` | 2026-09-30 | ci: enforce format/lint/typecheck gating on stage create-docker-image via rules:needs and remove CI rules assertion test |
| `eb6ae1a72` | 2026-09-30 | ci: implement approved STAGE release publication and gating checks |
| `1957626ec` | 2026-09-05 | feat: prepare isolated nonproduction Keycloak realm cutover |

