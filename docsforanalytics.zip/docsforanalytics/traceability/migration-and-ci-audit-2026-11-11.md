# Границы сверки migration runner и CI

Срез 3d3899d5d, дополнен 12.11.2026. Документ навигирует изменения вне бизнес-контрактов. Серии migration runner и preview рассмотрены по исходникам и истории. Проверка развёрнутых CI/security, выполнение миграций и раскатка не проводились.

## Что уже описано в корневом README

Серия a2b4f2033 → 251caf089 → 574aff4e4 → b856f3979 → 83946805f → 77f939a0f → 34a6581df и 790c69f23 формирует standalone Liquibase runner и публикацию STAGE. Последовательность важна: старое промежуточное classpath-поведение не является текущим контрактом.

Текущий README и код runner согласуются по проверенным точкам:

- validate/status/update без Spring/JPA/schedulers;
- пароль через stdin, параметры соединения — env; bare PostgreSQL JDBC URL без query, TLS verify-full;
- проверки database/login/effective role/schema и ограниченные timeout;
- stdout — одна JSON-строка, библиотечный вывод подавляется;
- финальный resource accessor — DirectoryResourceAccessor объединённого дерева db-layer + wms-layer;
- приоритет MIGRATION_CHANGELOG_DIR → system property migration.changelog.dir → /opt/alis/migration/changelogs; отсутствие каталога — ошибка;
- validate/status — read-only, существующие таблицы реестра и lock проверяются; это не dry-run полноценного update на production.

README описывает упаковку lib/changelogs и STAGE GitOps, артефакт image.env, условия активации. Приведённое там утверждение «не активировано» является заявлением автора документа на его срезе; фактическое состояние CI/кластера этой сверкой не установлено. Для аналитики БД основной результат — [цепочка схемы](../database/schema-changes-2026-09-11.md); operational детали принадлежат корневому README.

## Preview и форматирование

4096c4851 разделяет MR build и упаковку, db4766427 добавляет deploy/lifecycle/environment/stop и pairing, edc5c9eab заменяет прямой cross-project trigger запуском внешнего request.py. Все три diff и итоговые локальные скрипты сверены; границы внешних разрешений приведены ниже. Продуктовые API эта серия не меняет.

8db28aca7 меняет только два комментария CI/Dockerfile — бизнес-документация не требуется. cb6b3d198 меняет assertion migration-теста на Path.toString для Windows, production runner не меняется. 1a8ea8d9f добавляет fetch dev для сборки; c9801de74 меняет CI chmod на wrapper и включает настройки форматирования. 7a0c75530 перестраивает build.gradle ratchet — это build tooling, не новая предметная операция; полный Gradle/CI прогон не проводился.

Сомнение по a8cb5107e разрешено отдельной проверкой lexical tokens ниже: runtime-контракт не менялся. Одного ненулевого whitespace-insensitive diff для такого вывода было недостаточно.

7a0c75530 удалил динамический поиск ratchet base через fetch/merge-base всех remote branches и заменил его фиксированным origin/dev только вне CI. c9801de74 затем сделал ratchetFrom origin/dev общим для local/CI, убрал отключение SpotlessCheck в CI и оставил check.dependsOn(spotlessCheck). Отдельная прежняя зависимость build→spotlessCheck удалена; build проходит через check. CI chmod теперь выдаёт execute только ./gradlew вместо рекурсивного +rwx всему checkout. Эти два diff рассмотрены полностью; pipeline не запускался. Наличие доступного origin/dev важно для ratchet, а fetch dev рассмотрен отдельно в 1a8ea8d9f.

## Standalone runner: завершение source-level сверки 12.11.2026

Сопоставлены все 690 строк текущего runner, 392 строки тестов, launcher, buildMigrationRunner, Dockerfile и изменённые CI/README-части восьми коммитов серии. Это проверка итоговой реализации и её происхождения, без подключения к БД.

| Область | Точный текущий контракт |
|---|---|
| CLI / пароль | Ровно один аргумент validate/status/update, trim/lowercase; пароль — первая UTF-8 строка stdin без trim, пустая строка/EOF запрещены. Остальные настройки trim-ятся обычным env helper |
| TLS | sslmode=verify-full без env-выключателя; CA: MIGRATION_SSLROOTCERT → PGSSLROOTCERT → читаемый /etc/alis/postgres-ca/ca.crt; явно указанный нечитаемый путь — ошибка |
| Таймауты | connect 15 s (1–60), socket 240 s (10–600), lock 5000 ms (500–60000); statement 15000 ms для read-only, 180000 ms для update (1000–600000); idle 15/60 s |
| Сессия | currentSchema=alis,public; options задаёт effective role/search_path/read-only/таймауты. Guard сравнивает database, effective role, session user и current_schema с ожидаемыми, без учёта регистра |
| Lock | locked=true и отсутствующая строка id=1 запрещены; SQL ошибки запроса запрещены, **кроме 42P01** (нет таблицы), который guard явно пропускает для bootstrap. Guard не снимает lock |
| validate | Liquibase.validate, valid=true при успехе; не является запуском DDL |
| status | Ledger читается по ключу id\|author\|filePath; pending разделяется на новый/ранее зарегистрированный, передаются current/stored checksum и runAlways/runOnChange |
| update | ChangeExecListener.ran собирает записи; rerunCount только ExecType.RERAN, прочие callback-типы попадают в newCount. Это число callback-записей, не число SQL statements |
| Завершение update | После update повторно читается pending; любой pending без runAlways вызывает ошибку. Допустимые оставшиеся runAlways не входят в проверку, но pendingRemaining в успешном JSON жёстко равен 0 — это не буквальный размер pendingAfter |
| Checksum | Используется latest ChecksumVersion; при ошибке вычисления checksum возвращается NULL, не отдельный отказ runner |

status идентифицирует changeset по полному исходному filePath, без собственной нормализации пути; одного совпадения id недостаточно. Интерпретация RERAN в 83946805f заменила прежнее ошибочное приравнивание любого runAlways к повторному запуску.

### Ошибки и границы обещания «одна JSON-строка»

Внутри Java run config-отказы печатаются в переданный out. На время JDBC/Liquibase System.out/System.err заменены null-stream и восстанавливаются finally, библиотечный вывод не накапливается в памяти. SQL-ошибка выдаёт SQLState и фиксированную сводку без SQL/данных строки. Приоритет классификации: прямой IllegalArgumentException → CONFIGURATION_ERROR, прямой IllegalStateException → INVARIANT_VIOLATION, затем найденная SQL cause, затем ValidationFailed/Lock/Liquibase exceptions, иначе EXECUTION_ERROR. Для SQL префиксы 08/23/40/42/53/57 выделены в отдельные категории; остальные DATABASE_ERROR.

Config/invariant messages проходят только regex-masking известных password/pwd/secret форм; это не универсальный анализ произвольных чувствительных строк. Обычные прочие runtime messages заменяются фиксированным текстом. JSON создаёт Jackson; аварийный fallback сериализации проще и не доказывает эквивалентность полного JSON escaping.

Фраза README «ровно одна JSON-строка при любой ошибке» требует ограничения: если java не найдена, launcher пишет JSON **в stderr**, не stdout; ошибка запуска JVM происходит до Java runner. Кроме того, успешный JSON печатается до закрытия try-with-resources: `INFERENCE` — исключение close после печати может привести к последующей ERROR-строке. Такой сбой не воспроизводился и не покрыт просмотренными тестами. Безусловное утверждение об одном результате для всех возможных отказов исходниками не доказано.

### Упаковка и publisher

История accessor: сначала каталог db-layer, затем временный classloader в b856f3979, затем окончательное on-disk объединение db-layer+wms-layer в 77f939a0f. 34a6581df устанавливает приоритет env над system property; каталог должен существовать. buildMigrationRunner копирует jar/runtimeClasspath, executable bin/migrate и db/** обоих модулей, DuplicatesStrategy.FAIL запрещает коллизии. Dockerfile проверяет launcher/master changelog и копирует дистрибутив в /opt/alis/migration под UID 10001. Основной ENTRYPOINT остаётся Spring Boot jar; наличие runner не запускает update при старте контейнера.

create-docker-image сохраняет image.env как dotenv и обычный artifact (7d): image repository/tag/digest/reference, builder/runtime references, IMAGE_JOB_ID именно packaging-job, project/pipeline/SHA/ref/protected provenance. Старый fallback IMAGE_JOB_ID к publisher-job удалён; копирование image.env в внешний GitOps checkout также удалено. publish-gitops-image имеет needs на build/test/package и сериализацию resource_group, получает digest и вызывает внешний scripts/publish-gitops-image.sh backend ENVIRONMENT repository tag@digest. Образ в Dockerfile собирается с исключёнными test/integrationTest; проверки — отдельные pipeline jobs. Реальные protected flags/переменные и поведение внешнего GitOps-скрипта этим репозиторием не подтверждены. Заявление README о создании MR относится к внешнему компоненту.

### Что подтверждают исходники тестов

16 unit tests проверяют CLI/config отказы, query-параметры JDBC, bounds, отсутствие echo пароля, safe SQL/generic errors, четыре identity mismatch, env/property приоритет/accessor и занятый lock. Они не содержат успешного полного validate/status/update на PostgreSQL, всех ExecType/checksum веток, bootstrap 42P01/пустой lock row/permission-error и ошибки close после успешной печати. Исходники изучены без запуска. Read-only режим требует доступного ledger для операций Liquibase; bootstrap update не является универсальным dry-run.

## Что остаётся проверить

Внешние lifecycle/GitOps контракты, фактическую конфигурацию среды, сборку дистрибутива и интеграционный прогон runner на синтетической БД. Source-level серии runner/preview закрыты; команды update/deploy, доступ к БД, секретам и внешним сервисам не выполнялись.

## Preview: полный локальный контракт

Workflow исключает Draft MR pipelines. Ручной preview:deploy предлагается для MR в dev из того же проекта, allow_failure=true и needs=[]: успех тестовых jobs не является его prerequisite. Сборка выполняет bootJar и buildMigrationRunner с -x test -x integrationTest. Общий before_script объединяет target/source; SOURCE_COMMIT_SHA для MR берётся из CI_COMMIT_SHA и не является отдельным hash содержимого собранного jar или проверкой HEAD после merge.

По умолчанию PREVIEW_ID=p{project}-m{MR}; PREVIEW_PAIR=frontend!{iid} использует peer project 2. ID проверяется regex ^p[1-9][0-9]{0,5}-m[1-9][0-9]{0,6}$. Counterpart разрешён только для pipeline на preview-packaging с PREVIEW_BUILD_REF=dev: fetch origin dev и detached checkout FETCH_HEAD. Произвольный ref эта ветка не принимает.

Build artifact preview-out содержит service.jar, migration/, preview.env, preview-source.env и preview-deploy.env; срок 2d. Dotenv передаёт ID, paired, counterpart=skip/build, source job ID и URL. preview:lifecycle зависит от deploy и запускает request.py deploy. preview:environment зависит от обоих jobs, регистрирует preview/mr-{iid}, URL, stop action и auto_stop_in=72 hours. Это регистрация среды, без локальной HTTP health-check.

Общий request job с GIT_STRATEGY=none клонирует alis/preview-lifecycle через CI_JOB_TOKEN и запускает внешний Python-файл. Clone depth=1 не закреплён commit SHA. Комментарии называют PREVIEW_TRIGGER_TOKEN/PREVIEW_LIFECYCLE_READ_TOKEN; значения и наличие переменных не проверялись. Код проверки verified request, текущей generation, полномочий и согласования paired deploy находится вне backend. Название коммита не доказывает реализацию этих проверок здесь.

preview:stop — manual/allow_failure, needs=[], собственный p{project}-m{MR}, request.py destroy. Build artifacts ему не нужны. Обещание комментария о запрете остановки чужой generation/парного preview зависит от внешнего request/lifecycle и локальным кодом не подтверждается.

Упаковка preview-package-backend разрешена для web/api/pipeline на preview-packaging при numeric source job ID либо build ref dev; непосредственно script всё равно требует PREVIEW_SOURCE_JOB_ID. Статус protected ветки/runner задаётся GitLab, его нельзя вывести из имени ветки или комментария. Artifact скачивается через JOB-TOKEN из того же project/job; ZIP с абсолютными/parent paths отклоняется. Проверяются четыре обязательных entry, совпадение PREVIEW_ID и 40 hex source SHA. Это проверки структуры/provenance полей, не самостоятельная аттестация доверия к MR artifact.

Контекст Docker содержит фиксированный copy-only preview/Dockerfile.package, service.jar и migration/. Этот Dockerfile не выполняет MR build-скрипты: RUN отсутствует. Runtime base разрешается в digest; UID=10001, порт 8080, Spring jar ENTRYPOINT. Публикуется alis-preview/backend:{id}-{8sha}; preview-image.env хранит repository@digest, source provenance и packaging pipeline URL, срок 30d. Preview publisher отделён от STAGE publisher. Фактические deploy, доступы runner/secrets, очистка MR и callback внешнего lifecycle без его исходников и запуска не подтверждены.

## Источники

- [README.md](../../../README.md)
- [StandaloneLiquibaseRunner.java](../../../db-layer/src/main/java/ru/korusconsulting/alis/migration/StandaloneLiquibaseRunner.java)
- [StandaloneLiquibaseRunnerTest.java](../../../db-layer/src/test/java/ru/korusconsulting/alis/migration/StandaloneLiquibaseRunnerTest.java)
- [.gitlab-ci.yml](../../../.gitlab-ci.yml)
- [Dockerfile.package](../../../preview/Dockerfile.package)

## Разрешение вопроса a8cb5107e

При дополнительной проверке сравнили Java lexical tokens parent→commit с исключением пробелов/комментариев, сохраняя строковые литералы. Для StandaloneLiquibaseRunner.java и StandaloneLiquibaseRunnerTest.java последовательности токенов совпали. Следовательно, ненулевой git diff -w объясняется переносами строк/оформлением, нового runtime-контракта в этом коммите нет. Тем же способом подтверждено отсутствие смысловых Java-изменений в 86d2dc4fa. Это точнее предыдущего предварительного вывода по одной статистике -w.
