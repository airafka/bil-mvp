# Аудит backend-документации: 1 сентября — 11 ноября 2026

Срез: ветка `dev`, HEAD `3d3899d5d615ae4ec1edb10bfa7a8a8bd0f2dcde`. Проверяется рабочая копия документации, включая подготовленные пользователем изменения. История: коммиты, достижимые из HEAD, с датой committer начиная с 01.09.2026 00:00 MSK; без merge, 117 записей. Remote не обновлялся.

**Состояние на 12.11.2026: source-level сверка всех 117 коммитов диапазона завершена; 117 описано, 0 частично.** Каталоги и затронутые ручные контракты сопоставлены с локальным HEAD. Это аудит изменений диапазона, а не доказательство соответствия каждого исторического документа всей кодовой базе или работающей среде. Java/SQL/HTTP/CI/PDF не запускались; frontend и внешние системы не перепроверялись. Предыдущие блоки ниже сохраняют историю промежуточных результатов; текущий итог — тринадцатый блок.

## Подтверждённые расхождения

Исходный список находок на старте аудита; действия по ним выполнены в последующих блоках. Не следует читать формулировки «нужно» в этой таблице как текущую очередь. Отсутствующие внешние оригиналы обозначены явно, а не восстановлены.

| ID | Приоритет | Факт реализации | Пробел и действие |
|---|---|---|---|
| AUD-001 | P1 | `f89ddd3b9`: `outbound_data.payload TEXT`, nullable, без DEFAULT; include в v.1.35.0/cumulative.yml | В паспорте OutboundData поле отсутствует. Нужны поле в каталоге и физическая модель таблицы. |
| AUD-002 | P1 | OrderCancellationService сохраняет сериализованный пакет для CONTAINER; route обязателен; RECEIVING_ORDER_CANCEL/SHIPPING_ORDER_CANCEL. OrderCancelExportService читает сохранённый JSON, отвергает пустой/невалидный payload; scheduler fixedDelay по умолчанию 5000 мс | В order-integrations отсутствуют эти типы сообщений и сценарий сохранения/отправки отмены. Описать также условия enqueue, транзакцию, ошибки и повторную отправку после чтения BaseExportService и вызывающих сервисов. Payload не следует автоматически добавлять в публичный DTO: в текущем OutboundDataDto его нет. |
| AUD-003 | P1 | `930a1d076`: Waybill содержит parent identifier, parent FK, connection type; появились WaybillConnectionType и RelatedDocument DTO | Каталог Waybill не содержит трёх полей; новые паспорта отсутствуют. Ручные правила требуют сверки обработки связанных накладных и порядка их поступления. |
| AUD-004 | P1 | ShippingOrderContainerQty.ownerClient хранится в owner_client_id | В паспорте сущности поле отсутствует. Сверить миграцию, create/update, merge, фильтры и outbound. |
| AUD-005 | P2 | ReceivingOrderUpdateDto содержит payerId с @Valid | В DTO-каталоге поле отсутствует. Перепроверить ранее описанное расхождение UI-DIFF-07 и правила редактирования плательщика. |
| AUD-006 | P2 | ClientCreationDto/ClientUpdateDto: OKPO допускает 8, 10, 14 цифр или пустую строку | Каталог ещё описывает 10 цифр. Физическую длину проверять отдельно по миграции. |
| AUD-007 | P2 | check_docs.py: 739 Markdown, 8188 локальных ссылок, 63 отсутствующие цели; незакрытых fences и trailing whitespace нет | Включает ссылки на удалённые исходники и отсутствующие соседние материалы. 64 frontend-ссылки без frontend-root не проверены. |
| AUD-008 | P2 | README указывает backend 14.10.2026, coverage-matrix — 22.09.2026 | Даты и заявления покрытия расходятся; обновить после завершения аудита, не объявлять текущий HEAD полностью сверенным заранее. |

## Доказательства для outbound

- [OutboundData.java](../../../db-layer/src/main/java/ru/korusconsulting/alis/model/outbounddata/OutboundData.java)
- [v.1.35.0_20261021_order_cancel_payload.sql](../../../db-layer/src/main/resources/db/changelog/v.1.35.0/v.1.35.0_20261021_order_cancel_payload.sql)
- [OrderCancellationService.java](../../../web-layer/src/main/java/ru/korusconsulting/alis/datareon/service/ordercancel/OrderCancellationService.java)
- [OrderCancelExportService.java](../../../web-layer/src/main/java/ru/korusconsulting/alis/datareon/service/ordercancel/OrderCancelExportService.java)
- [ScheduledOrderCancelExportService.java](../../../web-layer/src/main/java/ru/korusconsulting/alis/datareon/service/ordercancel/ScheduledOrderCancelExportService.java)

## Сверка генерируемых каталогов

Генераторы запущены с OUTPUT во временной папке. Сравнивались строки Markdown-таблиц. Это обнаруживает структурные изменения, но не доказывает полноту генератора или бизнес-описания. Отличия ссылок и строк исходника также могут давать шум. Удалённые паспорта учитываются отдельно.

| Каталог | Отличающиеся/новые страницы, включая индекс |
|---|---|
| entities | 19 |
| dto | 34 |
| api | 1 |

### entities

| Страница | Статус | Изменившиеся поля (кандидаты) |
|---|---|---|
| `entities/catalog/README.md` | отличается |  |
| `entities/catalog/entities/datareoninbound/InboundEvent.md` | отличается | `terminalArea` |
| `entities/catalog/entities/route/Route.md` | отличается | `dataTime` |
| `entities/catalog/entities/clientgood/ClientGood.md` | отличается | `unitOfMeasure` |
| `entities/catalog/entities/goodpackage/GoodPackage.md` | отличается | `unitOfMeasure` |
| `entities/catalog/entities/shippingordercontainer/ShippingOrderContainer.md` | отличается | `containerOwner`, `ownerContainer` |
| `entities/catalog/entities/railway/RailwayCarriageMetaView.md` | нет паспорта | `active`, `axlesCount`, `code`, `dateDepotRepair`, `id`, `length`, `liftingCapacity`, `mileage`, `mileageRate`, `model`, `noworkingParking`, `owner`, `proxyOperator`, `remainingMileage`, `sort`, `type`, `volume`, `weight` |
| `entities/catalog/entities/receivingordercontainer/ReceivingOrderContainer.md` | отличается | `ownerContainer` |
| `entities/catalog/entities/waybillcontainer/WaybillContainer.md` | отличается | `excluded` |
| `entities/catalog/entities/container/Container.md` | отличается | `weight` |
| `entities/catalog/entities/container/ContainerMetaView.md` | нет паспорта | `containerTypeISO`, `id` |
| `entities/catalog/entities/shippingordercontainerqty/ShippingOrderContainerQty.md` | отличается | `ownerClient` |
| `entities/catalog/entities/waybill/WaybillConnectionType.md` | нет паспорта | `code`, `id`, `name` |
| `entities/catalog/entities/waybill/Waybill.md` | отличается | `waybillCategory`, `waybillConnectionType`, `waybillParent`, `waybillParentIdentifier` |
| `entities/catalog/entities/waybill/WaybillView.md` | отличается | `type`, `waybillCategory`, `waybillParentId` |
| `entities/catalog/entities/outbounddata/OutboundData.md` | отличается | `payload` |
| `entities/catalog/entities/transportpackage/TransportPackage.md` | отличается | `unitOfMeasure` |
| `entities/catalog/entities/containerremainview/ContainerRemainView.md` | отличается | `clientId` |
| `entities/catalog/entities/waybillrailwaycarriage/WaybillRailwayCarriage.md` | отличается | `excluded` |

Паспорта без соответствующего файла в свежей генерации (проверить удаление/переименование; не удалять автоматически):

- `mapped-superclasses/base/Sequential.md`
- `mapped-superclasses/base/PrioritizedWithId.md`
- `entities/dictionary/DictionaryParameter.md`
- `entities/dictionary/DictionaryLineParameter.md`
- `entities/dictionary/DictionaryLine.md`
- `entities/dictionary/Dictionary.md`
- `entities/uom/UnitOfMeasureConversion.md`
- `entities/uom/UnitOfMeasure.md`

### dto

| Страница | Статус | Изменившиеся поля (кандидаты) |
|---|---|---|
| `dto/catalog/README.md` | отличается |  |
| `dto/catalog/receivingordergood/ReceivingOrderGoodCreationDto.md` | отличается |  |
| `dto/catalog/receivingordergood/ReceivingOrderGoodDto.md` | отличается |  |
| `dto/catalog/wms/IdCodeDto.md` | отличается |  |
| `dto/catalog/wms/BaseCodedCreationDto.md` | отличается |  |
| `dto/catalog/shippingorderrequestedservice/ShippingOrderRequestedServiceDto.md` | отличается |  |
| `dto/catalog/shippingorderrequestedservice/ShippingOrderRequestedServiceCreationDto.md` | отличается |  |
| `dto/catalog/datareon/inbound/WaybillIntegrationDto.Waybill.RelatedDocument.md` | нет паспорта | `waybill_connection_type` |
| `dto/catalog/datareon/inbound/WaybillIntegrationDto.Waybill.md` | отличается | `related_document`, `waybill_parent_identifier` |
| `dto/catalog/shippingordercontainer/ShippingOrderContainerDto.md` | отличается | `containerOwner`, `ownerContainer` |
| `dto/catalog/shippingordercontainer/ShippingOrderContainerCreationDto.md` | отличается | `containerOwner`, `ownerContainer` |
| `dto/catalog/shippingordercontainer/ShippingOrderContainerUpdateDto.md` | отличается | `containerOwner`, `ownerContainer` |
| `dto/catalog/shippingordercargo/ShippingOrderCargoCreationDto.md` | отличается |  |
| `dto/catalog/shippingordercargo/ShippingOrderCargoDto.md` | отличается |  |
| `dto/catalog/containerowner/ContainerOwnerCodeNameDto.md` | нет паспорта | `code`, `id`, `name`, `onTerminalCount` |
| `dto/catalog/receivingorderblackbox/ReceivingOrderBlackboxDto.md` | отличается |  |
| `dto/catalog/receivingorderblackbox/ReceivingOrderBlackboxCreationDto.md` | отличается |  |
| `dto/catalog/shippingordergood/ShippingOrderGoodCreationDto.md` | отличается |  |
| `dto/catalog/shippingordergood/ShippingOrderGoodDto.md` | отличается |  |
| `dto/catalog/receivingordercontainer/ReceivingOrderContainerCreationDto.md` | отличается |  |
| `dto/catalog/receivingordercontainer/ReceivingOrderContainerDto.md` | отличается |  |
| `dto/catalog/shippingorder/validator/ShippingOrderAcceptValidator.md` | отличается | `containerOwnerDaoService`, `validators` |
| `dto/catalog/shippingordercontainerqty/ShippingOrderContainerQtyUpdateDto.md` | отличается | `ownerClient` |
| `dto/catalog/shippingordercontainerqty/ShippingOrderContainerQtyCreationDto.md` | отличается | `ownerClient` |
| `dto/catalog/shippingordercontainerqty/ShippingOrderContainerQtyDto.md` | отличается | `ownerClient` |
| `dto/catalog/receivingorder/ReceivingOrderUpdateDto.md` | отличается | `payerId` |
| `dto/catalog/waybill/WaybillStationPairGroupDto.WaybillDto.md` | отличается | `children`, `type` |
| `dto/catalog/waybill/WaybillDetailedDto.md` | отличается | `waybillCategory` |
| `dto/catalog/waybill/WaybillRelatedDocumentDto.md` | нет паспорта | `connectionTypeCode`, `connectionTypeName`, `id`, `number` |
| `dto/catalog/receivingorderrequestedservice/ReceivingOrderRequestedServiceCreationDto.md` | отличается |  |
| `dto/catalog/receivingorderrequestedservice/ReceivingOrderRequestedServiceDto.md` | отличается |  |
| `dto/catalog/routetocargochainpackage/ShippingOrderContainerChainPackageDto.md` | отличается | `containerOwnerId`, `ownerContainerId` |
| `dto/catalog/client/ClientUpdateDto.md` | отличается | `okpo` |
| `dto/catalog/client/ClientCreationDto.md` | отличается | `okpo` |

Паспорта без соответствующего файла в свежей генерации (проверить удаление/переименование; не удалять автоматически):

- `receivingordergood/ReceivingOrderGoodMultipleCreationDto.md`
- `wms/BaseLinkCreationDto.md`
- `wms/ResultDto.md`
- `wms/IdLineNumberDto.md`
- `wms/CountDto.md`
- `wms/IdSequentialDto.md`
- `wms/Restrictable.md`
- `wms/user/UserPermissionDto.md`
- `wms/dictionary/DictionaryLineUpdateDto.md`
- `wms/dictionary/DictionaryUpdateDto.md`
- `wms/dictionary/DictionaryLineParameterUpdateDto.md`
- `wms/dictionary/DictionaryParameterDto.md`
- `wms/dictionary/DictionaryLineCreationDto.md`
- `wms/dictionary/DictionaryLineDetailedDto.md`
- `wms/dictionary/DictionaryLineParameterCreationDto.md`
- `wms/dictionary/DictionaryParameterCreationDto.md`
- `wms/dictionary/DictionaryLineParameterDto.md`
- `wms/dictionary/DictionaryDto.md`
- `wms/dictionary/DictionaryParameterUpdateDto.md`
- `wms/dictionary/DictionaryLineSimpleDto.md`
- `wms/dictionary/DictionaryCreationDto.md`
- `wms/uom/UnitOfMeasureConversionUpdateDto.md`
- `wms/uom/BaseUnitOfMeasureSimpleDto.md`
- `wms/uom/UnitOfMeasureUpdateDto.md`
- `wms/uom/UnitOfMeasureConversionDto.md`
- `wms/uom/BaseUnitOfMeasureCreationDto.md`
- `wms/uom/BaseUnitOfMeasureDetailedDto.md`
- `wms/uom/UnitOfMeasureConversionCreationDto.md`
- `wms/uom/UnitOfMeasureCreationDto.md`
- `wms/uom/UnitOfMeasureDetailedDto.md`
- `wms/uom/UnitOfMeasureSimpleDto.md`
- `wms/uom/BaseUnitOfMeasureUpdateDto.md`
- `receivingordercargo/ReceivingOrderCargoMultipleCreationDto.md`
- `receivingordercargo/ReceivingOrderCargoDetailedDto.md`

## Реестр всех коммитов диапазона

Для каждой записи перечислены затронутые слои по списку файлов. Статус «ожидает» означает необходимость ручного чтения diff и сопоставления с документами; поиск номера задачи не считается доказательством покрытия. CI, форматирование и тесты требуют решения о влиянии после просмотра diff.

| Коммит | Дата | Изменение | Затронутые слои | Семантическая сверка |
|---|---|---|---|---|
| `8db28aca7` | 2026-11-11 | chore: describe changes without internal tracking references | CI/config | описано: только комментарии CI; продуктовой правки не требует |
| `930a1d076` | 2026-11-10 | KIS-4947 implement supplementary waybill support | БД, entity, DTO, API, поведение, тесты, CI/config | описано: полный source diff, exports/entity-info и оба integration test сопоставлены |
| `93915517d` | 2026-11-10 | KIS-4958 fix receiving order client meta filtering | поведение | описано: текущее правило и границы, source-level |
| `7898d0aaa` | 2026-11-10 | KIS-4951 fix: rm dot in error messages | поведение | описано: source-level; ограничения/риски зафиксированы |
| `8f622a62e` | 2026-11-09 | KIS-4969 fix: set data-time when copy | entity, поведение | описано: текущее правило и границы, source-level |
| `907bbe2a8` | 2026-11-09 | KIS-4958 fix receiving order client filter predicate | поведение, тесты | описано: текущее правило и границы, source-level |
| `471133b1f` | 2026-11-09 | KIS-4969 fix: set data-time when copy route | поведение | описано: текущее правило и границы, source-level |
| `818586514` | 2026-11-09 | KIS-4959 fix: error while receiving Cargo-Weight | entity | описано: текущее правило и границы, source-level |
| `9155b20a8` | 2026-11-09 | KIS-4968 fix: set containerQuantity for endpoint /findById | поведение | описано: текущее правило и границы, source-level |
| `5665d28d8` | 2026-11-05 | KIS-4951 fix: edit error msg | поведение | описано: source-level; ограничения/риски зафиксированы |
| `127231712` | 2026-11-05 | KIS-4870 endpoint /countcontaineronterminal | поведение | описано: добавление всех нулевых Client в count описано |
| `976343904` | 2026-11-04 | KIS-4920 Add client validation for nomenclature Excel import | поведение, тесты | описано: текущее правило и границы, source-level |
| `45e6620a1` | 2026-11-04 | KIS-4935 improve encapsulation in services | поведение | описано: DI и инкапсуляция, прежние load/status/user restriction сохранены |
| `966422467` | 2026-11-04 | KIS-4933 fix railway tariff payer update in receiving order | entity, DTO, поведение | описано: контракт и ручные правила, source-level |
| `8846daaef` | 2026-11-03 | KIS-4870 fix pagination error messages | DTO, API, поведение | описано: source-level; ограничения/риски зафиксированы |
| `42ee5f7e6` | 2026-11-03 | KIS-4927 fix shipping container owner meta test | поведение, тесты | описано: только test meta alias, описан точный контракт |
| `fe843b900` | 2026-11-03 | KIS-4936 synchronize owners in unaccepted shipping orders | БД, DTO, поведение, тесты, CI/config | описано: все DAO/service/mapper/SQL и тестовый diff propagation/snapshot |
| `a5c497dbf` | 2026-10-30 | KIS-4780 fix endpoint meta and countcontaineronterminal | DTO, поведение | описано: ветки accept, count и буквальный meta-path; учтены последующие правки |
| `3b356429b` | 2026-10-28 | KIS-4870 fix: /merge and add filter | DTO, API, поведение | описано: POST/body count, ClientDto и update/merge ownerClient |
| `8517b6c25` | 2026-10-28 | KIS-4870 fix: mapping for ShippingOrderContainerQty | поведение | описано: qty ownerClient mappings уже описаны, diff перепроверен |
| `edc5c9eab` | 2026-10-28 | ci(preview): developers deploy previews via verified requests (alis-3ws.7) | CI/config | описано: request.py delegation, локальные проверки и внешние границы lifecycle |
| `050d52ee8` | 2026-10-28 | KIS-4870 test: fix integrationTest | DTO, поведение, тесты | описано: creation/response JSON containerOwner и тесты описаны |
| `7d92a3277` | 2026-10-28 | KIS-4870 add column owner_client_id in table shipping_order_container_qty | БД, entity, DTO, API, поведение, тесты, CI/config | описано: qty owner/rename/outbound/TOS; ограничения фильтров отдельно зафиксированы |
| `db4766427` | 2026-10-27 | ci(preview): one-button preview environments for MRs (alis-3ws.6.4) | CI/config | описано: deploy/lifecycle/environment/stop, pairing и counterpart dev |
| `cb6b3d198` | 2026-10-27 | fix migration runner test path assertion on windows | тесты | описано: только Windows assertion теста; production не меняется |
| `b25f1cb27` | 2026-10-27 | KIS-4639 add cargo creation endpoint with uniqueness validation. | API, поведение | описано: source-level; ограничения/риски зафиксированы |
| `4096c4851` | 2026-10-27 | ci: build and package backend images for preview environments | CI/config | описано: build/package artifact, Docker context/digest/provenance и ограничения |
| `3677c832e` | 2026-10-26 | KIS-4894 fix duplicate client creation by INN and KPP | API, поведение | описано: source-level; ограничения/риски зафиксированы |
| `1db3d70b3` | 2026-10-23 | KIS-4901 Include service orders in container owner history | API, поведение, тесты | описано: source-level; ограничения/риски зафиксированы |
| `5b7ea1d74` | 2026-10-23 | KIS-4885 update integration tests | поведение, тесты | описано; source-level, см. блок outbound |
| `ce792561e` | 2026-10-23 | KIS-4885 update spotless | БД, поведение, тесты | описано; source-level, см. блок outbound |
| `8f158bad5` | 2026-10-23 | KIS-4885 add permission validate for cancellation of order process | БД, entity, поведение, тесты, CI/config | описано; source-level, см. блок outbound |
| `972912a2c` | 2026-10-22 | KIS-4885 update spotless | поведение, тесты | описано; source-level, см. блок outbound |
| `f89ddd3b9` | 2026-10-22 | KIS-4885 add cancellation order | БД, entity, DTO, поведение, тесты, CI/config | описано; source-level, см. блок outbound |
| `f6cfeb3c0` | 2026-10-21 | KIS-4899 correct test | поведение, тесты | описано: source-level; ограничения/риски зафиксированы |
| `86d2dc4fa` | 2026-10-21 | KIS-4899 update for spotless | поведение, тесты | описано: source-level; ограничения/риски зафиксированы |
| `20209781a` | 2026-10-21 | KIS-4899 add ContainerTypeISO sub-package to routechainpackage | DTO, поведение, тесты | описано: source-level; ограничения/риски зафиксированы |
| `859aec456` | 2026-10-20 | KIS-4888 fix waybill category fixtures and container movement tests | DTO, поведение, тесты | описано: fixtures/assertions категории и движения, без production-изменения |
| `545a1ebfd` | 2026-10-19 | KIS-4888 Fix KTK owner synchronization when receiving order default owner changes | поведение | описано: source-level; ограничения/риски зафиксированы |
| `91ad166bf` | 2026-10-19 | KIS-4795 Add waybill category | БД, entity, DTO, поведение, CI/config | описано: converter/JSON, resolver, persisted lifecycle и SQL DELETE-backfill |
| `f88b0f608` | 2026-10-19 | remove unused /multipleaddition endpoints | DTO, API, поведение | описано: восемь multipleaddition, DTO/helpers/cargoIsNull; текущая API-карта исправлена |
| `b42ab46f7` | 2026-10-19 | Fix railway carriage meta filter search | БД, entity, API, поведение, тесты, CI/config | описано: обе meta view, predicates/DAO/controller/filter contract и test exclusion |
| `87ccc2682` | 2026-10-19 | enable hibernate schema validation and fix problems | БД, entity, тесты, CI/config | описано: validate config/JPA/UUID/enum/CHAR, SQL и changeset identities сверены |
| `3b30f5466` | 2026-10-19 | KIS-4431 fix find etsng_code for Railway | поведение | описано: текущее правило и границы, source-level |
| `74c11bf96` | 2026-10-19 | KIS-4773 delete unused code in wms-layer | БД, entity, DTO, API, поведение, тесты, CI/config | описано: 174 удаления, whitelist компонентов, единственная DDL и error helper |
| `82c91f46d` | 2026-10-19 | KIS-4716 remove legacy owner column | БД, entity, CI/config | описано: итоговый cleanup SQL/JPA и include сверены |
| `4c1cfe13d` | 2026-10-16 | KIS-4883 fix order container existence check in carriage arrived action | entity, DTO, поведение | описано: текущее правило и границы, source-level |
| `29c96653f` | 2026-10-16 | KIS-4841 fix filter for order cargo | поведение | описано: текущее правило и границы, source-level |
| `2fccd6bf5` | 2026-10-16 | KIS-4841 fix filter for shipping | поведение | описано: текущее правило и границы, source-level |
| `e9fa1fc04` | 2026-10-15 | KIS-4841 fix search in filter | поведение | описано: текущее правило и границы, source-level |
| `63ccdfca8` | 2026-10-15 | KIS-4874 extended okpo field for client and company tables | БД, CI/config | описано: контракт и ручные правила, source-level |
| `c013c54e6` | 2026-10-15 | KIS-4873 typo fix in container TN | прочее | описано: статический текст ТН исправлен; бизнес-модель не меняется |
| `ba455a62e` | 2026-10-15 | KIS-4867 validated okpo | DTO | описано: контракт и ручные правила, source-level |
| `c0724fd89` | 2026-10-15 | KIS-4841 fix meta filter for field article and name | поведение | описано: source-level; ограничения/риски зафиксированы |
| `059d5f5a1` | 2026-10-14 | KIS-4861 delete filter by waybill status | поведение | описано: снятие исключения статуса кандидатов Waybill уже описано |
| `a4e3b5f84` | 2026-10-13 | fix(db): KIS-4665 idempotent unknown railway carriage model insert (dev) | БД | описано: идемпотентный SQL seed и changeset identity описаны |
| `51bce2217` | 2026-10-13 | fix(db): KIS-4665 idempotent unknown railway carriage model insert (stage) | БД | описано: тот же seed patch; дублирующее происхождение описано |
| `8ee1ab684` | 2026-10-13 | KIS-4841 add batchUnknown | БД, entity, DTO, поведение, тесты, CI/config | описано: batchUnknown, WMS/outbound, все warehouse parser ветки, ValidateUtil и тестовый diff |
| `a8cb5107e` | 2026-10-12 | stpoless apply | тесты | описано: Java tokens совпадают, только форматирование |
| `a1238ba1f` | 2026-10-12 | KIS-4830 expose newClient in container owner history | DTO, API, поведение, тесты | описано: newClient и удалённый orderClient отражены в history contract |
| `143d3a43d` | 2026-10-08 | KIS-4830 filter owner history by container status | API, поведение, тесты | описано: newStatus history фильтр описан с последующим SERVICE_ORDER bypass |
| `401bbea3d` | 2026-10-08 | KIS-4830 fix container ownership handling and container excel templates | БД, entity, DTO, API, поведение, тесты, CI/config | описано: snapshot/restore/history/TOS, все parser/collector изменения, XLSX и test diff |
| `34a6581df` | 2026-09-30 | fix(migration): honor MIGRATION_CHANGELOG_DIR override over the packaged default and guarantee a single JSON line on stdout for all actions | тесты, документация | описано: env priority, stdout suppression и границы one-line обещания |
| `790c69f23` | 2026-09-30 | docs(readme): document standalone migration runner, STAGE GitOps publication workflow, authoritative changelog resource contract and activation limits | документация | описано: README сопоставлен с runner/CI; launcher/external GitOps ограничения отмечены |
| `77f939a0f` | 2026-09-30 | fix(migration): extract union changelog tree on disk (Liquibase cannot resolve relative includes inside jars), publish source provenance in image.env, drop image.env copy from publisher job | тесты, CI/config | описано: union resources, Docker guard, provenance и удалённый image.env copy |
| `83946805f` | 2026-09-30 | fix(migration): precise ExecType.RERAN classification and remove obsolete changelog dir property from migrate launcher | прочее | описано: RERAN строго по ExecType и история launcher property |
| `b856f3979` | 2026-09-30 | fix(migration,ci): use ClassLoaderResourceAccessor over candidate jars, discard stderr via nullOutputStream, fail closed on changelog lock errors, and remove publisher job fallback | тесты, CI/config | описано: временный classloader/lock exceptions/stderr/fallback; учтён итоговый accessor |
| `574aff4e4` | 2026-09-30 | fix(migration,ci): enforce single DirectoryResourceAccessor, bare JDBC URL, ChangeExecListener update completion, bounded error categories, and archive image.env artifact | тесты, CI/config | описано: listener/status identities/counts/error categories/artifact; source-level |
| `251caf089` | 2026-09-30 | fix(migration): enforce strict TLS verify-full, reject JDBC URL overrides, preserve verbatim password whitespace, and redact failed SQL payloads | тесты | описано: TLS/bare URL/password/error masking; ограничения и тестовые ветки описаны |
| `a2b4f2033` | 2026-09-30 | feat(ci,migration): add protected stage publisher rules and standalone liquibase runner | тесты, CI/config | описано: runner/bootstrap packaging/STAGE rules и итоговая последовательность рассмотрены |
| `1a8ea8d9f` | 2026-09-29 | fix spotless in CI | CI/config | описано: CI fetch dev; отражено в infrastructure note |
| `156bcd48b` | 2026-09-25 | KIS-4716 more fixes for containerOwner in /list | DTO, поведение | описано: промежуточный merge mapping и снятие owner check описаны |
| `3ea781dde` | 2026-09-25 | KIS-4716 add ownerContainer to /list endpoint | поведение | описано: ContainerDto registry mapping отражён с итоговым контрактом |
| `2a9bc32f5` | 2026-09-25 | KIS-4716 restore container owner in /list endpoint | DTO, поведение | описано: исторический возврат owner в row DTO отражён |
| `7c7d4ec90` | 2026-09-25 | KIS-4716 move container owner to container dto | DTO, поведение | описано: разделение ETRAN owner и registry owner отражено |
| `78d692a35` | 2026-09-24 | KIS-4357 feat: valid comment in route | DTO | описано: create comment @Size уже описан; перепроверено |
| `5274443e7` | 2026-09-24 | KIS-4583 add few dates in ContainerTN document | поведение | описано: даты и ЗПУ ТН описаны по collector/JRXML |
| `8271bad78` | 2026-09-24 | remove railway fields required flag | DTO, поведение, тесты, CI/config | описано: service-level обязательные ЖД-поля и IdDto уже описаны |
| `d30d77adf` | 2026-09-24 | KIS-4093 delete receiving/shipping order transport | БД, entity, DTO, API, поведение, тесты, CI/config | описано: schema/backfill/API/manifest/reports, service/mapper и тестовый diff |
| `a912531c5` | 2026-09-23 | add json logging for contract_with_contractor datareon endpoint | API | описано: JsonNode logging без сохранения описан |
| `e233a9f3a` | 2026-09-23 | KIS-4716 fix logic and tests | поведение, тесты | описано: selectedOwners вместо клиента заявки, source/test assertions сверены |
| `1eef7cd93` | 2026-09-22 | Revert "KIS-4716 drop old owner container field" | БД, entity, CI/config | описано: revert cleanup, учтён итоговый 82c91f46d |
| `e8eed7fe7` | 2026-09-22 | KIS-4716 drop old owner container field | БД, entity, CI/config | описано: cleanup SQL/JPA, учтён последующий revert и восстановление |
| `3bcf01137` | 2026-09-22 | KIS-4716 add container owner management for receiving orders | БД, entity, DTO, API, поведение, тесты, CI/config | описано: parser/ClientFilter/bulk owners/export/fixtures, итоговый контракт описан |
| `e63fd99d7` | 2026-09-22 | KIS-4661 Correct filter and grouping by status owner | поведение, тесты | описано: parent filter, Java-группировка meta и тестовые assertions; учтён selected owner |
| `2cead392a` | 2026-09-22 | KIS-4661 Correct status expression | поведение | описано: промежуточный CASE-helper; текущий meta его не вызывает |
| `3d771b8a2` | 2026-09-21 | KIS-4661 KTK remains | поведение, тесты | описано: удаляет assertions тестов, бизнес-контракта не добавляет |
| `3786e33b2` | 2026-09-21 | KIS-4661 Update error processing for container remains | поведение, тесты | описано: sort/meta, null nested mapping и формат ошибок registry |
| `e1968e562` | 2026-09-21 | KIS-4583 update container TN | поведение, тесты | описано: collector/helper/tests и XML parameters/style/fonts/layout сопоставлены без PDF render |
| `8a81eb302` | 2026-09-21 | KIS-4661 update mapper in order to fix problem with empty... | поведение | описано: вложенный Container mapper; отсутствие искусственного nested DTO |
| `bfc92911d` | 2026-09-21 | KIS-4661 KTK remains | поведение | описано: обратная ссылка ContainerOwner; удаление впоследствии заменено restore |
| `9a05f552e` | 2026-09-21 | KIS-4661 KTK remains | БД, entity, DTO, API, поведение, тесты, CI/config | описано: registry, DTO/mappers, accept/reject/TOS wiring, removed usage/review и tests |
| `f11ff7ba9` | 2026-09-18 | add empty api for contract with contractor | API | описано: no-op endpoint описан |
| `f1c71971b` | 2026-09-18 | fix test | поведение, тесты | описано: test ожидает DB violation вместо UniqueViolationException |
| `a5a40f94e` | 2026-09-17 | remove datareon monitoring | API, поведение, тесты, CI/config | описано: все группы удаления monitor: REST/контроллеры/remains/config/CI/Helm |
| `c9801de74` | 2026-09-17 | enable spotless in ci | CI/config | описано: SpotlessCheck в CI/local, check dependency и chmod wrapper |
| `575ae6b90` | 2026-09-16 | KIS-4724 unify Spring Validation handling to legacy ApiErrorDto | API, тесты | описано: последняя validation error и DTO подтверждены |
| `8e9b494bf` | 2026-09-16 | add handler for AlisException and map to old error dto | API | описано: AlisException→legacy DTO подтверждено |
| `d24879c6e` | 2026-09-16 | KIS-4682 refactor global exception handler | поведение | описано: MVC/security/base CRUD exceptions; DataIntegrity заполняет только errorMessage |
| `b4e593780` | 2026-09-15 | fix integrationTest | поведение, тесты | описано: test исключает внутреннюю ContainerMovementMetaView |
| `bdfbae465` | 2026-09-15 | KIS-4720 fix: set owner container on update field | поведение | описано: update владельца и очистка NULL уже описаны |
| `b9d7c085b` | 2026-09-15 | KIS-4430 Fix filtering and sorting for container movements | БД, entity, поведение, CI/config | описано: модель движения, formula/filter/sort/meta SQL описаны |
| `7a0c75530` | 2026-09-15 | KIS-4692 refactor spotless | CI/config | описано: замена динамического ratchet фиксированным origin/dev |
| `6d9b50e25` | 2026-09-15 | KIS-4667 validate route transport type on update | entity, поведение | описано: уже покрыто route-lifecycle; перепроверено |
| `179784874` | 2026-09-15 | KIS-4690 calculate overdueDays with user timezone and add soring for products | БД, entity, API, поведение, тесты | описано: timezone/overdue и products sorting описаны в read model |
| `02d91d5a4` | 2026-09-15 | configure secure backend-managed CORS | CI/config | описано: CORS: текущая конфигурация и границы описаны |
| `978ba888c` | 2026-09-14 | KIS-4690 add new waybill representation and remove grouped_waybill | БД, entity, DTO, API, поведение, тесты, CI/config | описано: view/hierarchy, writers/parser/mapper/events и исходные integration tests |
| `ddb4c596d` | 2026-09-11 | KIS-4690 generalize SearchDate for temporal types | entity, DTO, поведение | описано: все затронутые Instant-поля, generic helper и различия date consumers |
| `20e4f8a72` | 2026-09-09 | add service bearer token for Keycloak SPI and isolate RestTemplate | поведение, тесты, документация, CI/config | описано: Keycloak SPI token и изоляция REST описаны |
| `5a823c353` | 2026-09-09 | KIS-4604 centralize MapStruct configuration and prevent precision loss | DTO, поведение, CI/config | описано: общий config, 91 mapper, изменения DTO/precision и Gradle |
| `4696ed25b` | 2026-09-09 | remove deprecated api | API, поведение, тесты | описано: удалённые mappings/UUID upsert/helpers, сохранённый filter overload, тестовый diff |
| `ce272f3ee` | 2026-09-09 | KIS-4683 create common error model and AlisException hierarchy | прочее | описано: иерархия и валидация ErrorDetails/AlisException сверены |
| `854dc869b` | 2026-09-08 | fix(db): reconcile container length column for KIS-4432 | БД, CI/config | описано: forward ADD length NUMERIC(15,3) IF NOT EXISTS описан |
| `90f71f397` | 2026-09-03 | KIS-4665 add unknown railway carriage model and update railway carriage sync | БД, entity, DTO, поведение, CI/config | описано: ETRAN patch vs Waybill reuse, единицы кг, model helper и seed history |
| `1c97f92df` | 2026-09-03 | KIS-4664 add unknown container type and update container sync | БД, entity, DTO, поведение, тесты, CI/config | описано: UNKNOWN/CHECK, lookup-only Waybill, split review/accept и исходники тестов |
| `fade0b93e` | 2026-09-03 | KIS-4369 fix include all shipping orders in meta filtering | API, поведение | описано: meta без принудительного ALL; веса из container item |
| `8e9083166` | 2026-09-01 | fix(db): reconcile KIS-4432 changeset drift | БД, CI/config | описано: ISO reconcile полностью описан в реестре схемы |

## Очередь дальнейшей сверки

1. P1: outbound payload и отмена заявок; связанные накладные; владельцы номерных и безномерных КТК. Пройти вызовы, права, ошибки, транзакции, retry и тестовые сценарии.
2. Полная цепочка Liquibase: изменения типов/nullable/default/FK/index/view и применимость include; сверить с JPA и ручными физическими моделями. Дата SQL-файла не заменяет дату его включения в Git.
3. API/DTO: сравнить нормализованные контракты без шума номеров строк; проверить удалённые endpoints и паспорта, параметры, permissions, validation и mapping.
4. Остальные коммиты: приёмка грузов, копирование рейсов, client meta, Excel, справочники, ошибки, auth/config; каждому поставить итоговый статус покрытия и ссылки на доказательства.
5. Проверить противоречия между ручными документами; недостающие внешние подтверждения вынести в открытые вопросы.
6. После реестра расхождений внести согласованные исправления, прогнать проверки ссылок и генераторов, обновить даты и журнал сверки.

Критерий завершения: ни одной записи «ожидает»; каждый существенный тезис связан с исходником/миграцией; все пробелы исправлены либо явно оставлены открытыми с причиной. Source-level проверка не подтверждает deployed БД или поведение внешних систем.

## Закрытие первого блока: outbound и отмена

11.11.2026: AUD-001 и AUD-002 исправлены в документации. Добавлены [модель таблицы](../database/outbound-data-as-is.md) и [контракт отмены](../integrations/order-cancellation-outbound-as-is.md), обновлены паспорт сущности, статусы, права, интеграции и reject рейса. Исходники тестов изучены, тесты не запускались. Вопросы внешней идемпотентности, группировки разных payload и runtime retry сохранены открытыми. Остальные пункты и исторический снимок различий каталогов выше остаются в очереди.

## Второй блок: накладные и владельцы КТК

11.11.2026: AUD-003 и AUD-004 закрыты в части отсутствующих полей/паспортов и описания текущего поведения. Добавлены [досылочные накладные](../business-rules/waybill-supplementary-as-is.md) и [владельцы КТК вывоза](../business-rules/shipping-container-owners-as-is.md). Обновлены выбранные Entity/DTO, два API-раздела, физические модели и прежние противоречащие описания повторного импорта/снимка. Общие даты полноты не повышались.

| Наблюдение | Состояние |
|---|---|
| ownerClient nullable в SQL/DTO против optional=false JPA | SOURCE_CONFIRMED, вопрос согласования |
| Экспорт qty вызывает ownerClient.getId без null guard | SOURCE_CONFIRMED; runtime-дефект на старых строках не воспроизводился |
| Счётчик владельцев добавляет всех остальных Client с нулём и не вызывает addUserRestriction | SOURCE_CONFIRMED; client-scope риск требует security-проверки |
| Переименование ownerContainerId → containerOwnerId у вывоза | SOURCE_CONFIRMED; внешний потребитель не проверен |
| Исключение вагонов основной не имеет обратного включения при смене связи | SOURCE_CONFIRMED по алгоритму; бизнес-решение открыто |
| Повтор товара не удаляет отсутствующие строки | SOURCE_CONFIRMED; корректность внешнего replay требует согласования |

Исходники integration tests по обоим порядкам импорта, нескольким досылочным, upsert груза, children и синхронизации владельцев изучены без запуска. Остальные коммиты, API и UI не объявляются полностью проверенными.

## Третий блок: схема, каталоги и контракты

11.11.2026: AUD-005 (payerId) и AUD-006 (ОКПО) исправлены. Полностью обновлены текущие generated-каталоги: 119 JPA-паспортов, 427 DTO-паспортов, 121 controller / 643 mapping-метода. 42 страницы вне свежей области генерации сохранены с явной пометкой DEPRECATED. Исходный список различий выше остаётся историческим результатом первичной проверки, не текущим списком незакрытых полей.

Добавлены [реестр 39 файлов миграций](../database/schema-changes-2026-09-11.md) и [изменения API-контрактов](../api/contract-changes-2026-11-11.md). Для диапазона схемы использован достижимый предшественник 01.09.2026 `aba0c312a695578bd017b9c1151fd5d5aaae465e`, а не reflog. Статически проверены 407 явных YAML file-ссылок: все цели найдены, две classpath-ссылки — в ресурсах WMS. Накат, classloader и preconditions не проверены.

Исправлены текущие BIGINT номера/количественные totals, окончательный cleanup receiving owner_container_id, payer update, VARCHAR(14) ОКПО и UI-DIFF-07 в части backend. Удалённые multipleaddition помечены историческими; surviving multipleupdate/batch не объявлялись удалёнными. Сохраняется необходимость проверки UI и runtime.

Проверки: 21 unittest scripts + 14 unittest API — успешно; git diff --check — успешно. check_docs: 752 Markdown, 8350 локальных ссылок, 21 отсутствующая цель (раньше 63), 0 ошибок fences/whitespace; 64 frontend-ссылки без frontend-root не проверены. Структурная проверка целиком ещё возвращает ненулевой код из-за этих 21 ссылок. AUD-007 остаётся открыт в этой части. Java-тесты и SQL не запускались.

Полная семантическая сверка 116 коммитов ещё не завершена: генерация закрывает структуру каталогов, но не доказывает все бизнес-правила.

## Четвёртый блок: копирование, приёмка, фильтры и Excel

11.11.2026: добавлены [привязка ClientGood Excel к клиенту](../business-rules/client-good-excel-import-as-is.md) и [уточнения бизнес-поведения](../business-rules/backend-behavior-changes-oct-nov-2026.md). Обновлены ручные правила рейса, receiving inbound, услуг, физические описания товаров/грузов/КТК и реестр открытых вопросов.

Подтверждено: копия рейса получает Instant.now (итог двух последовательных исправлений); CARRIAGE_ARRIVED учитывает обе модели контейнеров; null weight/container защищены в cargoWeight; detail сервисной заявки обогащается COUNT строк КТК. Прежние выводы о дефектах исправлены в местах их описания.

Пройден клиентский binding номенклатурного XLSX: VERY_HIDDEN лист, A1 UUID, проверка до save, отказ для старого/чужого шаблона. Scope фильтра receiving client и meta associationPath описан отдельно от доказательства client isolation. Поля code товаров/грузов относятся к ClientGood.code; meta вагона использует отдельный view/filter с SearchString для чисел.

Открыто: binary diff пяти warehouse XLSX из c0724fd89; полная семантика других частей b42ab46f7; ЖД-поиск ЕТСНГ по контейнеру без scope receivingOrder/excluded; client-scope/security и runtime отрицательных кейсов metadata. Существующие тестовые исходники просмотрены без запуска. Битых ссылок осталось 21; новые документы ошибок ссылок/fences/whitespace не добавили; git diff --check проходит.

## Пятый блок: бинарные шаблоны и справочники

11.11.2026: [сверены восемь XLSX](excel-template-diff-2026-11-11.md): пять warehouse из c0724fd89 (прежнее указание шести было неточным), три shipping из 401bbea3d. Проверены ячейки/формулы, видимость и XML-признаки структуры. Рендер и пересчёт не проводились. В двух текущих shipping warehouse-файлах найдены внешние формулы заголовков; cached text не доказывает вычисление через POI. Файлы/диапазоны и риск зафиксированы; XLSX не менялись.

[Дополнены справочные контракты](../business-rules/reference-contract-changes-oct-nov-2026.md): cargo create, client INN/KPP uniqueness и self-match риск, SERVICE_ORDER history bypass, перезапись дочерних владельцев при смене default поставки, ISO в трёх пакетах, ошибки групп Keycloak. Уточнена metadata: STRING-ячейка trim-ится reader-ом до сравнения UUID.

Проверки: 21 прежняя отсутствующая цель, 0 fences/whitespace; новых ошибок нет, git diff --check проходит. Java-тесты и внешние системы не запускались. Сентябрьские большие контуры, инфраструктура и прочие части частично просмотренных коммитов остаются в очереди.

## Шестой блок: безопасность, ошибки и инфраструктура

11.11.2026: добавлены [границы безопасности и Datareon](../business-rules/security-and-integration-boundaries-as-is.md) и [навигация migration/CI](migration-and-ci-audit-2026-11-11.md). Сверены CORS, отдельный Keycloak SPI RestTemplate, фильтровые 401/403, legacy error DTO, no-op contract_with_contractor и удаление monitor client. В двух физических моделях исправлена устаревшая гарантия BaseService catch: общая обёртка DB violation удалена, SQL-конфликт без локального catch возвращается как 500.

Route transport validation и create comment @Size уже описаны корректно; найдено и устранено одно противоречие в SQL-таблице comment. Shipping meta больше не принуждается к fillingType ALL, weight-фильтры container items относятся к самим item; эта часть требует дальнейшей сверки ручных документов. Статусные mapper/meta КТК уточнены отдельно от final owner propagation.

Standalone runner сверен по итоговым точкам с README; полная серия diff runner/CI, preview и deployment-права не закрыты. Состояние окружений, запуск update/deploy, секреты и внешние системы не проверялись. a8cb5107e оставлен открытым: несмотря на название spotless, -w diff не пуст.

Структурная проверка сохраняет 21 прежнюю отсутствующую цель, без новых ошибок fenced/whitespace; git diff --check проходит. Java и infrastructure tests не запускались.

## Закрытие ошибок локальных ссылок 11.11.2026

AUD-007 закрыт в части структурных ссылок: 21 оставшееся вхождение указывало на 13 отсутствующих исторических файлов. Поиск в рабочей копии, доступной Git-истории по ожидаемым путям, двух ZIP и соседних каталогах не нашёл оригиналы. Ссылки заменены явной пометкой недоступности; пути, прежние места использования и доступные тематические материалы сохранены в [реестре источников](../research/unavailable-sources.md). Фиктивные копии не создавались.

check_docs.py теперь проходит: 0 broken links, 0 unclosed fences, 0 trailing whitespace. git diff --check также проходит. 64 frontend-ссылки без frontend-root остаются вне проверки. Отсутствующие оригиналы — отдельный содержательный пробел; нулевая ошибка ссылок не означает их восстановление или завершение всего аудита.

## Седьмой блок: партии, шаблоны и ТН

11.11.2026: при повторной сверке KIS-4841 исправлено различие двух веток NomenclatureParserSupport. Текущие пять warehouse XLSX после c0724fd89 идут без колонки «Номенклатура» и допускают создание отсутствующей партии; ветка с этой колонкой требует существующую. Признак batchUnknown читается в обеих ветках при наличии колонки. Уточнено различие parser != NOT_USED против validator enum-набора. В реестре SQL исправлен временный DEFAULT false → DROP DEFAULT.

OOXML заголовки пяти файлов дополнительно сопоставлены parent→8ee1ab684, что подтверждает смену формы, затем обратную смену c0724fd89. Проверены validator, outbound batch branches и WMS matching: receiving syncId OR code, shipping syncId; batchUnknown совпадает с любой партией товара, несколько совпадений ошибочны. Подробные inbound/batch документы эти ветки уже содержат. Остальные parser-with-detail и shared ValidateUtil части большого 8ee1ab684 ещё требуют завершения, поэтому коммит не закрыт целиком.

В ТН описаны источники дат, sealNumbers, MSK, updatedAt вместо отдельной даты прибытия, helper неполных реквизитов и исправление текста адреса. Владелец DTO отслежен через четыре промежуточных коммита и финальное переименование 050d52ee8. Не спутаны test-only заголовки коммитов с фактическими DTO-изменениями.

Тестовые коммиты f1c71971b, b4e593780, 859aec456 изучены как изменения assertions/fixtures без production-контракта. Java-тесты не запускались; PDF не рендерился. Общая проверка документации продолжает проходить.

### Дополнительное закрытие небольших изменений

Сверены 45e6620a1 (DI/инкапсуляция при сохранении загрузки/статусной проверки и page restriction), e233a9f3a (selected owner при reserve), a4e3b5f84/51bce2217 (одинаковый идемпотентный SQL seed; оба коммита не являются двумя разными бизнес-правилами), 8e9083166 (ISO reconcile из реестра схемы), ce272f3ee (валидация ErrorDetails/AlisException). ddb4c596d рассмотрен по общему SearchDate; полная проверка всех потребителей ещё открыта.

a8cb5107e закрыт проверкой совпадения Java lexical tokens двух файлов parent→commit. Ненулевой -w diff не означал смыслового изменения: это форматирование/переносы строк. Предварительное сомнение из шестого блока разрешено; runtime-контракт не менялся.

## Восьмой блок: оставшиеся девять записей и read models

11.11.2026: добавлены полные текущие паспорта [waybill_view](../database/waybill-view-as-is.md) и [container_movement_meta_view](../database/container-movement-meta-as-is.md). Закрыт явный пробел отдельного описания hierarchy: пары станций как единица страницы, parent overlay, counts, timezone/overdue, filtering/meta и границы стабильного snapshot. Для движения описаны row multiplication, direct receiving items без Waybill, active-баланс и разные predicates page/meta.

Cleanup→revert→повторный cleanup проверены как последовательность e8eed7fe7/1eef7cd93/82c91f46d: конечный owner_container_id ссылается на Client. Backfill транспорта и registry-переходы дополнены точными ограничениями: root COALESCE, создание рейса только при отсутствии route, late-cancellation guards только для DONE, DEPARTED без удаления registry, history-поиск предшествующей заявки.

Найдено и исправлено противоречие: route-lifecycle всё ещё показывал удалённый review mapping, хотя order-statuses описывал недостижимость review. Current controller и /orderstatus/all сверены: review не публикуется, ON_REVIEW скрыт в списке. Уточнён буквальный meta alias containerowner.code и тестовое переименование ownerContainer→containerOwner.

Ни одна из 117 записей больше не остаётся без первичного рассмотрения, но это не завершение полной сверки: крупные коммиты сохраняют статус «частично» с конкретными остатками ниже. Java/SQL/HTTP/PDF и live environment не запускались; структурная проверка документации проходит.

| Частично рассмотренный крупный коммит | Что подтверждено сейчас | Что ещё не закрыто |
|---|---|---|
| 978ba888c | View/hierarchy, API/DTO, source/type, удаление MV и refresh | Полная сопоставительная проверка всех test/mapper/parser веток исходного diff |
| d30d77adf | Схема/backfill, API, root/route, manifest, accept route-check и Jasper | Остаток: полный тестовый diff и завершающая сверка всех mapper/service веток |
| 3bcf01137 | Selected/default owner, link/backfill и дочерние модели | Закрыт девятым блоком: parser, ClientFilter, bulk owners и тестовые изменения |
| 9a05f552e | Registry-машина, статусы/DTO, review mappings и notification listener | Остаток: все исходные тестовые/TOS/service ветки после удаления usage-check |
| 401bbea3d | Snapshot/restore, три XLSX, TOS owner, history и текущий mapping | Все parser/template-data collector branches и исходники тестов |

## Девятый блок: meta, импорт владельца, warehouse и транспорт

11.11.2026: закрыты ещё 12 частичных записей по исходникам. Итог реестра: **86 описано, 31 частично, 0 без первичного рассмотрения**, всего 117. Статус «описано» означает сопоставленный source-level контракт, а не успешный runtime-прогон.

Исправлено ошибочное описание meta статусов КТК как CASE/SQL grouping: текущие DAO группируют ID в Java и пагинируют группы после выборки. Документированы null→DEPARTED, сортировка UUID и статусных кодов, parent predicate, формат агрегированного ValidationException. Проверены исходные assertions для отсутствующего и явного DEPARTED, страницы групп, selected owner и изменения nested mapper.

[Владельцы поставки](../business-rules/container-remains-and-owner-as-is.md) дополнены поиском Client по коду в авто/ЖД-импорте, ClientFilter, проверками bulk setOwners, очисткой NULL и границами excluded. [Владельцы вывоза](../business-rules/shipping-container-owners-as-is.md) дополнены историей POST/body и ClientDto/update qty. nullable/merge/scope риски не объявляются исправленными в backend.

В [импорте товаров](../business-rules/order-goods-excel-import-as-is.md) сверены оставшиеся with-detail и конкретные parser реализации, ValidateUtil, упаковка/Cargo, ключи Map и исходники тестов. Устранены противоречия с текущими пятью XLSX: пример/сдвиг A/B относится к форме 8ee1ab684, а после c0724fd89 текущая форма снова без колонки Номенклатура. Удаление двух export generateDto-тестов зафиксировано как ограничение подтверждения.

В основных разделах [рейсов](../business-rules/route-lifecycle-as-is.md) и [PDF](../business-rules/order-pdf-reports-as-is.md) устранены сохранившиеся ссылки на создание/удаление transport-записей и использование удалённых Jasper-параметров. Подтверждены shipper/consignee/waybill из корневой заявки, driver/vehicle/carrier из Route, route-null accept check и изменённые JRXML M-7/Packing List. d30d77adf пока частичный: весь тестовый и оставшийся сервисный diff не объявлен закрытым.

Описан [notification listener](../business-rules/order-integrations.md) AFTER_COMMIT с точным DRAFT→ACCEPTED, условиями неизвестного номера и DTO без дочерних UUID. 9a05f552e сохраняет остаток тестовых/TOS/service веток. Полностью рассмотрены небольшие [Spotless/CI изменения](migration-and-ci-audit-2026-11-11.md) и [meta/веса item](../business-rules/backend-behavior-changes-oct-nov-2026.md).

Java/SQL/HTTP/PDF, POI-import и CI pipeline в этом блоке не запускались. check_docs.py: 761 Markdown, 8569 локальных ссылок, 0 broken links, 0 незакрытых fences, 0 trailing whitespace; git diff --check проходит. 64 frontend-ссылки без frontend-root остаются вне проверки.

## Десятый блок: справочные импорты, удалённые API, ошибки и фильтры

11.11.2026: закрыты 90f71f397, 1c97f92df, d24879c6e, 4696ed25b, f88b0f608, fe843b900, 7d92a3277, 91ad166bf, b42ab46f7 и ddb4c596d. **96 описано, 21 частично, 0 без первичного рассмотрения**, всего 117. Сопоставление выполнено по исходникам и истории; status «описано» не означает отсутствия рисков в реализации.

Исправлены основные документы, а не только добавлены примечания:

- [ЭТРАН-справочники](../business-rules/etran-reference-imports-as-is.md): килограммы в RailwayCarriage source comments, отсутствие пересчёта чисел, patch отдельного endpoint против reuse в Waybill; UNKNOWN-type не равен seed-модели «Не определено».
- [Карта дочерних API](../api/order-api.md) и [история контрактов](../api/contract-changes-2026-11-11.md): убраны действующие описания удалённых transport/multipleaddition/UUID-upsert операций; сохранённые multipleupdate, batch, merge и filter-overload описаны отдельно. Тела сохранённых controller-методов дополнительно сопоставлены по токенам; runtime route registration не проверена.
- [Модель ошибок](../business-rules/error-model-as-is.md): у DataIntegrityViolationException errorMessage=InternalError, но errorCode/contextObject не заполняются конструктором; стандартные MVC handlers наследуются, старые exception/406 paths удалены.
- [Владельцы КТК](../business-rules/shipping-container-owners-as-is.md) и [TOS](../business-rules/shipping-inbound-actions.md): все части owner propagation и snapshot diff, TOS NONE_CONTAINER требует registry, объявленный checkContainerOwner не вызывается.
- [Категория накладной](../database/waybill-view-as-is.md): точные значения JSON/БД и порядок resolver, BEFORE_COMMIT пересчёт, backfill требует обе станции и физически удаляет NULL category. Учтён последующий parent-first resolver.
- [SearchDate и meta views](../business-rules/backend-behavior-changes-oct-nov-2026.md): инвентаризированы все Instant-поля ddb4c596d, custom end-only/equal-day правила отделены от общего helper; разобраны ContainerMetaView и RailwayCarriageMetaView.

### Открытые вопросы реализации, выявленные при сверке

| Факт кода | Что не доказано / следующая проверка |
|---|---|
| ContainerOwnerFilter.status объявлен и учитывается в isNotEmpty, ContainerOwnerPredicate его не читает | Общая DAO-фильтрация не содержит status-условия; отдельные сервисы, включая count, фильтруют самостоятельно. Нужна проверка ожидаемого контракта вызывающих API |
| ShippingOrderContainerQtyFilter.isNotEmpty не учитывает ownerClient; predicate вызывает ClientPredicate.in без qty.ownerClient пути | Корректная корреляция и owner-only запрос на БД не подтверждены; это INFERENCE-риски, не воспроизведённый runtime-дефект |

Оба пункта вынесены в [реестр вопросов](analyst-open-items-registry.md). Там же устранены устаревшие заявления о мёртвом accept, root/transport дубле consignee, отсутствии owner propagation и актуальности старой Excel-формы. Отсутствующие исторические внешние источники этим не восстановлены.

Вспомогательная проверка ссылок на controller-разделы endpoints-generated.md: 82 ссылки, 0 отсутствующих controller anchors. Это отдельный ограниченный scan, не полная проверка всех Markdown-фрагментов. Java/SQL/HTTP, миграции, TOS/POI-import, PDF и CI не запускались; backend production-код не изменялся.

## Одиннадцатый блок: завершение четырёх начатых сверок 12.11.2026

HEAD остаётся 3d3899d5d; диапазон и 117 коммитов не менялись. Закрыты 87ccc2682, a5a40f94e, 930a1d076 и e1968e562: **100 описано, 17 частично**. Новая дата означает продолжение аудита прежнего среза, не проверку нового remote HEAD.

- [Схема/Hibernate](../database/schema-changes-2026-09-11.md): все 17 файлов validate-коммита; UUID clientId, enum STRING, CHAR станции, снятый schema атрибут и identities пересоздаваемых views.
- [Monitoring](../business-rules/security-and-integration-boundaries-as-is.md): весь diff REST-конструкторов/контроллеров/GoodRemain/config/CI/Helm. Отправка пакетов сохранена, копия в отдельный monitor удалена.
- [Досылочные](../business-rules/waybill-supplementary-as-is.md): остаток exports/entity-info и двух integration test. Assertions детей/count/JSON и повторного product upsert отделены от факта запуска тестов.
- [ContainerTN](../business-rules/order-pdf-reports-as-is.md): object→String параметры, expressions, общий style/font registry и изменения геометрии JRXML. Исправлено неверное утверждение о прямом разыменовании NULL UserInfoDto и уточнено имя TRANSPORT_DATA_TEMPLATE.

Source-level полнота этих записей не означает визуальную проверку PDF, успешный ORM startup, применение миграций или доставку интеграций. Backend-код не менялся. Оставшиеся 17 включают runner/CI/preview и крупные service/parser/mapper/cleanup изменения; аудит ещё не завершён.

## Двенадцатый блок: migration runner и STAGE publisher, 12.11.2026

Восемь частичных записей серии a2b4f2033—790c69f23 закрыты по исходникам/истории. **108 описано, 9 частично** из 117. Полностью прочитаны текущий Java runner, 16 unit test, launcher, packaging task, Dockerfile и относящиеся к серии CI/README изменения; [точный контракт и ограничения](migration-and-ci-audit-2026-11-11.md).

Дополнены различия identity/checksum/status/RERAN, listener count против SQL statements, pendingRemaining=0 при допустимом runAlways, bounded timeouts, приоритет категорий ошибок, env/property ресурсы, union db+wms и provenance image.env. В README найдены границы безусловных обещаний: launcher без java пишет в stderr; внешний GitOps script не доказывается кодом backend; ошибку close после успешного JSON нужно проверять отдельно. Lock guard пропускает только SQLState 42P01, а не любые ошибки.

Все эти пункты теперь явно описаны; реальные миграции, buildMigrationRunner, Java-тесты и CI jobs не запускались. Наличие исходника теста не заменено заявлением о пройденной проверке. Остаются preview (3 записи), cleanup/MapStruct и крупные service/parser/test контуры (6 записей).

## Тринадцатый блок: завершение диапазона, 12.11.2026

Закрыты последние девять частичных записей; итог реестра: **117 описано, 0 частично, 0 без первичного рассмотрения**. Срез остаётся 3d3899d5d, remote не обновлялся. Статус означает сопоставление влияния изменения с документацией по исходникам, а не отсутствие дефектов backend.

| Коммиты | Итог и доказательство |
|---|---|
| 4096c4851, db4766427, edc5c9eab | [Preview](migration-and-ci-audit-2026-11-11.md): ручной MR build без tests, pairing/dev counterpart, artifact/package/digest, request.py и stop. Verified request/generation/RBAC внешнего проекта не объявлены проверенными |
| 5a823c353 | [API/DTO](../api/contract-changes-2026-11-11.md): удалённые legalEntity/documentConfirmed/clientId, наследуемые name/active и BigDecimal. 89 mapper совпадают вне imports/@Mapper/формата, два исключения просмотрены; unmappedTargetPolicy остаётся IGNORE |
| 74c11bf96 | [Cleanup](../database/schema-changes-2026-09-11.md): 167 Java/7 resource удалений, 4 modified/1 added; ComponentScan, exception overload, DROP conversion. Поиск полных удалённых Java FQN в текущих модулях не нашёл совпадений |
| 401bbea3d | [Владельцы и импорт](../business-rules/shipping-container-owners-as-is.md): parser/колонки, dropdown источники, snapshot/restore/history и оставшиеся test changes; XLSX сверены по OOXML ранее |
| d30d77adf | [Рейсы и transport removal](../business-rules/route-lifecycle-as-is.md): service/mapper остаток, route-ignore обычного update, root manifest и изменённые тестовые fixtures/assertions |
| 9a05f552e | [Регистр КТК](../business-rules/container-remains-and-owner-as-is.md): accept/reject/TOS вызывающие пути, снятые usage/review, dropdown, семь исходных registry tests и поздние изменения ожиданий |
| 978ba888c | [Waybill view](../database/waybill-view-as-is.md): ETRAN/MANUAL writers, LocalDate, null-safe mapper, удаление refresh event, четыре исходных hierarchy tests |

В ручных API исправлены утверждения о действующем legalEntity контрагента; из реестра вопросов убран устаревший response-only documentConfirmed. AdditionalAgreementDto.legalEntity — другое поле и остаётся отдельным mapping-вопросом. Уточнены TOS NONE_CONTAINER без registry и уже исправленный каталог MissingOwnerContainer.

Оставшиеся ограничения: 64 frontend-ссылки требуют frontend-root; отсутствующие внешние исследования явно зарегистрированы; runtime client scope, nullable owner/qty predicates, applied schema, PDF/Excel исполнение, concurrency и внешний lifecycle/GitOps не подтверждены. Эти вопросы описаны и не считаются исправлениями production-кода. Документы, не затронутые диапазоном, сохраняют собственные даты/уровни достоверности; 117/117 нельзя использовать как сертификат всей библиотеки.

Финальная структурная проверка: check_docs.py — 761 Markdown, 8632 локальные ссылки, 0 broken links, 0 незакрытых fences, 0 trailing whitespace. Дополнительный scan — 82 controller anchor references, 0 отсутствующих целей. git diff --check проходит. Эти проверки не выполняют Java-код, SQL и CI и не проверяют все возможные Markdown fragments.
