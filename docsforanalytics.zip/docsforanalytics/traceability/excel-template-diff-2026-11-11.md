# Сверка бинарных Excel-шаблонов

Срез 3d3899d5d, 11.11.2026. Сопоставлены OOXML из Git parent→commit для c0724fd89 и 401bbea3d, затем проверены заголовки текущих warehouse-шаблонов. Использован read-only разбор ZIP/XML: значения shared/inline strings, формулы и cached values, видимость листов, merge, validations, protection, widths, views и style indices. Файлы не менялись. Рендер и пересчёт Excel/LibreOffice/POI не выполнялись; изменение style index не доказывает визуального изменения.

## Охват

В c0724fd89 изменены **пять**, а не шесть XLSX. В 401bbea3d — три шаблона вывоза. Все восемь проверены; остальные XLSX других коммитов этим блоком не объявляются сверенными.

| Коммит | Файл | Лист | Изменённые ячейки с содержимым | Изменённые XML-признаки |
|---|---|---|---:|---|
| `c0724fd89` | [receiving_order_auto_warehouse_nomenclature.xlsx](../../../web-layer/src/main/resources/templates/receiving_order_auto_warehouse_nomenclature.xlsx) | Инструкция | 0 | sheetViews, индексы стилей |
| `c0724fd89` | [receiving_order_auto_warehouse_nomenclature.xlsx](../../../web-layer/src/main/resources/templates/receiving_order_auto_warehouse_nomenclature.xlsx) | Номенклатура | 16 | sheetProtection, sheetViews, cols, индексы стилей |
| `c0724fd89` | [receiving_order_auto_warehouse_nomenclature.xlsx](../../../web-layer/src/main/resources/templates/receiving_order_auto_warehouse_nomenclature.xlsx) | Артикул | 0 | cols |
| `c0724fd89` | [receiving_order_auto_warehouse_nomenclature.xlsx](../../../web-layer/src/main/resources/templates/receiving_order_auto_warehouse_nomenclature.xlsx) | Партия | 0 | cols, индексы стилей |
| `c0724fd89` | [receiving_order_auto_warehouse_nomenclature.xlsx](../../../web-layer/src/main/resources/templates/receiving_order_auto_warehouse_nomenclature.xlsx) | Партия неизвестна | 2 | sheetViews, cols |
| `c0724fd89` | [receiving_order_auto_warehouse_with_detail.xlsx](../../../web-layer/src/main/resources/templates/receiving_order_auto_warehouse_with_detail.xlsx) | Инструкция | 0 | sheetViews, индексы стилей |
| `c0724fd89` | [receiving_order_auto_warehouse_with_detail.xlsx](../../../web-layer/src/main/resources/templates/receiving_order_auto_warehouse_with_detail.xlsx) | Номенклатура | 16 | sheetProtection, sheetViews, cols, индексы стилей |
| `c0724fd89` | [receiving_order_auto_warehouse_with_detail.xlsx](../../../web-layer/src/main/resources/templates/receiving_order_auto_warehouse_with_detail.xlsx) | Артикул | 0 | cols |
| `c0724fd89` | [receiving_order_auto_warehouse_with_detail.xlsx](../../../web-layer/src/main/resources/templates/receiving_order_auto_warehouse_with_detail.xlsx) | Контейнеры | 0 | cols |
| `c0724fd89` | [receiving_order_auto_warehouse_with_detail.xlsx](../../../web-layer/src/main/resources/templates/receiving_order_auto_warehouse_with_detail.xlsx) | Упаковка | 0 | cols |
| `c0724fd89` | [receiving_order_auto_warehouse_with_detail.xlsx](../../../web-layer/src/main/resources/templates/receiving_order_auto_warehouse_with_detail.xlsx) | Партия | 0 | cols |
| `c0724fd89` | [receiving_order_auto_warehouse_with_detail.xlsx](../../../web-layer/src/main/resources/templates/receiving_order_auto_warehouse_with_detail.xlsx) | Партия неизвестна | 2 | sheetViews |
| `c0724fd89` | [receiving_order_auto_warehouse_without_detail.xlsx](../../../web-layer/src/main/resources/templates/receiving_order_auto_warehouse_without_detail.xlsx) | Инструкция | 0 | sheetViews, индексы стилей |
| `c0724fd89` | [receiving_order_auto_warehouse_without_detail.xlsx](../../../web-layer/src/main/resources/templates/receiving_order_auto_warehouse_without_detail.xlsx) | Номенклатура | 16 | sheetProtection, sheetViews, cols, индексы стилей |
| `c0724fd89` | [receiving_order_auto_warehouse_without_detail.xlsx](../../../web-layer/src/main/resources/templates/receiving_order_auto_warehouse_without_detail.xlsx) | Артикул | 0 | cols |
| `c0724fd89` | [receiving_order_auto_warehouse_without_detail.xlsx](../../../web-layer/src/main/resources/templates/receiving_order_auto_warehouse_without_detail.xlsx) | Партия | 0 | cols, индексы стилей |
| `c0724fd89` | [receiving_order_auto_warehouse_without_detail.xlsx](../../../web-layer/src/main/resources/templates/receiving_order_auto_warehouse_without_detail.xlsx) | Партия неизвестна | 2 | sheetViews |
| `c0724fd89` | [shipping_order_auto_warehouse_nomenclature.xlsx](../../../web-layer/src/main/resources/templates/shipping_order_auto_warehouse_nomenclature.xlsx) | Инструкция | 0 | sheetViews, индексы стилей |
| `c0724fd89` | [shipping_order_auto_warehouse_nomenclature.xlsx](../../../web-layer/src/main/resources/templates/shipping_order_auto_warehouse_nomenclature.xlsx) | Номенклатура | 16 | sheetProtection, sheetViews, cols, индексы стилей |
| `c0724fd89` | [shipping_order_auto_warehouse_nomenclature.xlsx](../../../web-layer/src/main/resources/templates/shipping_order_auto_warehouse_nomenclature.xlsx) | Артикул | 0 | cols |
| `c0724fd89` | [shipping_order_auto_warehouse_nomenclature.xlsx](../../../web-layer/src/main/resources/templates/shipping_order_auto_warehouse_nomenclature.xlsx) | Партия | 0 | cols, индексы стилей |
| `c0724fd89` | [shipping_order_auto_warehouse_nomenclature.xlsx](../../../web-layer/src/main/resources/templates/shipping_order_auto_warehouse_nomenclature.xlsx) | Партия неизвестна | 2 | sheetViews |
| `c0724fd89` | [shipping_order_auto_warehouse_with_detail.xlsx](../../../web-layer/src/main/resources/templates/shipping_order_auto_warehouse_with_detail.xlsx) | Инструкция | 0 | sheetViews, индексы стилей |
| `c0724fd89` | [shipping_order_auto_warehouse_with_detail.xlsx](../../../web-layer/src/main/resources/templates/shipping_order_auto_warehouse_with_detail.xlsx) | Номенклатура | 16 | sheetViews, cols, индексы стилей |
| `c0724fd89` | [shipping_order_auto_warehouse_with_detail.xlsx](../../../web-layer/src/main/resources/templates/shipping_order_auto_warehouse_with_detail.xlsx) | Артикул | 0 | cols |
| `c0724fd89` | [shipping_order_auto_warehouse_with_detail.xlsx](../../../web-layer/src/main/resources/templates/shipping_order_auto_warehouse_with_detail.xlsx) | Контейнеры | 0 | sheetProtection, sheetViews, cols, индексы стилей |
| `c0724fd89` | [shipping_order_auto_warehouse_with_detail.xlsx](../../../web-layer/src/main/resources/templates/shipping_order_auto_warehouse_with_detail.xlsx) | Номер КТК | 0 | cols |
| `c0724fd89` | [shipping_order_auto_warehouse_with_detail.xlsx](../../../web-layer/src/main/resources/templates/shipping_order_auto_warehouse_with_detail.xlsx) | Упаковка | 0 | cols |
| `c0724fd89` | [shipping_order_auto_warehouse_with_detail.xlsx](../../../web-layer/src/main/resources/templates/shipping_order_auto_warehouse_with_detail.xlsx) | Партия | 0 | cols, индексы стилей |
| `c0724fd89` | [shipping_order_auto_warehouse_with_detail.xlsx](../../../web-layer/src/main/resources/templates/shipping_order_auto_warehouse_with_detail.xlsx) | Партия неизвестна | 2 | sheetViews |
| `401bbea3d` | [shipping_order_auto_container_yard.xlsx](../../../web-layer/src/main/resources/templates/shipping_order_auto_container_yard.xlsx) | Свод данных | 2252 | dataValidations, sheetViews, cols, индексы стилей |
| `401bbea3d` | [shipping_order_railway_carriage.xlsx](../../../web-layer/src/main/resources/templates/shipping_order_railway_carriage.xlsx) | Свод данных | 1110 | dataValidations, cols, индексы стилей |
| `401bbea3d` | [shipping_order_railway_carriage_filling_type_container.xlsx](../../../web-layer/src/main/resources/templates/shipping_order_railway_carriage_filling_type_container.xlsx) | Свод данных | 11 | cols, индексы стилей |

Количество изменённых ячеек в трёх шаблонах вывоза включает сдвиг колонок и формул вниз по заполненной области; это не количество новых бизнес-полей.

## Warehouse: новый лист «Номенклатура»

| Ячейка | Старое значение заголовка | Текущее |
|---|---|---|
| A1 | № | Артикул* |
| B1 | Артикул | Наименовании партии |
| C1 | Номенклатура | Дата партионного учета (в части файлов со звёздочкой) |
| D1 | Ед. изм. | Штрихкод партии |
| E1 | Партия | Партия неизвестна* |
| F1 | Партия неизвестна | Количество план* |
| G1 | Цена за 1 ед. изм. | Цена за 1 ед. изм.* |
| H1 | Количество всего, план | Удалено |

A2:G2 теперь содержат подсказки вместо примера товара. На листе «Партия неизвестна» добавлены A1=Да и A2=Нет. B1 «Наименовании партии» — точная строка файла и ExcelTemplateColumn.BATCH_NAME, не исправленная редактором формулировка. Изменены ширины, состояние защиты/выделения и индексы стилей; новую бизнес-валидацию нельзя выводить только из звёздочек.

C1 без звёздочки в receiving nomenclature/with_detail; со звёздочкой в receiving without_detail и обоих shipping. Это различие маркировки, не доказательство разной серверной обязательности.

## Внешние формулы: открытый риск

В текущем shipping_order_auto_warehouse_nomenclature.xlsx лист «Номенклатура», E1:G2 содержат внешние ссылки вида `[1]Номенклатура!E1`, а в shipping_order_auto_warehouse_with_detail.xlsx — E1:E2. Cached text при чтении OOXML совпадает с ожидаемыми заголовками/подсказками. Это не доказательство успешного вычисления.

ExcelFileReader.getStringValue для FORMULA вызывает POI evaluator; при исключении возвращает NULL, без fallback на cached value. `INFERENCE`: недоступная внешняя книга может нарушить распознавание заголовков или значений. Требуется импорт именно этих шаблонов через текущую POI-версию и повтор после сохранения в Excel; проблема не воспроизводилась. Шаблоны в рамках аудита не исправлялись.

## Вывоз: удалена колонка владельца КТК

| Файл | Удалённая колонка листа «Свод данных» | Сдвиг |
|---|---|---|
| shipping_order_auto_container_yard.xlsx | L1 Собственник КТК* | Порожний*: M→L, остальные правее также сдвинуты |
| shipping_order_railway_carriage.xlsx | U1 Собственник КТК* | Порожний*: V→U; Собственник вагона остаётся в I1 |
| shipping_order_railway_carriage_filling_type_container.xlsx | G1 Собственник КТК* | Порожний*: H→G |

Подтверждает уже описанное удаление выбора владельца из трёх шаблонов вывоза. Владельца номерного КТК сервер берёт из регистра; контракт и синхронизация — [правила владельца](../business-rules/shipping-container-owners-as-is.md). Перенос валидаций/формул проверен как XML-различие, но визуальная корректность и весь импорт строк не подтверждены запуском.

## Источники реализации

- [ExcelFileReader.java](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/parsing/ExcelFileReader.java)
- [ExcelTemplateColumn.java](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/parsing/ExcelTemplateColumn.java)
