# Изменения контрактов API и DTO: целевая сверка 11.11.2026

Срез 3d3899d5d, AS_IS / SOURCE_CONFIRMED. Каталоги API/DTO/Entity полностью обновлены текущими генераторами. Полнота извлечения генераторов и runtime-регистрация не доказываются этим запуском. Ручная семантика изменений сверяется отдельно.

## Плательщик поставки

Коммит 966422467 от 04.11.2026 добавил payerId: IdDto с @Valid в ReceivingOrderUpdateDto. Mapper превращает непустой id в ссылку Payer; service при непустой отличающейся ссылке загружает Payer через DAO и присваивает. Отсутствие payerId, NULL или ссылка без ID на direct service-пути не очищают прежнего плательщика; HTTP @Valid для непустого IdDto проверяет id. Проверка update-статуса остаётся общей. Дополнительной проверки соответствия плательщика паре станций в этой ветке не найдено.

Станции departureStationId/destinationStationId в update DTO отсутствуют и mapper их игнорирует. UI-DIFF-07 закрыт только в части backend payer; актуальный frontend и стенд не проверены. Создание CONTAINER + RAILWAY безусловно требует все три поля (без прежнего env-флага).

## ОКПО

ba455a62e разрешает в ClientCreationDto 8/10/14 цифр или пустую строку; @Pattern допускает NULL. ClientUpdateDto наследует правило. Ошибка — Client.InvalidOkpo. 63ccdfca8 расширяет client.okpo и company.okpo до VARCHAR(14). CompanyDto не задаёт собственного @Pattern: нельзя переносить валидацию клиента на компанию только из одинаковой длины SQL. Прежний frontend-срез описывал 10 цифр; его актуальность отдельно не проверена.

## Удалённые mappings

Ниже — удалённые аннотации из Git diff двух коммитов; controller paths взяты из текущего класса. Это удаление конкретного mapping, не всех CRUD или batch-контрактов контроллера. DELETE/PUT/POST с похожим путём могут оставаться. Текущий состав — [полный каталог](endpoints-generated.md).

| Коммит | Controller | Базовый путь | Удалённая аннотация |
|---|---|---|---|
| `4696ed25b` | `ReceivingOrderCargoController` | `/receivingordercargo` | `@PostMapping(path = "/{receivingOrderId}", consumes = MediaType.APPLICATION_JSON_VALUE)` |
| `4696ed25b` | `ReceivingOrderContainerController` | `/receivingordercontainer` | `@PostMapping(path = "/{receivingOrderId}", consumes = MediaType.APPLICATION_JSON_VALUE)` |
| `4696ed25b` | `ReceivingOrderContainerItemController` | `/receivingordercontaineritem` | `@PostMapping(path = "/{receivingOrderId}", consumes = MediaType.APPLICATION_JSON_VALUE)` |
| `4696ed25b` | `ShippingOrderController` | `/shippingorder` | `@PostMapping(path = "/unnumbered/page", consumes = MediaType.APPLICATION_JSON_VALUE)` |
| `4696ed25b` | `ShippingOrderController` | `/shippingorder` | `@PostMapping(path = "/unnumbered/meta/{fieldName}", consumes = MediaType.APPLICATION_JSON_VALUE)` |
| `4696ed25b` | `ShippingOrderCargoController` | `(см. контроллер)` | `@PostMapping(path = "/{shippingOrderId}", consumes = MediaType.APPLICATION_JSON_VALUE)` |
| `4696ed25b` | `ShippingOrderContainerController` | `/shippingordercontainer` | `@PostMapping(path = "/{shippingOrderId}", consumes = MediaType.APPLICATION_JSON_VALUE)` |
| `4696ed25b` | `ShippingOrderContainerItemController` | `/shippingordercontaineritem` | `@PostMapping(path = "/{shippingOrderId}", consumes = MediaType.APPLICATION_JSON_VALUE)` |
| `4696ed25b` | `ShippingOrderEtranInvoiceController` | `/shippingorderetraninvoice` | `@PostMapping(path = "/{shippingOrderId}", consumes = MediaType.APPLICATION_JSON_VALUE)` |
| `4696ed25b` | `ShippingOrderRailwayCarriageController` | `/shippingorderrailwaycarriage` | `@PostMapping(path = "/{shippingOrderId}", consumes = MediaType.APPLICATION_JSON_VALUE)` |
| `f88b0f608` | `ReceivingOrderBlackboxController` | `(см. контроллер)` | `@PostMapping("/multipleaddition")` |
| `f88b0f608` | `ReceivingOrderCargoController` | `/receivingordercargo` | `@PostMapping(path = "/multipleaddition", consumes = MediaType.APPLICATION_JSON_VALUE)` |
| `f88b0f608` | `ReceivingOrderContainerController` | `/receivingordercontainer` | `@PostMapping(path = "/multipleaddition", consumes = MediaType.APPLICATION_JSON_VALUE)` |
| `f88b0f608` | `ReceivingOrderGoodController` | `/receivingordergood` | `@PostMapping(path = "/multipleaddition", consumes = MediaType.APPLICATION_JSON_VALUE)` |
| `f88b0f608` | `ReceivingOrderRequestedServiceController` | `/receivingorderrequestedservice` | `@PostMapping(path = "/multipleaddition", consumes = MediaType.APPLICATION_JSON_VALUE)` |
| `f88b0f608` | `ShippingOrderCargoController` | `(см. контроллер)` | `@PostMapping(path = "/multipleaddition", consumes = MediaType.APPLICATION_JSON_VALUE)` |
| `f88b0f608` | `ShippingOrderGoodController` | `(см. контроллер)` | `@PostMapping(path = "/multipleaddition", consumes = MediaType.APPLICATION_JSON_VALUE)` |
| `f88b0f608` | `ShippingOrderRequestedServiceController` | `/shippingorderrequestedservice` | `@PostMapping(path = "/multipleaddition", consumes = MediaType.APPLICATION_JSON_VALUE)` |

Удаление /multipleaddition не отменяет /multipleupdate и /{orderId}/batch, если они присутствуют в текущем классе. Например ShippingOrderCargo оставляет PUT /multipleupdate и POST /{shippingOrderId}/batch; ReceivingOrderBlackbox теперь имеет одиночные POST/PUT/DELETE. Старые рассуждения об атомарности удалённых методов относятся только к истории.

## Семантика удалённых операций

4696ed25b удалил UUID-overload BaseService.upsertAndDelete(orderId, dtos) и createFilterWithOrderId в восьми дочерних сервисах. Он трактовал отсутствующие в списке строки как подлежащие удалению. Оставшийся overload upsertAndDelete(filter, dtos), явный applyBatch и специализированные merge — самостоятельные операции; удаление старого POST /{orderId} не делает их HTTP-заменами с тем же body. Два удалённых /shippingorder/unnumbered endpoint принудительно задавали UNNUMBERED_TYPES; для нового read-запроса фильтр нужно задавать явно.

Тела сохранённых controller-методов в двух diff сопоставлены по Java-токенам без пробелов/комментариев: изменений в телах не найдено. Отдельно просмотрены удалённые методы и mappings; это вспомогательная проверка, не Java-компиляция. В 4696ed25b удалён integration test старого upsert-and-delete вагонов; наличие текущего теста remove не доказывает покрытие нового batch/merge.

f88b0f608 вместе с восемью multipleaddition удалил сервисные циклы массового создания, ReceivingOrderCargoDetailedDto/MultipleCreationDto и ReceivingOrderGoodMultipleCreationDto. В cargo удалена эвристика повторного использования «пустой» строки товара: findEmpty, cargoIsNull filter и его predicate. Эти правила не переносятся на одиночный create или applyBatch. Входной cargoIsNull больше не является поддерживаемым полем ShippingOrderCargoFilter; реакция HTTP на неизвестное JSON-поле зависит от Jackson-конфигурации.

Актуальная [карта дочерних API](order-api.md) обновлена: удалённые transport/multipleaddition/upsert пути не представлены как действующие. Исторические разделы физических моделей явно отделены от текущего контракта.

## Исчезнувшие паспорта

42 прежние страницы отсутствуют в свежей области генерации: они явно помечены DEPRECATED и сохранены для исторических ссылок. Это не означает, что все 42 класса были удалены именно в сентябре–ноябре: для WMS возможен прежний дрейф генерации/истории. Текущие индексы содержат 119 JPA-паспортов и 427 DTO-паспортов. Полный API-каталог: 121 controller, 643 mapping-метода.

## MapStruct и изменения DTO 09.09.2026

`5a823c353` затрагивает 105 файлов и меняет публичные контракты, а не только оформление mapper. В текущих каталогах отражены следующие изменения:

| DTO | Изменение |
|---|---|
| `ClientRelatedEntityCreationDto` / `ClientRelatedEntityDto` | Удалён `legalEntity`; update наследует creation DTO, связь `client` сохранена |
| `ShippingOrderDto` | Удалён `documentConfirmed`; это не удаление подтверждения документов у ReceivingOrder |
| `GoodGroupDto` | `BaseNamedDto → IdCodeDto`: исчезли наследуемые `name` и `active`, `id/code` сохранены |
| `GoodPackageDto` | `BaseNamedDto → IdActiveCodeDto`: исчез `name`, `active/id/code` сохранены |
| `RailwayCarriageChainPackageDto` | Удалён `clientId` |
| `ShippingOrderContainerChainPackageDto` | `weight`: Double → BigDecimal |
| `WaybillProductDto` | `weight/volume/length/width/height`: Double → BigDecimal |
| `WaybillProductDetailedDto` | `weightLoaded/grossWeight/netWeight`: Double → BigDecimal |

`BaseDto` содержит id, а не audit-поля: смена этих родителей не означает удаления дат/авторов. `WaybillDetailedDto` в этом diff меняет оформление. SQL-миграций в коммите нет. Переход на BigDecimal убирает промежуточное представление Double в DTO; точность внешнего JSON-потребителя этим не гарантируется.

Общий [MapStructConfig](../../../wms-layer/src/main/java/ru/korusconsulting/wms/mapper/MapStructConfig.java): Spring component model, CommonObjectMapper, typeConversionPolicy=ERROR, unmappedTargetPolicy=IGNORE, nullValueCheckStrategy=ON_IMPLICIT_CONVERSION. ERROR относится к диагностике небезопасных неявных преобразований при генерации, а не к runtime-валидации всех чисел. Незамапленные target-поля по-прежнему игнорируются. Отдельные compilerArgs IGNORE удалены из Gradle двух модулей.

Сравнение Java-токенов после удаления imports и только верхней аннотации @Mapper показало: у 89 mapper-файлов остальные токены совпадают. Два исключения просмотрены отдельно: ShippingOrderContainerQtyMapper удаляет toContainerDto; CommonObjectMapper сохраняет null-safe id/code/common mapping через IdCodeDto.of и удаляет toIdSequentialDto. IdCodeDto добавляет null-safe overload для Identifiable & HasCode<String>, сохраняя BaseIdCode overload. Это вспомогательная сверка исходников, без запуска annotation processor или HTTP.

## Источники

- [ReceivingOrderUpdateDto.java](../../../web-layer/src/main/java/ru/korusconsulting/alis/dto/receivingorder/ReceivingOrderUpdateDto.java)
- [ReceivingOrderMapper.java](../../../web-layer/src/main/java/ru/korusconsulting/alis/mapper/receivingorder/ReceivingOrderMapper.java)
- [ReceivingOrderService.java](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/receivingorder/ReceivingOrderService.java)
- [ClientCreationDto.java](../../../web-layer/src/main/java/ru/korusconsulting/alis/dto/client/ClientCreationDto.java)
- [ClientUpdateDto.java](../../../web-layer/src/main/java/ru/korusconsulting/alis/dto/client/ClientUpdateDto.java)
- [CompanyDto.java](../../../web-layer/src/main/java/ru/korusconsulting/alis/dto/company/CompanyDto.java)
- [v.1.35.0_20261015_KIS-4874_extended_okpo_field.sql](../../../db-layer/src/main/resources/db/changelog/v.1.35.0/v.1.35.0_20261015_KIS-4874_extended_okpo_field.sql)
