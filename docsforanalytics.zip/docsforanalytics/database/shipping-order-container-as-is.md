# `shipping_order_container`: КТК заявки на вывоз, физическая модель AS-IS (часть 20)

> **Сверено:** backend `3d3899d5d` (12.11.2026) · **Основание:** `SOURCE_CONFIRMED` — исходный код, миграции и тесты (тесты не запускались); БД и стенд не проверялись.

Это реконструкция по Liquibase-цепочке и Java-коду, не проверка применённой БД. Root totals — в [модели `shipping_order`](shipping-order-root-as-is.md). Контур зеркален [`receiving_order_container`](receiving-order-container-as-is.md); отличия: сохранённый прямой FK на вагонную задачу (у receiving удалён), флаг `random`, отсутствие проверки статуса заявки при изменении строк. [`ShippingOrderContainerItem`](shipping-order-container-item-as-is.md) — соседняя таблица.

## Endpoint, условная обязательность и validator

[`ShippingOrderContainerController`](../../../web-layer/src/main/java/ru/korusconsulting/alis/controller/shippingordercontainer/ShippingOrderContainerController.java) (`/shippingordercontainer`, permission path `ShippingOrder.ShippingOrderContainer`) объявляет `POST /`, `PUT /{id}`, `DELETE /{id}`, `GET /{id}`, `/all`, `/page`, `/preview`. Deprecated `POST /{shippingOrderId}` (полная замена набора КТК) удалён 09.09.2026 (`4696ed25`). [`ShippingOrderContainerControllerV2`](../../../web-layer/src/main/java/ru/korusconsulting/alis/controller/shippingordercontainer/ShippingOrderContainerControllerV2.java) под `/shipping-order/{shippingOrderId}/shipping-order-container` даёт `page`, `list`, `list/preview`, `unnumbered/list`, `meta/{fieldName}` (и `unnumbered/meta/{fieldName}`) и два merge-эндпоинта: `PUT /merge` (группировка по вагону) и `PUT /unnumbered/merge` (только `fillingType=CONTAINER`).

**Проверки статуса заявки нет.** В отличие от сервисов всех остальных дочерних таблиц вывоза, `ShippingOrderContainerService` не вызывает `OrderServiceUtils.checkOrderStatusForUpdate`: строки КТК можно добавлять, менять и удалять (в т.ч. через merge) в заявке любого статуса, включая `ACCEPTED`/`DONE`.

[`ValidShippingOrderContainer`](../../../web-layer/src/main/java/ru/korusconsulting/alis/validator/ValidShippingOrderContainer.java)/[`ValidShippingOrderContainerValidator`](../../../web-layer/src/main/java/ru/korusconsulting/alis/validator/ValidShippingOrderContainerValidator.java) задают ту же условную схему, что и у receiving: при `ktkNumberUnknown=true` дополнительных полей не требуется; иначе обязательны `container.id` и `customsClearance`, а при `empty≠true` — ещё `dangerClass.id` и `sealType.id`. **Найдено расхождение**: default-сообщение аннотации перечисляет `container, dangerClass, weight, customsClearance, dangerousCargo` как обязательные, но сама проверка **не трогает** ни `weight`, ни `dangerousCargo` (поля `dangerous_cargo` в текущей схеме уже нет — см. ниже) — текст ошибки описывает более старую версию правила, чем реализованный код.

Помимо `IdDto`-полей (`container`, `sealType`, `dangerClass`, `shippingOrderRailwayCarriage`), [`CreationDto`](../dto/catalog/shippingordercontainer/ShippingOrderContainerCreationDto.md) использует **`IdCodeDto`** для `customerService`, `ownerRailwayCarriage`, `containerOwner` — то есть клиент технически может передать код вместе с id для этих трёх ссылок, хотя lookup всё равно идёт по id (см. ниже). Исключение — `containerOwner`: с 08.10.2026 (KIS-4830) значение из DTO игнорируется и при create, и при update, а Excel-импорт его не передаёт; сервер записывает снимок из registry (см. таблицу колонок). `random` имеет DTO `@Builder.Default = TRUE`. [`UpdateDto`](../dto/catalog/shippingordercontainer/ShippingOrderContainerUpdateDto.md) добавляет `UUID id` без `@NotNull`; `PUT /{id}` не принимает `@PathVariable id`, лукап идёт по body `UpdateDto.id`, как и везде в контуре заявок.

## Дубль-проверка: только application-level

[`ALG-644`](../../../db-layer/src/main/resources/db/changelog/v.1.0.0/v1.0.0_20240903_ALG-644_add_table_shipping_order_container.sql) создавал `UNIQUE (shipping_order_id, container_id)` (`shipping_order_container_order_container_unique_idx`), но уже через два дня [`ALG-670`](../../../db-layer/src/main/resources/db/changelog/v.1.0.0/v1.0.0_20240905_ALG-670_add_column_for_receiving_order_containers_carriage.sql) удалил его — тем же файлом, что и receiving-аналог. Физической уникальности пары «заявка + КТК» нет.

Единственная защита — [`ShippingOrderContainerService.checkIfAlreadyExists`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/shippingordercontainer/ShippingOrderContainerService.java): `count` по `(shippingOrder, container)` с default-фильтром [`ShippingOrderContainerFilter.deleted=false`](../../../db-layer/src/main/java/ru/korusconsulting/alis/filter/shippingordercontainer/ShippingOrderContainerFilter.java); при превышении — `DuplicateEntityException("ShippingOrderContainer.AlreadyExists")`. Проверка пропускается при `ktkNumberUnknown=true` или `container=null`. Повторное добавление КТК после soft-delete разрешено. Защиты от гонки двух параллельных INSERT нет (`INFERENCE`).

## SQL-колонки и изменения

| Поле/источник | Текущий SQL source contract | История и отличие от `receiving_order_container` |
|---|---|---|
| `id`, `shipping_order_id` | `UUID PK`; `shipping_order_id UUID NOT NULL REFERENCES shipping_order` | Обычный собственный PK, много строк на заявку. |
| `container_id` | `UUID NULL REFERENCES container(id)` | ALG-644 изначально `NOT NULL`; [`KIS-1970`](../../../db-layer/src/main/resources/db/changelog/v.1.30.0/v.1.30.0_20251107_KIS-1970_add_column_ktk_number_unknown_on_receiving_order_and_shipping_order_and_removing_restrictions.sql) снял `NOT NULL` для `ktkNumberUnknown`. Тот же SQL продублирован в `v.1.30.0` и `v.1.30.1` (оба включены в changelog, идемпотентны). [`KIS-2013`](../../../db-layer/src/main/resources/db/changelog/v.1.31.0/v.1.31.0_20251201_KIS-2013_add_indexes_for_container_and_railway_carriage_ids.sql) добавил `idx_shipping_order_container_container_id`. |
| `railway_carriage_id` → `shipping_order_railway_carriage_id` | `UUID NULL REFERENCES shipping_order_railway_carriage(id)` | ALG-644 сначала ссылался на глобальный каталог `railway_carriage`; [`ALG-843`](../../../db-layer/src/main/resources/db/changelog/v.1.0.0/v1.0.0_20240926_ALG-843_update_railway_carriage_link.sql) перевёл на строку задачи вагона этой же заявки (`shipping_order_railway_carriage`) с backfill по паре `(railway_carriage_id, shipping_order_id)`. **В отличие от receiving**, где аналогичный прямой FK был позже полностью удалён (`KIS-3631`) в пользу связи через `WaybillContainer`, у shipping этот FK остаётся действующим прямым полем сущности. |
| `seal_numbers` | `VARCHAR(50)[] NULL` | `NOT NULL` снят [`KIS-282`](../../../db-layer/src/main/resources/db/changelog/v.1.0.0/v1.0.0_20250306_KIS-282_drop_not_null.sql) — тем же changeset, что и у receiving. |
| `seal_type_id` | `UUID NULL REFERENCES seal_type(id)` | Добавлен [`KIS-286`](../../../db-layer/src/main/resources/db/changelog/v.1.0.0/v1.0.0_20250206_KIS-286_add_table_seal_type.sql), создавшим и сам справочник; у receiving аналогичная колонка добавлена позже отдельным changeset `KIS-2003`. |
| `danger_class_id` | `UUID NULL REFERENCES danger_class(id)` | [`KIS-167`](../../../db-layer/src/main/resources/db/changelog/v.1.0.0/v1.0.0_20250227_KIS-167_add_danger_class_to_order_containers_tables.sql) добавил FK с backfill на класс «Отсутствует» (`code_danger_class='0'`) и `NOT NULL`; `KIS-1970` снял `NOT NULL`. Старая прямая колонка `dangerous_cargo BOOLEAN NOT NULL` (из ALG-644) удалена [`KIS-2003`](../../../db-layer/src/main/resources/db/changelog/v.1.30.1/v.1.30.1_20251112_KIS-2003_refactoring_excel_template.sql) — именно её всё ещё упоминает устаревшее сообщение validator'а. |
| `container_owner_id` (до переименования owner_container_id) | `UUID NULL REFERENCES client(id)` (с 08.10.2026, KIS-4830) | Добавлена `KIS-2003` со ссылкой на `client_related_entity`. [`KIS-4830`](../../../db-layer/src/main/resources/db/changelog/v.1.35.0/v.1.35.0_20261006_KIS-4830_shipping_container_owner_client.sql) (коммит `401bbea3`, 08.10.2026) перевёл FK на `client(id)`: существующие значения перемаплены по той же таблице соответствия `client_related_entity → client`, что и в KIS-4716 (`3bcf0113`); **значения, отсутствующие в таблице соответствия, обнулены**. JPA-поле `ShippingOrderContainer.containerOwner` теперь `Client`. Значение из DTO игнорируется (`modelCreation` и с KIS-4830 также `modelUpdate` — `@Mapping(target = "containerOwner", ignore = true)`); сервер сам записывает **снимок** владельца из registry `container.containerOwner.client`: при `create` (`prepareModelToAdd`), при смене КТК в `PUT` (`prepareModelToUpdate`, только если изменился `container`) и при создании/замене строки по результату TOS-отгрузки (`TosShipmentResultAction`). Без КТК (`ktkNumberUnknown`) или без записи в registry — `NULL`. Штатная смена владельца/статуса синхронизирует snapshot у неудалённых DRAFT/ON_REVIEW строк. ACCEPTED/IN_PROGRESS/DONE сохраняют прежнее значение. SQL backfill 20261102 исправляет DRAFT/ON_REVIEW при наличии registry; runtime при отсутствующей registry способен записать NULL. В TOS NONE_CONTAINER создание законченной строки без registry отдельно запрещено. Подробнее — [регистр остатков и владельца КТК](../business-rules/container-remains-and-owner-as-is.md#владелец-на-строке-вывоза-kis-4830). |
| `customer_services_id`, `owner_railway_carriage_id` | `UUID NULL REFERENCES client_related_entity(id)` | Добавлены тем же `KIS-2003`. `prepareModelToUpdate` эти поля не трогает — через `PUT` они не изменяются; при create маппятся из `IdCodeDto` (используется только `id`). По-прежнему `ClientRelatedEntity`, а не `Client`. |
| `data_time_krugloye_pole` | `TIMESTAMP NULL` | Добавлена `KIS-2003` (Excel-шаблон); JPA `dataTimeKrugloyePole`, в DTO create/update. Бизнес-смысл в коде не раскрыт (`OPEN_QUESTION`). |
| `empty` | `BOOLEAN NOT NULL` | С ALG-644. При `empty=true` сервис подставляет класс опасности «Отсутствует» (`code=0`); переход `empty false→true` в update удаляет item-строки. |
| `customs_clearance` | `BOOLEAN NOT NULL DEFAULT false` | `DEFAULT false` добавлен [KIS-3352](../../../db-layer/src/main/resources/db/changelog/v.1.33.0/v.1.33.0_20260303_KIS-3352_shipping_order_filling_type_and_qty_tables.sql). |
| `customs_control` | `BOOL NOT NULL DEFAULT FALSE` — **колонка физически осталась** | Добавлена [`KIS-163`](../../../db-layer/src/main/resources/db/changelog/v.1.0.0/v1.0.0_20250225_KIS-163_add_customs_control_to_order_containers_tables.sql). [`KIS-664`](../../../db-layer/src/main/resources/db/changelog/v.1.30.0/v.1.30.0_20251107_KIS-664_remove_field_custom_control.sql) дважды удаляет её из `receiving_order_container`, а из `shipping_order_container` — нет (вероятная опечатка в миграции). В JPA поля нет, INSERT получает `DEFAULT FALSE`. |
| `weight` | `NUMERIC(15,3) NULL` | ALG-644 изначально `NOT NULL`; `KIS-1970` снял. Create берёт `Container.weight` (или `null` без КТК); update пересчитывает как тара КТК + сумма `wightGross` item-строк, а без КТК пишет `0` (не `null`). One-off [`KIS-3297`](../../../db-layer/src/main/resources/db/changelog/v.1.33.0/v.1.33.0_20260223_KIS-3297_recalculate_container_weight_by_order.sql) backfill — для обеих `_container`-таблиц. |
| `actual_quantity` | `NUMERIC(16,3) NULL` | [`ALG-728`](../../../db-layer/src/main/resources/db/changelog/v.1.0.0/v1.0.0_20240910_ALG-728_add_field_shipping_order_container_actual_quantity.sql) . Writer — [`TosShipmentResultAction`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/datareon/inbound/action/TosShipmentResultAction.java) (`cargoData.qty` из результата отгрузки TOS); см. [inbound actions вывоза](../business-rules/shipping-inbound-actions.md). Читается route chain package. |
| `status` | `VARCHAR(20) NULL` | [`ALG-851`](../../../db-layer/src/main/resources/db/changelog/v.1.0.0/v1.0.0_20240930_ALG-851_add_order_container_status.sql). JPA `TaskStatus`: `UPLOADED` пишет `CargoShippingTaskExportService`, `FINISHED` — `TosShipmentResultAction`. |
| `random` | `BOOLEAN NOT NULL DEFAULT false` | [`KIS-1039`](../../../db-layer/src/main/resources/db/changelog/v.1.0.0/v1.0.0_20250514_KIS-1039_add_random_for_shipping_order_container.sql) создал с `DEFAULT TRUE`, [KIS-3352](../../../db-layer/src/main/resources/db/changelog/v.1.33.0/v.1.33.0_20260303_KIS-3352_shipping_order_filling_type_and_qty_tables.sql) сменил default на `false`. JPA — примитив `boolean` (Java default `false`), а `CreationDto.random` имеет Lombok `@Builder.Default = TRUE`: итог зависит от того, передал ли клиент поле. У receiving такого поля нет. Смысл по коду: `TosShipmentResultAction.replaceContainerInOrder` заменяет КТК строки на фактически отгруженный TOS только при `random=true` («любой подходящий КТК»); при `false` пишет WARN и замену не делает. |
| `ktk_number_unknown` | `BOOLEAN NULL DEFAULT false` | `KIS-1970`; service нормализует `null → false` на add/update; при `true` на update очищает `seal_type_id`. Root имеет отдельный флаг того же имени, обновляемый только для `TerminalArea=CONTAINER + TransportType=VEHICLE` — см. ниже. |
| `deleted`, audit | `BOOLEAN NOT NULL DEFAULT false`; стандартный audit | ALG-644; soft-delete через `BaseService.remove`, `postRemove` soft-удаляет item-строки КТК. |

Индексы: PK, `idx_shipping_order_container_container_id`. На `shipping_order_id` и `shipping_order_railway_carriage_id` индексов нет. CHECK нет. На строку ссылается `shipping_order_container_item.shipping_order_container_id`.

Update: если в теле `shippingOrderRailwayCarriage=null`, а у строки вагон был, `prepareModelToUpdate` вызывает `railwayCarriage.getId()` на `null` → `NullPointerException` (снять вагон через `PUT` нельзя; `INFERENCE` по коду, теста нет).

## getCargoWeight: исправление 09.11.2026

С 818586514 NULL weight строки заменяется нулём, отсутствующий container даёт нулевую тару. Прежний NPE для безномерного КТК закрыт кодом. У существующего Container с NULL weight защита по-прежнему отсутствует; @Column(nullable=false) не доказывает состояние старых данных. Отрицательная разница не ограничена. ТН суммирует результат и переводит в кг множителем 1000. [Формула и границы проверки](../business-rules/backend-behavior-changes-oct-nov-2026.md).

## Stored totals и `ktkNumberUnknown`-флаг заявки

[`ShippingOrderContainerService.calculateAndSetReceivingOrderFields`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/shippingordercontainer/ShippingOrderContainerService.java) (имя метода унаследовано от общего паттерна, несмотря на shipping-контекст) после add/update/remove читает все контейнеры заявки и пишет `total_container_quantity = count(rows)`, `total_weight = sum(row.weight, null skipped)` — те же формулы, что и в receiving.

[`checkFlagKtkNumber`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/shippingordercontainer/ShippingOrderContainerService.java) обновляет **отдельный** root-флаг `shipping_order.ktk_number_unknown = существует хотя бы один active КТК этой заявки с `ktkNumberUnknown=true``, но **только** если `terminalArea = CONTAINER` и `transportType = VEHICLE`; для остальных комбинаций (включая `CONTAINER + RAILWAY`) метод выходит без изменений — старое значение root-флага в этом случае не трогается ни в какую сторону. `postAdd`/`postRemove` также вызывают `updateReceivingOrderRequestedService` → `ShippingOrderRequestedServiceService.updateCargoPlaceRequestedServices` — тот же side effect на `CARGO_PLACE`-услуги, что и у [грузового места](shipping-order-cargo-as-is.md#stored-root-totals-и-побочный-пересчёт-услуг).

```mermaid
flowchart TD
    D[Creation/Update DTO: order/container/carriage refs, seal/danger/owner, flags] --> V[ValidShippingOrderContainer: conditional on ktkNumberUnknown/empty]
    V --> M[Mapper: new UUID]
    M --> S[Service: app-level duplicate count deleted=false, catalog tare, owner snapshot]
    S --> C[(shipping_order_container: no physical UNIQUE)]
    C --> R[Sum weight, count rows]
    R --> T[(shipping_order.total_container_quantity/total_weight)]
    C --> K[checkFlagKtkNumber: CONTAINER+VEHICLE only]
    K --> KF[(shipping_order.ktk_number_unknown)]
    C --> RS[updateCargoPlaceRequestedServices]
    C --> TN[TNContainerReportDataCollectorService.getCargoWeight]
```

## Outbound: route chain package и `ownerContainerId`

Строку `shipping_order_container` читают **два независимых** outbound-механизма, которые не описаны нигде централизованно:

1. **Старый row-level `outbound_config`** — запись `EntityType.SHIPPING_ORDER_CONTAINER` закомментирована в [`OutboundConfigService`](../../../web-layer/src/main/java/ru/korusconsulting/alis/config/outbound/OutboundConfigService.java) (`// addConfig(EntityType.SHIPPING_ORDER_CONTAINER, MessageType.CARGO_SHIPMENT_TASK)`) — этот путь мёртв, именно про него открытый вопрос №7 ниже.
2. **Route chain package** — активный, отдельный от (1) механизм. [`ShippingOrderContainerMapper.toChainPackageDto`](../../../web-layer/src/main/java/ru/korusconsulting/alis/mapper/shippingordercontainer/ShippingOrderContainerMapper.java) строит [`ShippingOrderContainerChainPackageDto`](../dto/catalog/routetocargochainpackage/ShippingOrderContainerChainPackageDto.md), который собирает [`ShippingRouteChainPackageExportService`](../../../web-layer/src/main/java/ru/korusconsulting/alis/datareon/service/routechainpackage/ShippingRouteChainPackageExportService.java) в рамках `ShippingRouteChainPackageDto` для рейса и отправляет в Datareon (через `ShippingRouteChainPackageDatareonRestService`/`ScheduledShippingRouteChainPackageExportService`). Включается только когда `OutboundConfigService.isRouteChainPackageEnabled` — то есть площадка рейса `CONTAINER` и feature flag `receivingAndShippingRailwayRouteChainPackageEnabled`; при выключенном флаге accept использует обычную интеграцию от SHIPPING_ORDER (в том числе CARGO_SHIPMENT_TASK), а не отключённый child-hook. Поэтому отсутствие route chain package не означает отсутствия всей интеграции заявки.

Текущий `toChainPackageDto` маппит `containerOwnerId` из `containerOwner.id` — собственного поля ShippingOrderContainer.containerOwner. Историческое ownerContainerId не является текущим JSON-именем вывоза.

**История дефекта (закрыт KIS-4830).** С 22.09.2026 (KIS-4716) по 08.10.2026 это поле у новых строк было всегда `null`, поэтому пакет по вывозу уходил в Datareon с `ownerContainerId = null`, хотя read-DTO показывали владельца из registry. Коммит `401bbea3` (KIS-4830, 08.10.2026) стал заполнять поле снимком владельца из registry (см. таблицу колонок), а read-DTO (`toDto`, `toDetailedDto`, merge-DTO) — читать именно его, а не `container.containerOwner.client`. Сейчас пакет и API читают одно поле строки; для DRAFT/ON_REVIEW оно дополнительно синхронизируется и backfill-ится из registry, для принятых строк сохраняется snapshot. Состояние конкретных старых строк без данных среды не установлено. Подробности — в [регистре остатков и владельца КТК](../business-rules/container-remains-and-owner-as-is.md#владелец-на-строке-вывоза-kis-4830).

## Merge-эндпоинты: замена в границах всей заявки, не вагона

`PUT /merge` группирует вход по вагону (`ShippingOrderContainerMergeDto` на вагон, вложенный список контейнеров), но фактическая замена (`ShippingOrderContainerService.merge` → `super.upsertAndDelete(filterByShippingOrder, updateDtos)`) сканирует **весь** `shipping_order_id`, а не отдельный вагон. Если в запросе перечислены контейнеры не для всех вагонов заявки, контейнеры отсутствующих в запросе вагонов физически совпадают со «спискoм на удаление» диапазона upsert и будут soft-удалены. `mergeForUnnumberedOrder` — аналогичная операция, но дополнительно требует `shippingOrder.fillingType == CONTAINER` (иначе `IllegalArgumentException`) и не переносит из DTO вагон, тип пломбы, `customsClearance`, `random`, `ktkNumberUnknown`, `dataTimeKrugloyePole`, `customerService`, `ownerRailwayCarriage`. Оба метода используют `BaseService.upsertAndDelete(F filter, List<U> dtos)` со strict-проверкой: неизвестный non-null `id` вне scope даёт `NotFoundException`. Каждая строка проходит обычные `add`/`update`/`remove` (с пересчётом totals и флага).

## Что подтверждают tests, но не их запуск

- [`ShippingOrderContainerServiceIntegrationTest`](../../../web-layer/src/integrationTest/java/ru/korusconsulting/alis/service/shippingordercontainer/ShippingOrderContainerServiceIntegrationTest.java) покрывает delete с каскадным soft-remove item-строк, переход `empty=true` с удалением items, пересчёт root totals при add/update/remove, preview dto и один positive merge-тест.
- [`ShippingOrderContainerDaoServiceTest`](../../../db-layer/src/integrationTest/java/ru/korusconsulting/alis/service/shippingordercontainer/ShippingOrderContainerDaoServiceTest.java) — DAO-уровень.
- Не найдено: тест `getCargoWeight()`/ТН-отчёта для заявки с `ktkNumberUnknown`-контейнером; тест `merge` с частичным списком вагонов; тест изменения КТК в заявке со статусом `ACCEPTED`.
- Тесты не запускались; их наличие не подтверждает применённую схему.

## Неподтверждённое и вопросы для ТЗ

1. `OPEN_QUESTION` [ОКРУЖЕНИЕ] Не проверены `DATABASECHANGELOG`, `pg_catalog`, допустимые null в развернутой БД; в частности, наличие колонки `customs_control` на средах.
2. ~~Конфликт app-level дубль-чека и физического `UNIQUE` после soft-delete~~ — закрыто: UNIQUE удалён `ALG-670`, конфликта нет. Новый вопрос `OPEN_QUESTION` [АНАЛИТИК]: нужна ли физическая уникальность (partial index `WHERE deleted=false AND container_id IS NOT NULL`)?
3. `OPEN_QUESTION` [АНАЛИТИК] Нужен runtime-тест ТН для КТК без номера: прежний NPE для null weight/container закрыт 818586514. Отдельно проверить существующий Container с null тарой и отрицательную разницу веса.
4. `OPEN_QUESTION` [АНАЛИТИК] Текст `ValidShippingOrderContainer.message()` перечисляет `weight`/`dangerousCargo`, которые не проверяются (и `dangerous_cargo` удалена) — обновить текст.
5. `OPEN_QUESTION` [АНАЛИТИК] Бизнес-смысл `data_time_krugloye_pole`; какой default `random` верный (SQL/JPA `false` против DTO `true`) — от него зависит, разрешит ли результат TOS заменить КТК. ~~Смысл `random`~~ — по коду: разрешение замены КТК результатом TOS.
6. `OPEN_QUESTION` [АНАЛИТИК] Должен ли `PUT /merge` быть full-order-replace, или UI всегда шлёт полный список вагонов.
7. `OPEN_QUESTION` [АНАЛИТИК] Судьба `@Deprecated` `getListOfEntitiesToOutbound`/закомментированного `insertRowsForFurtherIntegration` (dead outbound config). Не путать с активным route chain package.
8. ~~`ownerContainerId` в route chain package для вывоза всегда `null` с 22.09.2026~~ — закрыто KIS-4830 (`401bbea3`, 08.10.2026). DRAFT/ON_REVIEW уже синхронизируются и имеют backfill; открыта политика исправления snapshot принятых заявок и фактические старые данные.
9. `OPEN_QUESTION` [АНАЛИТИК] Сервис КТК не проверяет статус заявки (`checkOrderStatusForUpdate`) — КТК меняются в `ACCEPTED`/`DONE` заявках. Дефект или намеренно (например, для корректировок после accept)?
10. `OPEN_QUESTION` [АНАЛИТИК] Миграция KIS-664 не удалила `shipping_order_container.customs_control` (дважды удаляет из receiving) — удалить колонку?
11. `OPEN_QUESTION` [АНАЛИТИК] `PUT` со снятым вагоном (`shippingOrderRailwayCarriage=null`) по коду даёт NPE — нужен ли сценарий «отвязать КТК от вагона».

## Чек-лист изменения таблицы

1. При изменении правил уникальности помнить, что физического UNIQUE нет — защита только в `checkIfAlreadyExists`.
2. При вызове методов, вычисляющих производные значения из nullable-полей entity (`getCargoWeight()` и подобные), переносить null-guard внутрь метода, а не полагаться на `filter(Objects::nonNull)` после `map`.
3. При обновлении текста Bean Validation error message синхронизировать его с фактическим состоянием SQL-схемы (удалённые колонки не должны оставаться в тексте ошибки).
4. Для merge/upsert-эндпоинтов, где scope замены шире, чем единица группировки во входном DTO (вагон vs вся заявка), явно документировать это в API-контракте, чтобы клиент не терял данные по невключённым группам.
5. Для нового reference-поля явно решить, `IdDto` или `IdCodeDto` использовать в DTO, и не оставлять `code` неиспользуемым, если lookup всё равно идёт по `id`.

## Связанные документы

- [Правила вывоза](../business-rules/shipping-orders.md)
- [Валидация заявок](../business-rules/order-validation.md)
- [Inbound actions вывоза](../business-rules/shipping-inbound-actions.md)
- [Route shipping plan/fact (meta-контур КТК/вагонов)](../business-rules/route-shipping-plan-fact-as-is.md)
- [Регистр остатков и владельца КТК: `ContainerOwner` AS-IS](../business-rules/container-remains-and-owner-as-is.md)
- [Route chain package export: 4 пакета в Datareon AS-IS](../business-rules/route-chain-package-export-as-is.md)
- [Корень заявки на вывоз: физическая модель AS-IS](shipping-order-root-as-is.md)
- [Грузовое место заявки на вывоз: физическая модель AS-IS](shipping-order-cargo-as-is.md)
- [КТК поставки: физическая модель AS-IS (аналогичный контур)](receiving-order-container-as-is.md)
- [API заявок](../api/order-api.md)
- [JPA-паспорт ShippingOrderContainer](../entities/catalog/entities/shippingordercontainer/ShippingOrderContainer.md)

## Уточнение целевой сверки 11.11.2026

Колонка owner_container_id переименована в container_owner_id, Java поле — containerOwner. DRAFT/ON_REVIEW строки синхронизируются с регистром при штатных переходах/смене владельца; принятые строки сохраняются. [Правила и миграция backfill](../business-rules/shipping-container-owners-as-is.md).
