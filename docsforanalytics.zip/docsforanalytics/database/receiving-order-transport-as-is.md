# `receiving_order_transport`: транспорт заявки на поставку, физическая модель AS-IS (часть 2) — DEPRECATED

> **Сверено:** backend `3d3899d5d` (13.11.2026) · **Основание:** `SOURCE_CONFIRMED` — миграции удаления/backfill; частично: тело — история до `d30d77ad`, построчно не пересверялось; БД и стенд не проверялись.

> **DEPRECATED.** Коммит `d30d77ad` (KIS-4093, 24.09.2026) удалил таблицу/сущность `receiving_order_transport` ([`remove_order_transport.sql`](../../../db-layer/src/main/resources/db/changelog/v.1.34.0/v.1.34.0_20260718_KIS-4093_remove_order_transport.sql)), её controller/mapper/service/DTO и endpoint'ы `POST/PUT /receivingordertransport/*`, описанные ниже. [Backfill](../../../db-layer/src/main/resources/db/changelog/v.1.34.0/v.1.34.0_20260718_KIS-4093_backfill_order_transport_data.sql) перед удалением:
> - `shipper_id`/`waybill` → `receiving_order.shipper_id`/`waybill` через `COALESCE` (значение корня приоритетно, transport-значение терялось при заполненном корне);
> - `carrier_id` → `route.client_related_entity_id`, `client_driver_id`/`client_vehicle_id` → одноимённые колонки `route`: создаётся новый `route` (`route_type='RECEIVING'`, `status` = статус заявки) **только** для заявок без `route_id`; у заявок с уже привязанным рейсом перевозчик/водитель/ТС transport-строки не переносились;
> - `outbound_data.entity_type` `RECEIVING_ORDER_TRANSPORT` → `RECEIVING_ORDER`; удалены permission `ReceivingOrder.ReceivingOrderTransport` и `entity_info` `ReceivingOrderTransport`.
>
> Текущее состояние: [корень заявки, раздел о переносе](receiving-order-root-as-is.md#перенос-полей-удалённой-receiving_order_transport-kis-4093) (поле `route` убрано из DTO заявки; водитель/ТС в detailed DTO берутся из `route`). Жизненный цикл рейса — [route-lifecycle-as-is.md](../business-rules/route-lifecycle-as-is.md); отдельного физического паспорта таблицы `route` в `database/` нет. Граница удаления и замещающий код пересверены на 3d3899d5d 12.11.2026; историческое тело не сертифицируется как текущая реализация. Ниже — исторический AS-IS удалённой таблицы.

Это **source-level реконструкция** на момент до удаления (Java DTO/controller/mapper/service/JPA, Liquibase, тесты), а не проверка применённой БД. Корень заявки и его собственные `shipper_id`/`waybill` описаны [отдельно](receiving-order-root-as-is.md): одноимённые поля транспорта физически относились к другой таблице. Текущие правила заявки — в [процессе поставки](../business-rules/receiving-orders.md).

## Общий ключ и HTTP-цепочка

`ReceivingOrderTransport` (сущность удалена) — отдельная `@Entity @Table(RECEIVING_ORDER_TRANSPORT)` с наследуемыми audit-полями `BaseEditable`. [`ALG-199 CREATE TABLE`](../../../db-layer/src/main/resources/db/changelog/v.1.0.0/v1.0.0_20240710_ALG-199_add_table_receiving_order_transport.sql) задавал `id UUID PRIMARY KEY REFERENCES receiving_order(id) NOT NULL`: **один** transport row на один root order ID и отсутствие transport без root обеспечивались этим SQL source constraint. В `ReceivingOrder.transport` был объявлен `@OneToOne(cascade=PERSIST,MERGE) @JoinColumn(name="id")`; child-класс не содержал `receivingOrder` entity field. Это shared-key связь, а не отдельная `receiving_order_id` колонка.

`ReceivingOrderTransportController` (удалён) объявлял `POST /receivingordertransport/` с `CreationDto` и `PUT /receivingordertransport/{id}` с `UpdateDto`. Create/update были защищены `@Secure(..., CREATE/WRITE)` по `ReceivingOrder.ReceivingOrderTransport` в source. Для пяти `IdDto` полей (`receivingOrder`, `shipper`, `carrier`, `clientVehicle`, `clientDriver`) DTO задавал `@NotNull @Valid`, а `IdDto.id` — `@NotNull`; `waybill` не имел Bean Validation `@NotBlank/@Size`. Update наследовал поля create и добавлял обязательный UUID `id`.

`ReceivingOrderTransportMapper` (удалён) явно маппил `receivingOrder.id → model.id` **и при create, и при update**. `BaseService.add` выполнял modelCreation → DAO save в `@Transactional`; service транспорта не переопределял `prepareModelToAdd`. SQL PK/FK и NOT NULL проверяли итоговые значения при INSERT, но source не показывал отдельной проверки принадлежности shipper/carrier/driver/vehicle клиенту заявки.

У `PUT` Java handler **не было** `@PathVariable id` в signature, вызывался `service.update(updateDto)`, а не имеющийся у `BaseService` overload `update(UUID id, U dto)` со сверкой path/body. Lookup target шёл по **`UpdateDto.id`**. Mapper при этом создавал updateModel с **`receivingOrder.id`**; `preUpdate`/`prepareModelToUpdate` не сравнивали его с найденным target и не перепривязывали PK. Поэтому расхождение path ID, body `id` и body `receivingOrder.id` не имело доказанной защитной проверки на этом HTTP пути (вопрос снят вместе с удалением endpoint'а).

## Колонки и изменение миграциями

| DTO / JPA поле | SQL source contract на текущем checkout | Изменение/обработка |
|---|---|---|
| `receivingOrder.id` → `ReceivingOrderTransport.id` | `UUID PK NOT NULL`, FK на `receiving_order(id)` | ALG-199; один shared ID. Create mapper подставляет root ID, update target выбирается отдельно по `UpdateDto.id`. |
| `shipper.id` → `shipper_id` | `UUID NOT NULL REFERENCES client_related_entity(id)` | ALG-199. Update при отличии делает `ClientRelatedEntityDaoService.findById`, затем `setShipper`; это **не** root `receiving_order.shipper_id`. |
| `carrier.id` → `carrier_id` | `UUID NOT NULL REFERENCES client_related_entity(id)` | ALG-199. Update аналогично делает lookup. Это **не** поздний root `carrier_id` из KIS-3631. |
| `clientDriver.id` → `client_driver_id` | `UUID NOT NULL REFERENCES client_driver(id)` | [`ALG-430`](../../../db-layer/src/main/resources/db/changelog/v.1.0.0/v1.0.0_20240729_ALG-430_update_receiving_order_transport.sql) сначала `DELETE FROM RECEIVING_ORDER_TRANSPORT`, затем добавляет обязательный FK; update делает DAO lookup. Содержимое старых transport rows этим source SQL уничтожалось при применении changeset. |
| `clientVehicle.id` → `client_vehicle_id` | `UUID NOT NULL REFERENCES client_vehicle(id)` | Тот же ALG-430 после удаления строк; update делает DAO lookup. |
| `waybill` → `waybill` | `VARCHAR(50) NULL` после изменений | [`ALG-568`](../../../db-layer/src/main/resources/db/changelog/v.1.0.0/v1.0.0_20240815_ALG-568_add_fields_for_receiving_order_entities.sql) добавил `VARCHAR(50)`, заполнил `''`, затем `NOT NULL`; [`KIS-282`](../../../db-layer/src/main/resources/db/changelog/v.1.0.0/v1.0.0_20250306_KIS-282_drop_not_null.sql) снял `NOT NULL`. Update присваивает напрямую, включая `null`. Длина `50` не выражена DTO validation/JPA annotation; итоговый DB exception/HTTP mapping не тестировались. |
| Audit, не request DTO | `created_at TIMESTAMP NOT NULL`, `created_by VARCHAR(50) NOT NULL`, `updated_at TIMESTAMP NULL`, `updated_by VARCHAR(50) NULL` | ALG-199 и inherited [`BaseEditable`](../../../wms-layer/src/main/java/ru/korusconsulting/wms/model/base/BaseEditable.java)/`BaseCreatable` auditing. Создание audit не задаётся транспортным DTO. |

Первоначальный ALG-199 хранил текстовые `vehicle_number`, `vehicle_trailer_number`, `vehicle_insurance_number`, `driver_name`, `driver_phone_number`, `driver_poa_number`. ALG-430 переименовал `vehicle_number → vehicle_code`, `driver_name → driver_code` и добавил FK справочников; ALG-568 добавил persisted `with_trailer BOOL NOT NULL` с backfill из trailer number. [`KIS-1106`](../../../db-layer/src/main/resources/db/changelog/v.1.23.0/v.1.23.0_20250723_KIS-1106_remove_driver_and_vehicle_info_from_order_transport.sql) удалил **все эти snapshot-колонки** (`vehicle_code`, trailer/insurance, `with_trailer`, `driver_code`, phone/POA). На текущей JPA entity их уже нет. Старыми схемами/экспортами нельзя доказывать существование этих полей в текущей таблице; применённая миграция конкретной среды не проверена.

По просмотренным SQL references к этой таблице отдельные `UNIQUE`, `CHECK` или non-PK index не найдены. PK обеспечивает уникальность `id`; наличие индексов FK, FK names, sequence/default, ON DELETE и полный набор фактических constraints надо сверять с `pg_catalog` и `DATABASECHANGELOG`, а не выводить из JPA.

## Источник полей ответа и риск несогласованного snapshot

`ReceivingOrderTransportDto` (удалён) содержал `shipper`, `carrier`, `vehicleInfo`, `driverInfo`, `waybill`, но `vehicleInfo`/`driverInfo` **не** читаются из старых колонок транспорта. Mapper `toDto/toDetailedDto` строит [`VehicleInfoDto`](../dto/catalog/transport/VehicleInfoDto.md) из `clientVehicle.id/code/trailerNumber/insuranceNumber/withTrailer` и [`DriverInfoDto`](../dto/catalog/transport/DriverInfoDto.md) из `clientDriver.id/code/phoneNumber/POANumber`; `shipper` строится через `ClientRelatedEntityMapper.toShortDto`. `carrier` представлен `IdCodeDto` по mapper declaration, а точную сгенерированную MapStruct реализацию не инспектировали. Отсюда вывод: изменение справочной записи машины/водителя может изменить последующий transport response без UPDATE transport row. Для исторического «снимка на дату заявки» этих current table columns недостаточно; решение о versioning/snapshot выходит за рамки AS-IS.

```mermaid
flowchart TD
    D[Creation DTO: receivingOrder/shipper/carrier/vehicle/driver IDs] --> M[Mapper: receivingOrder.id to transport.id]
    M --> T[(receiving_order_transport: shared PK/FK and reference FKs)]
    U[Update DTO: id plus inherited fields] --> L[BaseService lookup by body id]
    L --> S[Service: root status check and selective reference lookups]
    S --> T
    T --> R[Response mapper]
    V[(client_vehicle current fields)] --> R
    C[(client_driver current fields)] --> R
```

`ReceivingOrderTransportDaoServiceTest` (удалён вместе с сущностью) содержал add/find/page/filter/update DAO cases на Testcontainers; [`ReceivingOrderTestEntityFactory`](../../../db-layer/src/integrationTest/java/ru/korusconsulting/alis/testcontainer/factory/ReceivingOrderTestEntityFactory.java) ранее создавала transport с `id = receivingOrder.id` и четырьмя справочными references. Это **не** прямой тест HTTP DTO validation, path/body mismatch, отсутствующей root записи, FK/NOT NULL или обновления справочника после создания заявки. Тесты не запускались. Influencing commits: `11de1385` (initial SQL chain 2024-08), `13918fb6` (waybill nullable, 2025-03), `c9294b26` (удаление текстовых driver/vehicle columns, 2025-07). Commit — исходная история checkout, не доказательство того, что changeset прошёл на deployed БД.

## Уточнение backfill и потерь 11.11.2026

Backfill d30d77adf переносит shipper/waybill через COALESCE в receiving root и consignee/address в shipping root: непустое root-значение имеет приоритет. При отсутствии route и наличии transport создаёт отдельный Route на заявку с UUID, прежними ссылками carrier/driver/vehicle; data_time — плановая дата, затем transport.created_at, затем root.created_at. При уже существующем route новый не создаётся и его поля transport-значениями не дозаполняются. После переписывания outbound entity_type удаляются permission/entity_info и transport-таблицы. Это миграция модели, не runtime создание transport-объекта.

Номер/генерация Route миграцией явно не передаются; применимость default/sequence и соответствие orderStatus значениям RouteStatus требуют контроля applied schema/данных. Материалы об исторической таблице выше не являются API для новых интеграций.
