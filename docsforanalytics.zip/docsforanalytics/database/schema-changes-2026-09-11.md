# Изменения физической модели: сентябрь–ноябрь 2026

Срез `3d3899d5d`. Сравнение `aba0c312a695578bd017b9c1151fd5d5aaae465e..HEAD`: исходники Git, без reflog и без обновления remote. Имена/даты SQL не означают дату включения в dev. AS_IS / SOURCE_CONFIRMED по SQL; выполнение на среде не проверялось.

## Hibernate validation и связанные типы (87ccc2682, сверка 12.11.2026)

В основном web application.yaml и db integrationTest application.yaml ddl-auto перенесён в spring.jpa.hibernate.ddl-auto и установлен validate. Это проверка соответствия JPA/схемы при запуске, не автоматическое обновление таблиц Hibernate. Конфигурация конкретной среды/профиля и успешный старт приложения этой source-сверкой не доказаны.

Кроме перечисленных ниже SQL-изменений, коммит исправляет Java-модель: ContainerRemainView.clientId и множество ContainerRemainViewFilter.clientId — UUID вместо String; ContainerRemain больше не фиксирует schema=alis в @Table. InboundEvent.terminalArea хранится как enum STRING, а не ordinal; миграция нормализует только 0→CONTAINER и 1/2/WAREHOUSE_428→WAREHOUSE, не произвольные неизвестные значения. RailwayStation.esrCode имеет JdbcTypeCode CHAR и columnDefinition char(6).

После DROP зависимых views в миграции номеров четыре rerunnable SQL получили явные author/id changeset с runOnChange=true для повторного создания view. Это изменение Liquibase-идентичности; наличие исправленного include не подтверждает порядок/результат применения на конкретной БД. Все 17 файлов исходного diff сопоставлены; SQL и Java integration tests не запускались.

## Реестр файлов

| Файл | Git | Эффект / границы сверки |
|---|---|---|
| [cumulative-rerunnable.yml](../../../db-layer/src/main/resources/db/changelog/rerunnable/cumulative-rerunnable.yml) | M | Изменяет последовательность include; наличие файлов проверено статически, не запуском Liquibase. |
| [view_container_meta.sql](../../../db-layer/src/main/resources/db/changelog/rerunnable/view_container_meta.sql) | A | Новая view ID контейнера→ISO code через LEFT JOIN. |
| [view_container_movement_meta.sql](../../../db-layer/src/main/resources/db/changelog/rerunnable/view_container_movement_meta.sql) | A | Meta view движений; исправлена formatted changeset identity; source-level покрытие полей требует сверки потребителя. |
| [view_container_movements.sql](../../../db-layer/src/main/resources/db/changelog/rerunnable/view_container_movements.sql) | M | Analytics view движений КТК; changeset identity исправлена для восстановления после DROP зависимостей. |
| [view_good_movements.sql](../../../db-layer/src/main/resources/db/changelog/rerunnable/view_good_movements.sql) | M | Analytics view движений товара; changeset identity исправлена для восстановления после DROP зависимостей. |
| `view_grouped_waybill.sql` (удалён) | D | Удалён исходник materialized read model, заменён waybill_view. |
| [view_railway_carriage_meta.sql](../../../db-layer/src/main/resources/db/changelog/rerunnable/view_railway_carriage_meta.sql) | A | Новая meta view вагона: sort, model, ремонты и другие атрибуты; потребитель/фильтры требуют отдельной семантической сверки. |
| [view_waybill.sql](../../../db-layer/src/main/resources/db/changelog/rerunnable/view_waybill.sql) | A | Обычная view накладных вместо grouped MV; категория, parent/type, активные счётчики с excluded-фильтрами. |
| [cumulative.yml](../../../db-layer/src/main/resources/db/changelog/v.1.34.0/cumulative.yml) | M | Изменяет последовательность include; наличие файлов проверено статически, не запуском Liquibase. |
| [v.1.34.0_20260718_KIS-4093_backfill_order_transport_data.sql](../../../db-layer/src/main/resources/db/changelog/v.1.34.0/v.1.34.0_20260718_KIS-4093_backfill_order_transport_data.sql) | A | Перенос полей и связей Route из transport-таблиц в корни заявок; использует временные таблицы выбора рейса. |
| [v.1.34.0_20260718_KIS-4093_remove_order_transport.sql](../../../db-layer/src/main/resources/db/changelog/v.1.34.0/v.1.34.0_20260718_KIS-4093_remove_order_transport.sql) | A | Переписывает outbound entity_type на корни заявок, удаляет transport permissions/entity_info и обе transport-таблицы. |
| [cumulative.yml](../../../db-layer/src/main/resources/db/changelog/v.1.35.0/cumulative.yml) | M | Изменяет последовательность include; наличие файлов проверено статически, не запуском Liquibase. |
| [v.1.35.0_20260901_KIS-4432_reconcile_container_iso_dictionary.sql](../../../db-layer/src/main/resources/db/changelog/v.1.35.0/v.1.35.0_20260901_KIS-4432_reconcile_container_iso_dictionary.sql) | A | Исправляет identifity→identifier, BIGINT NOT NULL UNIQUE; проверяет конфликты/null/дубли, upsert seed по identifier и entity_info. |
| [v.1.35.0_20260901_KIS-4664_add_container_type_check_constraint.sql](../../../db-layer/src/main/resources/db/changelog/v.1.35.0/v.1.35.0_20260901_KIS-4664_add_container_type_check_constraint.sql) | A | CHECK container_type с UNKNOWN; не задаёт NOT NULL этим SQL. |
| [v.1.35.0_20260901_KIS-4665_add_unknown_railway_carriage_model.sql](../../../db-layer/src/main/resources/db/changelog/v.1.35.0/v.1.35.0_20260901_KIS-4665_add_unknown_railway_carriage_model.sql) | A | Идемпотентная вставка «Не определено» при отсутствии code; formatted changeset заменяет прежний raw вариант. |
| [v.1.35.0_20260908_KIS-4432_reconcile_container_length.sql](../../../db-layer/src/main/resources/db/changelog/v.1.35.0/v.1.35.0_20260908_KIS-4432_reconcile_container_length.sql) | A | ADD IF NOT EXISTS length NUMERIC(15,3), nullable без DEFAULT. |
| [v.1.35.0_20260909_KIS-4626_add_waybill_creation_source.sql](../../../db-layer/src/main/resources/db/changelog/v.1.35.0/v.1.35.0_20260909_KIS-4626_add_waybill_creation_source.sql) | A | creation_source VARCHAR(20) NOT NULL, backfill по порогу identifier 10^9; CHECK ETRAN/MANUAL и соответствия порогу. |
| [v.1.35.0_20260911_KIS-4626_change_waybill_delivery_deadline_to_date.sql](../../../db-layer/src/main/resources/db/changelog/v.1.35.0/v.1.35.0_20260911_KIS-4626_change_waybill_delivery_deadline_to_date.sql) | A | DROP waybill_view, delivery_deadline→DATE через cast; временная часть прежнего значения теряется. |
| [v.1.35.0_20260911_KIS-4626_drop_grouped_waybill.sql](../../../db-layer/src/main/resources/db/changelog/v.1.35.0/v.1.35.0_20260911_KIS-4626_drop_grouped_waybill.sql) | A | DROP MATERIALIZED VIEW grouped_waybill; текущая read model — обычная waybill_view. |
| [v.1.35.0_20260915_KIS-4661_add_container_owner_status.sql](../../../db-layer/src/main/resources/db/changelog/v.1.35.0/v.1.35.0_20260915_KIS-4661_add_container_owner_status.sql) | A | Статус VARCHAR(12) NOT NULL DEFAULT ON_TERMINAL с backfill; receiving/shipping FK и индексы; old/new status history с CHECK. |
| [v.1.35.0_20260921_KIS-4716_add_owner_client_columns.sql](../../../db-layer/src/main/resources/db/changelog/v.1.35.0/v.1.35.0_20260921_KIS-4716_add_owner_client_columns.sql) | A | default_container_owner_id FK client, backfill client_id, NOT NULL; nullable receiving owner_container_id_new и waybill owner_container_id. |
| [v.1.35.0_20260921_KIS-4716_migrate_owner_client_data.sql](../../../db-layer/src/main/resources/db/changelog/v.1.35.0/v.1.35.0_20260921_KIS-4716_migrate_owner_client_data.sql) | A | Data migration receiving owner из client_related_entity по жёсткой таблице UUID→Client; не универсальный lookup. |
| [v.1.35.0_20260922_KIS-4716_cleanup_receiving_order_container_owner.sql](../../../db-layer/src/main/resources/db/changelog/v.1.35.0/v.1.35.0_20260922_KIS-4716_cleanup_receiving_order_container_owner.sql) | A | Удаляет старую owner_container_id, переименовывает новую колонку и FK. Ранний revert не отражает итоговую цепочку. |
| [v.1.35.0_20260925_KIS-4773_drop_unit_of_measure_conversion.sql](../../../db-layer/src/main/resources/db/changelog/v.1.35.0/v.1.35.0_20260925_KIS-4773_drop_unit_of_measure_conversion.sql) | A | DROP unit_of_measure_conversion и DELETE entity_info по имени. |
| [v.1.35.0_20260929_align_order_number_with_long.sql](../../../db-layer/src/main/resources/db/changelog/v.1.35.0/v.1.35.0_20260929_align_order_number_with_long.sql) | A | DROP зависимых views; receiving/shipping number→BIGINT, sequences AS BIGINT NO MAXVALUE. |
| [v.1.35.0_20260929_align_outbound_data_attempts_with_integer.sql](../../../db-layer/src/main/resources/db/changelog/v.1.35.0/v.1.35.0_20260929_align_outbound_data_attempts_with_integer.sql) | A | attempts→INTEGER; прежние NOT NULL/DEFAULT сохраняются. |
| [v.1.35.0_20260929_normalize_inbound_event_terminal_area.sql](../../../db-layer/src/main/resources/db/changelog/v.1.35.0/v.1.35.0_20260929_normalize_inbound_event_terminal_area.sql) | A | Data migration: 0→CONTAINER; 1/2/WAREHOUSE_428→WAREHOUSE. |
| [v.1.35.0_20260930_KIS-4795_add_waybill_category.sql](../../../db-layer/src/main/resources/db/changelog/v.1.35.0/v.1.35.0_20260930_KIS-4795_add_waybill_category.sql) | A | waybill_category VARCHAR(10) NOT NULL, backfill Archive/Inbound/Outbound по DONE/станциям; DELETE накладных с NULL категорией; CHECK enum. |
| [v.1.35.0_20260930_align_order_total_quantities_with_long.sql](../../../db-layer/src/main/resources/db/changelog/v.1.35.0/v.1.35.0_20260930_align_order_total_quantities_with_long.sql) | A | 7 receiving и 6 shipping quantity totals→BIGINT через ::BIGINT; weight/price не меняются. |
| [v.1.35.0_20260930_align_route_number_with_long.sql](../../../db-layer/src/main/resources/db/changelog/v.1.35.0/v.1.35.0_20260930_align_route_number_with_long.sql) | A | route.number→BIGINT, sequence AS BIGINT NO MAXVALUE. |
| [v.1.35.0_20261006_KIS-4830_shipping_container_owner_client.sql](../../../db-layer/src/main/resources/db/changelog/v.1.35.0/v.1.35.0_20261006_KIS-4830_shipping_container_owner_client.sql) | A | Data migration shipping owner→Client, nullable FK; несопоставленные значения могут стать NULL. |
| [v.1.35.0_202610120_KIS-4870_add_client_owner_for_unnumbered_orders.sql](../../../db-layer/src/main/resources/db/changelog/v.1.35.0/v.1.35.0_202610120_KIS-4870_add_client_owner_for_unnumbered_orders.sql) | A | Qty owner_client_id nullable FK Client; numbered owner_container_id→container_owner_id. |
| [v.1.35.0_20261012_KIS-4841_add_order_good_batch_unknown.sql](../../../db-layer/src/main/resources/db/changelog/v.1.35.0/v.1.35.0_20261012_KIS-4841_add_order_good_batch_unknown.sql) | A | batch_unknown BOOLEAN NOT NULL в receiving_order_good/shipping_order_good; DEFAULT FALSE только для backfill, затем DROP DEFAULT. |
| [v.1.35.0_20261015_KIS-4874_extended_okpo_field.sql](../../../db-layer/src/main/resources/db/changelog/v.1.35.0/v.1.35.0_20261015_KIS-4874_extended_okpo_field.sql) | A | company.okpo и client.okpo→VARCHAR(14). |
| [v.1.35.0_20261021_order_cancel_payload.sql](../../../db-layer/src/main/resources/db/changelog/v.1.35.0/v.1.35.0_20261021_order_cancel_payload.sql) | A | outbound_data.payload TEXT nullable, без DEFAULT/backfill. |
| [v.1.35.0_20261023_order_reject_after_start_permissions.sql](../../../db-layer/src/main/resources/db/changelog/v.1.35.0/v.1.35.0_20261023_order_reject_after_start_permissions.sql) | A | Добавляет RejectAfterStart paths и NO_ACCESS существующим role_id. |
| [v.1.35.0_20261102_KIS-4927_sync_unaccepted_shipping_container_owners.sql](../../../db-layer/src/main/resources/db/changelog/v.1.35.0/v.1.35.0_20261102_KIS-4927_sync_unaccepted_shipping_container_owners.sql) | A | Исправляет владельца неудалённых DRAFT/ON_REVIEW номерных строк из registry при наличии совпадения. |
| [v.1.35.0_20261105_KIS-4627_waybill_relations.sql](../../../db-layer/src/main/resources/db/changelog/v.1.35.0/v.1.35.0_20261105_KIS-4627_waybill_relations.sql) | A | Parent identifier/FK/connection-type FK; справочник 45/47; индексы parent; excluded NOT NULL DEFAULT FALSE у WRC/WC. |
| [v.1.35.0_20261109_KIS-4627_add_waybill_connection_type_entity_info.sql](../../../db-layer/src/main/resources/db/changelog/v.1.35.0/v.1.35.0_20261109_KIS-4627_add_waybill_connection_type_entity_info.sql) | A | Upsert entity_info WaybillConnectionType. |

## Порядок и ограничения проверки

Статически проверено 407 явных file-ссылок YAML внутри db-layer: целей, не найденных в db-layer, 2 (обе найдены в wms-layer/src/main/resources по classpath). Проверка не интерпретирует includeAll, classpath, preconditions или изменения уже выполненных changeset и не доказывает успешный накат.

Версионные SQL со снятием views зависят от последующего rerunnable-контура для их восстановления. Преобразования BIGINT/DATE и удаление данных по категории требуют проверки на копии данных и DATABASECHANGELOG; в этой задаче миграции не выполнялись. У view_container_meta.sql и view_railway_carriage_meta.sql заголовок `--changeset runOnChange:true` отличается от исправленных заголовков других views; корректность обработки текущим Liquibase требует отдельной проверки, не объявляется подтверждённым дефектом.

## Обнаруженные пропуски документации

- Исправлены типы totals, payerId update и окончательное имя owner_container_id; промежуточный revert больше не трактуется как текущая схема.
- Выделено удаление накладных с неразрешённой категорией в migration, а не только добавление поля категории.
- Состав API/DTO/Entity обновлён; исчезнувшие типы оставлены как явно исторические паспорта.

Связанные описания: [outbound](outbound-data-as-is.md), [связи накладных](../business-rules/waybill-supplementary-as-is.md), [владельцы вывоза](../business-rules/shipping-container-owners-as-is.md).

Classpath-ссылки, разрешаемые ресурсами WMS (не отсутствующие файлы):
- `db.changelog-master.yaml: db/changelog/1.1.6_20240520_korusmws5751_unit_of_measure.sql`
- `db.changelog-master.yaml: db/changelog/1.1.6_20240525_koruswms5837_permissions.sql`

## Удаление legacy WMS-кода: 74c11bf96

Коммит изменяет 179 файлов: удаляет 167 Java-классов и 7 changelog-ресурсов, меняет 4 файла и добавляет одну SQL-миграцию. Удалены WMS dictionary/uom controllers, DTO, models, repositories, services/mappers/predicates; вспомогательные mask/increment, Keycloak API adapters, старые exception/context, validation, Hibernate/auditor/logging классы и базовые интерфейсы. Действующие ALIS unit-of-measure API относятся к другим классам.

Текущий ComponentConfiguration сканирует ALIS и перечисленные WMS permission/role/user/mapper/event/keycloak/featureflags пакеты. Он не включает все WMS controllers. Удалены исключения двух старых uom компонентов и явные include ParentDependentSequenceRepository/DaoService. Из удаления controller-файла нельзя заключить, что endpoint был зарегистрирован в предыдущем ALIS runtime.

Единственная добавленная DDL в этом cleanup — DROP TABLE unit_of_measure_conversion без IF EXISTS и удаление entity_info с name=UnitOfMeasureConversion; соответствующее исключение убрано из EntityInfoConsistencyTest. Удаление Java dictionary-классов и старых SQL-файлов не выполняет DROP всех одноимённых legacy таблиц в существующей БД. Текущий db-layer master сохраняет ссылки на оставшиеся WMS unit_of_measure/permissions ресурсы; ссылок на семь удалённых changelog-файлов в текущих ресурсах модулей не найдено.

ExceptionAdviceUtils удаляет overload с DbErrorContext и fields; prepareErrorDto(Throwable) сохранён. Это не переход HTTP API на новую схему ошибок. Поиск полных имён 167 удалённых Java-классов с границами имени в текущих Java/XML/YAML/properties трёх модулей совпадений не дал; это ограниченный поиск ссылок, а не компиляция, проверка reflection или ORM startup. Исторические паспорта в документации помечены DEPRECATED отдельно.

Источники: [ComponentConfiguration](../../../web-layer/src/main/java/ru/korusconsulting/alis/config/ComponentConfiguration.java), [ExceptionAdviceUtils](../../../wms-layer/src/main/java/ru/korusconsulting/wms/controller/exception/ExceptionAdviceUtils.java), [master changelog](../../../db-layer/src/main/resources/db/changelog/db.changelog-master.yaml), [cleanup SQL](../../../db-layer/src/main/resources/db/changelog/v.1.35.0/v.1.35.0_20260925_KIS-4773_drop_unit_of_measure_conversion.sql).
