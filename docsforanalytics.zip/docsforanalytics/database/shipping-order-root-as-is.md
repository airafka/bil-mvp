# `shipping_order`: корень вывоза, физическая модель AS-IS (часть 16)

> **Сверено:** backend `3d3899d5d` (12.11.2026) · **Основание:** `SOURCE_CONFIRMED` — исходный код, миграции и тесты (тесты не запускались); БД и стенд не проверялись.

Это реконструкция по Liquibase-цепочке и Java-коду, а не инспекция применённой БД. Содержательная валидация и переходы статусов — в [правилах вывоза](../business-rules/shipping-orders.md) и [карте валидации](../business-rules/order-validation.md); здесь — корневая таблица, происхождение её полей и writers сохранённых агрегатов. Дочерние таблицы описаны в отдельных документах (см. [карту целостности](shipping-order-integrity-map.md)).

## Граница агрегата и цепочка записи

[`ShippingOrder`](../entities/catalog/entities/shippingorder/ShippingOrder.md) наследует mapped-superclasses [`TransportOrder`](../entities/catalog/mapped-superclasses/order/TransportOrder.md) → [`Order`](../entities/catalog/mapped-superclasses/order/Order.md) → `BaseEditable`; их поля физически находятся в `shipping_order`, отдельных таблиц superclass нет.

```mermaid
flowchart LR
    HTTP[POST /shippingorder/\nPUT /shippingorder/{id}] --> DTO[CreationDto / UpdateDto]
    DTO --> MAP[ShippingOrderMapper]
    MAP --> SVC[ShippingOrderService]
    SVC --> VAL[OrderCombinationValidator\nconsignee lookup]
    SVC --> DAO[ShippingOrderDaoService]
    DAO --> ROOT[(shipping_order)]
    ROUTE_API[POST/DELETE /routes/{id}/assign\nPOST /routes/{id}/change-status/accept] -->|route_id, need_transport, accept| ROOT
    CHILD[goods / cargo / containers / items\nservices / blackbox / qty] -->|recalculate stored totals| ROOT
    INBOUND[Datareon inbound actions] -->|actual time / statuses| ROOT
    DAO -->|status changed event| LSN[ShippingOrderListener\nApplicationStatusNotificationListener]
```

[`BaseService.add`](../../../wms-layer/src/main/java/ru/korusconsulting/wms/service/BaseService.java) и `update` транзакционны. Mapper создаёт новый UUID (route игнорируется), затем [`ShippingOrderService.prepareModelToAdd`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/shippingorder/ShippingOrderService.java) принудительно ставит `DRAFT`, проверяет грузополучателя и подставляет его адрес, проверяет сочетание площадки/транспорта/вида вывоза/типа заполнения (`OrderCombinationValidator.validateAndNormalize`). После INSERT в той же transaction `postAdd` прямой DAO-вставкой добавляет обязательные услуги договора.

Первоначальный [`CREATE TABLE` ALG-388](../../../db-layer/src/main/resources/db/changelog/v.1.0.0/v1.0.0_20240730_ALG-388_add_table_shipping_order.sql) задаёт `id uuid PRIMARY KEY` и `number SERIAL NOT NULL`. Java [`Order.number`](../../../db-layer/src/main/java/ru/korusconsulting/alis/model/order/Order.java) использует общий `@EntitySequence(ORDER)`, поэтому приложение подставляет номер до INSERT; `SERIAL` остаётся default только для прямого INSERT. `UNIQUE(number)` в цепочке не найден.

## DTO → service/JPA → физические колонки

Контракты: [`ShippingOrderCreationDto`](../dto/catalog/shippingorder/ShippingOrderCreationDto.md), [`ShippingOrderUpdateDto`](../dto/catalog/shippingorder/ShippingOrderUpdateDto.md) (= creation + `@NotNull id`), [`ShippingOrderDto`](../dto/catalog/shippingorder/ShippingOrderDto.md) и [`ShippingOrderDetailedDto`](../dto/catalog/shippingorder/ShippingOrderDetailedDto.md). HTTP — [`ShippingOrderController`](../../../web-layer/src/main/java/ru/korusconsulting/alis/controller/shippingorder/ShippingOrderController.java).

| Request / иное происхождение | Entity → SQL | Source-контракт и write semantics |
|---|---|---|
| Нет request `id`, `number`, audit | `id`, `number`, `createdAt/By`, `updatedAt/By` | `uuid PK`, `BIGINT NOT NULL` (первоначально SERIAL), create audit `NOT NULL`, update audit nullable. Заполняет приложение. Unique номера нет. |
| `client.id` — `@NotNull` | `client` → `client_id` | После [KIS-1397](../../../db-layer/src/main/resources/db/changelog/v.1.24.0/v1.24.0_KIS-1397_add-field-tables-legal_entity_id.sql) и [KIS-1623](../../../db-layer/src/main/resources/db/changelog/v.1.28.0/v.1.28.0_20250918_KIS-1623_RemoveClientTable_RenameLegalEntityTable.sql) (бывший `legal_entity_id`): `UUID NOT NULL`, FK `shipping_order_client_id_fkey` → `client(id)`; JPA `optional=false`, `updatable=false`. Update DTO содержит client, но service его не переносит. |
| `contract.id` — `@NotNull` | `contract` → `contract_id` | `UUID NOT NULL REFERENCES contract(id)`. Update ищет Contract по ID при изменении. Проверки принадлежности договора client заявки в корневом service/SQL нет. |
| `terminalArea` — `@NotNull` | `terminalArea` → `terminal_area_catalog_id` | [KIS-1422](../../../db-layer/src/main/resources/db/changelog/v.1.33.0/v.1.33.0_20251111_KIS-1422_edit_terminal_area_catalog_entity.sql): `UUID NOT NULL`, FK `fk_shipping_order_terminal_area_catalog`, backfill из старого `terminal_area` и удаление старой колонки. JPA `updatable=false`. Заявки площадки «центральный склад» перенесены на другую площадку миграцией [remove-central](../../../db-layer/src/main/resources/db/changelog/v.1.35.0/v.1.35.0_20260825_remove-central_remove_central_warehouse.sql) (`22355528`, 25.08.2026). |
| `transportType` — `@NotNull` | → `transport_type` | `VARCHAR(100) NOT NULL`, enum STRING, JPA `updatable=false`. `RAILWAY` допустим только для площадки `CONTAINER` (`OrderCombinationValidator`). |
| `orderStatus` — `@NotNull` | → `order_status` | `VARCHAR(100) NOT NULL`. На create присланное значение **игнорируется** → `DRAFT`; update его не копирует. Остальные writers — см. [статусы](#статус-и-побочные-эффекты). |
| `plannedShippingDateTime` — optional | → `planned_shipping_date_time` | `TIMESTAMP`; [KIS-703](../../../db-layer/src/main/resources/db/changelog/v.1.0.0/v1.0.0_20250311_KIS-703_drop_not_null_in_orders_tables.sql) снял `NOT NULL`. Update присваивает значение, включая `null`. |
| Datareon inbound, не DTO | `actualShippingDateTime` → `actual_shipping_date_time` | [KIS-147](../../../db-layer/src/main/resources/db/changelog/v.1.0.0/v1.0.0_20250218_KIS-147_add_vh_departure_action_inbound_event_config.sql): `TIMESTAMP NULL`. Единственный writer — [`VhDepartureAction`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/datareon/inbound/action/VhDepartureAction.java) (только площадка `WAREHOUSE`, `eventDateTime` события). |
| `currency.id` — optional | `currency` → `currency_id` | FK на `currency(id)`, `NOT NULL` снят KIS-703. При update ветка вызывает `updateModel.getCurrency().getId()`, если текущая валюта `null` или отличается от новой: передача `currency=null` (или повторное сохранение без валюты) приводит к `NullPointerException` до SQL. |
| `contact` — optional embedded | → `contact_name`, `contact_phone`, `contact_email` | После ALG-814 все nullable; phone `VARCHAR(50)` (ALG-511), name `VARCHAR(100)`, email `VARCHAR(255)`. Update заменяет contact только при `contact != null`; `null` не очищает. |
| `comment` — optional | → `comment` | `VARCHAR(512) NULL`; update присваивает напрямую (можно очистить). |
| `deliveryType` — optional | → `delivery_type` | [KIS-1135](../../../db-layer/src/main/resources/db/changelog/v.1.0.0/v1.0.0_20250606_KIS-1135_add_delivery_type_for_shipping_order.sql): `VARCHAR(64) NULL`. На create обязателен для склада (`WAREHOUSE`/`WAREHOUSE_428`) + `VEHICLE` и обнуляется для других сочетаний; update не переносит. SQL CHECK нет. |
| `needTransport` — optional | → `need_transport` | [KIS-1751](../../../db-layer/src/main/resources/db/changelog/v.1.29.0/v.1.29.0_20251008_KIS-1751_add_table_route.sql): `BOOLEAN NOT NULL DEFAULT false`. Пишется только на create; update не переносит; привязка к рейсу сбрасывает в `false`. |
| Нет в request (mapper `route` ignore) | `route` → `route_id` | KIS-1751: nullable FK `route(id)`; [KIS-2332](../../../db-layer/src/main/resources/db/changelog/v.1.31.0/v.1.31.0_20251224_KIS-2332_add_index_for_route_in_shipping_and_receiving_orders.sql) — индекс `idx_shipping_order_route_id`. Пишет только [`RouteService.assign/unassign`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/route/RouteService.java) (`POST`/`DELETE /routes/{id}/assign`). Для существовавших заявок с транспортом рейсы созданы backfill-миграцией [KIS-4093](../../../db-layer/src/main/resources/db/changelog/v.1.34.0/v.1.34.0_20260718_KIS-4093_backfill_order_transport_data.sql). |
| `consignee.id`; присланный `consigneeAddress` | → `consignee_id`, `consignee_address` | `consignee_id` добавлен как `shipper_id` без FK ([KIS-1873](../../../db-layer/src/main/resources/db/changelog/v.1.29.0/v.1.29.0_20251023_KIS-1873_add_new_fields_in_order_for_route.sql)) и переименован [KIS-3084](../../../db-layer/src/main/resources/db/changelog/v.1.33.0/v.1.33.0_20260204_KIS-3084_rename_column_shipper_to_consignee.sql); SQL FK нет. Service требует `isConsignee=true` и того же client, body-address игнорирует: сохраняет trimmed `ClientRelatedEntity.addressFact`; при отсутствии consignee очищает оба поля. [KIS-4248](../../../db-layer/src/main/resources/db/changelog/v.1.34.0/v.1.34.0_20260729_KIS-4248_expand_shipping_order_consignee_address.sql) — `VARCHAR(1000)`. KIS-4093 дозаполнил пустые значения из удалённой `shipping_order_transport`. |
| `fillingType` — optional | → `filling_type` | [KIS-3352](../../../db-layer/src/main/resources/db/changelog/v.1.33.0/v.1.33.0_20260303_KIS-3352_shipping_order_filling_type_and_qty_tables.sql): `VARCHAR(16) NOT NULL`, backfill `ALL`, CHECK; [KIS-4271](../../../db-layer/src/main/resources/db/changelog/v.1.34.0/v.1.34.0_20260716_KIS-4271_add_none_container_filling_type.sql) расширяет CHECK до `ALL/RAILWAY_CARRIAGE/CONTAINER/NONE/NONE_CONTAINER`. Java default и `@PrePersist` дают `ALL`; `NONE_CONTAINER` разрешён только `CONTAINER`+`VEHICLE`. Update не переносит. В `@Schema` `ShippingOrderDto` `allowableValues` не содержит `NONE_CONTAINER`. |
| Не в request | `ktkNumberUnknown` → `ktk_number_unknown` | [KIS-1970](../../../db-layer/src/main/resources/db/changelog/v.1.30.1/v.1.30.1_20251107_KIS-1970_add_column_ktk_number_unknown_on_receiving_order_and_shipping_order_and_removing_restrictions.sql): `BOOLEAN DEFAULT false` без `NOT NULL`; вычисляет `ShippingOrderContainerService.checkFlagKtkNumber` по дочерним КТК (только `CONTAINER`+`VEHICLE`). |

Колонка `document_confirmed` (KIS-1717) удалена в [v1.31](../../../db-layer/src/main/resources/db/changelog/v.1.31.0/v.1.31.0_20251202_KIS-1717_drop_column.sql); в entity и DTO вывоза поля нет (осталось только у поставки).

`PUT /shippingorder/{id}` не принимает `@PathVariable`: [`BaseService.update(updateDto)`](../../../wms-layer/src/main/java/ru/korusconsulting/wms/service/BaseService.java) ищет цель по `body.id`, сверки path/body нет (перегрузка `update(UUID, dto)` её умеет, но не используется). Update разрешён только в `DRAFT`/`ON_REVIEW` (`OrderServiceUtils.checkOrderStatusForUpdate`); для `ON_REVIEW` требуется право `RECEIVING_ORDER_SEND_TO_ACCEPT` — право **поставки**, а не вывоза.

## Обязательность: три разных слоя

| Поля | Create JSON / Bean Validation | SQL | Серверная логика |
|---|---|---|---|
| `orderStatus`, `client`, `contract`, `terminalArea`, `transportType` | `@NotNull` | `NOT NULL` | Статус заменяется на `DRAFT`; client/площадка/транспорт после create не меняются. |
| `currency`, `plannedShippingDateTime` | optional | nullable после KIS-703 | Допустимы в черновике, но [`ShippingOrderAcceptValidator`](../../../web-layer/src/main/java/ru/korusconsulting/alis/dto/shippingorder/validator/ShippingOrderAcceptValidator.java) требует оба при review/accept. |
| `deliveryType` | optional | nullable | Обязателен для склад+`VEHICLE`; иначе обнуляется. |
| `consignee` | optional | nullable, FK нет | Обязателен при review/accept для `CONTAINER`; при наличии проверяются роль и client. |
| `route` | нет в DTO | nullable FK | При review/accept для `WAREHOUSE`+`VEHICLE` обязателен (`ShippingOrder.MissingTransport`). |
| `fillingType` | optional | `NOT NULL` + CHECK | Null → `ALL`. |
| totals | нет в request | восемь `NOT NULL`, `total_weight` nullable | Java defaults и дочерние writers; SQL `DEFAULT` нет. |

«Можно сохранить черновик» не равно «можно отправить на review/accept». `@NotNull orderStatus` в create DTO не означает, что клиент выбирает начальный статус.

## Persisted totals и конкурирующие writers

[ALG-534](../../../db-layer/src/main/resources/db/changelog/v.1.0.0/v1.0.0_20240819_ALG-534_add_columns_for_shipping_order_preview.sql) добавил восемь агрегатов, [ALG-644](../../../db-layer/src/main/resources/db/changelog/v.1.0.0/v1.0.0_20240903_ALG-644_add_table_shipping_order_container.sql) — `total_container_quantity`. ALG-633 выполнил backfill нулями и `SET NOT NULL`; KIS-1970 снял `NOT NULL` только с `total_weight`. SQL `DEFAULT` нет; Java builder defaults действуют лишь на ORM-сущность. С `87ccc2682` шесть количественных totals преобразованы в BIGINT через ::BIGINT, соответствуют Java Long; вес и цены этой миграцией не меняются.

| Корневая колонка | Writer и формула |
|---|---|
| `total_sku_quantity`, `total_goods_price` | [`ShippingOrderGoodService`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/shippingordergood/ShippingOrderGoodService.java): distinct items и сумма `totalPrice`. |
| `total_weight`, `total_cargo_quantity`, pallet/not-pallet | [`ShippingOrderCargoService`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/shippingordercargo/ShippingOrderCargoService.java): полный пересчёт активных cargo. |
| `total_goods_price`, `total_weight` | [`ShippingOrderContainerItemService`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/shippingordercontainer/ShippingOrderContainerItemService.java): суммы item price/weight. |
| `total_container_quantity`, `total_weight` | [`ShippingOrderContainerService`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/shippingordercontainer/ShippingOrderContainerService.java): число строк КТК заявки и сумма их веса. |
| `total_container_quantity` | [`ShippingOrderContainerQtyService`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/shippingordercontainerqty/ShippingOrderContainerQtyService.java): сумма количеств безномерных строк. |
| `total_cargo_quantity` | [`ShippingOrderBlackboxService`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/shippingorderblackbox/ShippingOrderBlackboxService.java): `+1/-1` при direct create/delete. |
| `total_requested_service_quantity/price` | [`ShippingOrderRequestedServiceService`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/shippingorderrequestedservice/ShippingOrderRequestedServiceService.java): число активных строк и сумма цены без НДС. |

`total_weight`, `total_goods_price`, `total_cargo_quantity` и `total_container_quantity` имеют несколько writers в зависимости от варианта заявки; схема не фиксирует authoritative formula. Прямая вставка обязательных услуг в `postAdd` не пересчитывает service totals, поэтому сразу после create они могут быть нулевыми при существующих строках услуг.

## Статус и побочные эффекты

- HTTP-точки смены статуса: `PUT /shippingorder/{id}/reject` (право `SHIPPING_ORDER_REJECT`) и `POST /routes/{id}/change-status/accept` — рейс вызывает `ShippingOrderService.accept` для каждой своей заявки. `/shippingorder/{id}/review` и `/routes/{id}/change-status/review` удалены 21.09.2026 (`9a05f552`, KIS-4661); `ShippingOrderService.review` по HTTP сейчас недоступен (вызывается только из `RouteService.changeStatus`, который HTTP вызывает лишь с `ACCEPTED`).
- `review`, `accept`, `reject` блокируют строку `findAndLock`, проверяют матрицу [`OrderStatus`](../../../db-layer/src/main/java/ru/korusconsulting/alis/model/orderstatus/OrderStatus.java), валидируют агрегат (review — без проверки `ktkNumberUnknown`, accept — с ней) и обновляют корень в одной transaction.
- `accept` резервирует КТК (`ContainerStatusService.reserveForShippingOrder` → `container_owner.status=RESERVED_OUT`, `container_owner.shipping_order_id`) и, если для площадки не включён route chain package, вставляет строки outbound-интеграции. `reject` отменяет резерв (`cancelShippingOrder`; для заявок из `DRAFT`/`ON_REVIEW` регистр не меняется). При прежнем ACCEPTED и площадке CONTAINER в той же транзакции сохраняется payload отмены; IN_PROGRESS/DONE дополнительно требуют RejectAfterStart/DELETE и не создают этот пакет. [Контракт отмены](../integrations/order-cancellation-outbound-as-is.md).
- [`ShippingOrderDaoService.postUpdatePublishEvent`](../../../db-layer/src/main/java/ru/korusconsulting/alis/service/shippingorder/ShippingOrderDaoService.java) сравнивает transient `previousStatus` (`@PostLoad`) со статусом после update и публикует `ShippingOrderStatusChangedEvent` (с nullable `routeId`).
- Inbound: [`CarriageArrivedAction`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/datareon/inbound/action/CarriageArrivedAction.java) и `StatusInWorkResultAction` пишут `IN_PROGRESS`; [`TosShipmentResultAction`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/datareon/inbound/action/TosShipmentResultAction.java) и `StatusCompletedResultAction` — `DONE`; `VhDepartureAction` — `actual_shipping_date_time`. Это не common update DTO.
- Soft-delete у корня нет, DELETE endpoint нет. Дочерние FK без `ON DELETE CASCADE`, включая `container_owner.shipping_order_id` ([KIS-4661](../../../db-layer/src/main/resources/db/changelog/v.1.35.0/v.1.35.0_20260915_KIS-4661_add_container_owner_status.sql)).

## Ограничения и индексы

| Вид | Что подтверждено |
|---|---|
| PK | `shipping_order(id)`. |
| FK (исходящие) | `client_id`, `contract_id`, `currency_id`, `terminal_area_catalog_id`, `route_id`. Для `consignee_id` FK нет. |
| FK (входящие) | Дочерние таблицы `shipping_order_*` и `container_owner.shipping_order_id` (индекс `container_owner_shipping_order_id_idx`). |
| CHECK | Только `chk_shipping_order_filling_type` (пять значений). Для status, transport/delivery type, totals и дат CHECK нет. |
| UNIQUE | Нет. |
| Индексы | `idx_shipping_order_route_id` и PK; на остальные FK индексов нет. |
| Defaults | `number SERIAL`, `need_transport=false`, `ktk_number_unknown=false`. `filling_type` и totals — backfill, не `DEFAULT`. |

## Миграции и влияющие commits

| Изменение | Commit |
|---|---|
| Первичная таблица и preview totals | `11de1385` |
| Actual shipping datetime | `f2734e15` |
| Nullable currency/planned datetime | `c4e6bf2c` |
| Delivery type | `80b4dbb0` |
| `legal_entity_id` → `client_id` | `a90b9076` |
| Route FK/default и индекс | `bc3b0253`, `e58cd9ab` |
| Consignee rename | `52d3c091` |
| TerminalArea catalog | `78cd428f` / `ec84d091` |
| Filling type/check | `d29256da`, `3a283b5a` |
| Derived consignee address / length 1000 | `fa27bf56` |
| Удаление `shipping_order_transport`, backfill consignee/route | `d30d77ad` (KIS-4093, 24.09.2026) |
| Удаление площадки «центральный склад» | `22355528` |
| `container_owner.shipping_order_id`, удаление `/review` | `9a05f552` (KIS-4661) |

## Что подтверждают tests, но не их запуск

- [`ShippingOrderServiceIntegrationTest`](../../../web-layer/src/integrationTest/java/ru/korusconsulting/alis/service/shippingorder/ShippingOrderServiceIntegrationTest.java): create с обязательными услугами, derived consignee address, create без currency/planned datetime и отказ accept для него, review, reject вне рейса, partial/full copy с проверкой totals.
- [`ShippingOrderServiceTest`](../../../web-layer/src/test/java/ru/korusconsulting/alis/service/shippingorder/ShippingOrderServiceTest.java): derived consignee address, чужой client, отсутствие роли consignee.
- [`ShippingOrderAcceptValidatorTest`](../../../web-layer/src/test/java/ru/korusconsulting/alis/dto/shippingorder/validator/ShippingOrderAcceptValidatorTest.java): часть комбинаций и отсутствующих дочерних данных.

Тесты не запускались; их наличие не подтверждает applied schema и HTTP routing.

## Неподтверждённое и вопросы для ТЗ

1. `OPEN_QUESTION` [ОКРУЖЕНИЕ] Не проверены `DATABASECHANGELOG`, `pg_catalog`, реальные defaults/indexes/FK, дубли номера.
2. `OPEN_QUESTION` [АНАЛИТИК] Path ID в `PUT /shippingorder/{id}` не сверяется с body ID — должен ли path быть authoritative?
3. `OPEN_QUESTION` [АНАЛИТИК] Update с `currency=null` падает NPE; `contact=null` не очищает; `deliveryType`, `fillingType`, `needTransport`, `client` есть в update DTO, но не переносятся — нужен явный перечень изменяемых полей.
4. `OPEN_QUESTION` [АНАЛИТИК] FK `consignee_id → client_related_entity(id)` отсутствует в миграциях — нужен ли.
5. `OPEN_QUESTION` [АНАЛИТИК] Authoritative writer для `total_weight`, `total_goods_price`, `total_cargo_quantity`, `total_container_quantity` и момент учёта обязательных услуг в totals.
6. `OPEN_QUESTION` [АНАЛИТИК] Зачем `orderStatus` обязателен в create DTO, если сервер всегда сохраняет `DRAFT`.
7. ~~Endpoint для `accept` не найден~~ — закрыто: accept вызывается через `POST /routes/{id}/change-status/accept`. Новый вопрос `OPEN_QUESTION` [АНАЛИТИК]: `review` после KIS-4661 недоступен по HTTP ни для заявки, ни для рейса — это намеренно (статус `ON_REVIEW` для вывоза больше не используется)?
8. `OPEN_QUESTION` [АНАЛИТИК] Редактирование заявки вывоза в `ON_REVIEW` проверяет право `RECEIVING_ORDER_SEND_TO_ACCEPT` (право поставки) — дефект или общее право.
9. `OPEN_QUESTION` [АНАЛИТИК] `copyOrder` обращается к `shippingOrder.getContact().getName()` без null-проверки: копирование заявки без контакта (все три колонки `NULL` → embedded `null`) предположительно падает NPE (`INFERENCE`, тест не найден).
10. Перед требованием физического удаления нужна полная карта дочерних FK и `ON DELETE` по applied schema.

## Чек-лист изменения корня

1. Разделить draft-save обязательность, review/accept обязательность и SQL `NOT NULL`.
2. Для update явно перечислить изменяемые поля и проверить path ID против body ID.
3. Для нового enum/value обновить Java enum, DTO/OpenAPI `@Schema` и SQL CHECK одновременно.
4. Для consignee проверять роль, client ownership, snapshot-address и физический FK как разные гарантии.
5. Для нового writer totals определить вариант заявки, формулу, transaction и полный пересчёт после create/update/delete/copy/import.
6. Для смены статуса проверить lock, переход, validator, резерв КТК (`container_owner`), outbound inserts и route status event.
7. Для удаления/перепривязки проверить все child FK, включая `container_owner`.

## Связанные документы

- [Правила вывоза](../business-rules/shipping-orders.md)
- [Валидация заявок](../business-rules/order-validation.md)
- [API заявок](../api/order-api.md)
- [Общая модель заявок](orders.md)
- [JPA-паспорт ShippingOrder](../entities/catalog/entities/shippingorder/ShippingOrder.md)
- [Бывшая `shipping_order_transport`](shipping-order-transport-as-is.md)

## Сверка числовых типов 11.11.2026

Текущие number корня и sequence — BIGINT; количественные totals также BIGINT после 87ccc2682. DEFAULT/NULL и UNIQUE номера этим ALTER TYPE не добавляются. Полная цепочка и зависимые views — [реестр миграций](schema-changes-2026-09-11.md).
