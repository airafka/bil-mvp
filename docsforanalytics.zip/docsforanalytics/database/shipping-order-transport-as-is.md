# `shipping_order_transport`: транспорт заявки на вывоз, физическая модель AS-IS (часть 17) — DEPRECATED

> **Сверено:** backend `3d3899d5d` (13.11.2026) · **Основание:** `SOURCE_CONFIRMED` — миграции KIS-4093 и текущий код (таблицы и кода транспорта нет); исторические разделы — по истории git до `d30d77ad`; БД и стенд не проверялись.

> **DEPRECATED.** Таблица `shipping_order_transport`, сущность `ShippingOrderTransport`, её controller/mapper/service/DTO, endpoint'ы `POST/PUT /shippingordertransport/*`, permission path `ShippingOrder.ShippingOrderTransport` и `entity_info` удалены коммитом `d30d77ad` (KIS-4093, 24.09.2026) миграцией [`KIS-4093_remove_order_transport`](../../../db-layer/src/main/resources/db/changelog/v.1.34.0/v.1.34.0_20260718_KIS-4093_remove_order_transport.sql). В текущем backend нет ни одной ссылки на `ShippingOrderTransport`/`SHIPPING_ORDER_TRANSPORT` вне changelog. Для новых ТЗ этот документ не использовать — см. раздел «Где теперь живут поля».

## Где теперь живут поля

| Бывшая колонка `shipping_order_transport` | Где сейчас | Кто пишет |
|---|---|---|
| `id` (shared PK/FK на заявку) | Отдельной строки нет; связь заявка → транспорт = `shipping_order.route_id` → `route` | [`RouteService.assign/unassign`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/route/RouteService.java) (`POST`/`DELETE /routes/{id}/assign`) |
| `consignee_id`, `consignee_address` | `shipping_order.consignee_id`, `shipping_order.consignee_address` | `ShippingOrderService` (роль/client проверяются, адрес = `addressFact` грузополучателя) — см. [корень](shipping-order-root-as-is.md) |
| `carrier_id` | `route.client_related_entity_id` (`Route.clientRelatedEntity`) | API рейса |
| `client_vehicle_id` | `route.client_vehicle_id` | API рейса |
| `client_driver_id` | `route.client_driver_id` | API рейса |
| audit | `route.created_*/updated_*` (для backfill — из transport) | — |

Модель и правила рейса: [жизненный цикл рейса](../business-rules/route-lifecycle-as-is.md), [JPA-паспорт `Route`](../entities/catalog/entities/route/Route.md). В ответе `ShippingOrderDetailedDto` водитель и машина берутся из `route` (`ShippingOrderMapper.toDetailedDto`: `route.clientDriver`, `route.clientVehicle`). Валидатор accept для `WAREHOUSE`+`VEHICLE` теперь требует `shipping_order.route_id` (`ShippingOrder.MissingTransport`), а не строку transport. Исходящий `TRANSPORT_MANIFEST` ([`ShippingTransportManifestExportService`](../../../web-layer/src/main/java/ru/korusconsulting/alis/datareon/service/shipping/transportmanifest/ShippingTransportManifestExportService.java)) берёт перевозчика/машину/водителя из `shippingOrder.getRoute()`, грузополучателя — из корня.

## Как мигрированы данные (KIS-4093)

[`KIS-4093_backfill_order_transport_data`](../../../db-layer/src/main/resources/db/changelog/v.1.34.0/v.1.34.0_20260718_KIS-4093_backfill_order_transport_data.sql), затем `remove_order_transport`:

1. `shipping_order.consignee_id/consignee_address` = `COALESCE(значение корня, значение transport)` — значение корня приоритетно; transport-значение использовано только там, где корень был пуст.
2. Для заявок с transport и **без** `route_id` создан новый `route` (`route_type='SHIPPING'`, `status` = статус заявки, `data_time` = `COALESCE(planned_shipping_date_time, transport.created_at, order.created_at)`, площадка и тип транспорта — из заявки, carrier/driver/vehicle — из transport), и заявка к нему привязана. Для заявок, уже имевших `route_id`, carrier/driver/vehicle из transport **не переносились** (остались данные рейса).
3. `outbound_data.entity_type='SHIPPING_ORDER_TRANSPORT'` переписан в `'SHIPPING_ORDER'`.
4. Удалены `role_permission`/`permission_path` для `ShippingOrder.ShippingOrderTransport`, `entity_info` `ShippingOrderTransport`, затем `DROP TABLE shipping_order_transport`.

## Историческая структура таблицы (до 24.09.2026)

[ALG-393](../../../db-layer/src/main/resources/db/changelog/v.1.0.0/v1.0.0_20240807_ALG-393_add_table_shipping_order_transport.sql): `id UUID PK REFERENCES shipping_order(id)` (shared key, 0..1 строка на заявку), `consignee_id`/`carrier_id` → `client_related_entity(id)`, `client_vehicle_id` → `client_vehicle(id)`, `client_driver_id` → `client_driver(id)` (все `NOT NULL`), `consignee_address VARCHAR(512)` (`NOT NULL` снят [KIS-2441](../../../db-layer/src/main/resources/db/changelog/v.1.33.0/v.1.33.0_20260115_KIS-2441_remove_not_null_consignee_address.sql)), audit. Текстовые snapshot-колонки машины/водителя (`vehicle_code`, `driver_code` и др.) удалены [KIS-1106](../../../db-layer/src/main/resources/db/changelog/v.1.23.0/v.1.23.0_20250723_KIS-1106_remove_driver_and_vehicle_info_from_order_transport.sql). CHECK/UNIQUE/индексов кроме PK не было.

### Создание: bidirectional shared-key crutch

Историческое: `ShippingOrderTransportService.prepareModelToAdd` связывал transport и root через общий ID и явно вызывал `update(shippingOrder)` («crutch», `dd22741c`, KIS-928) из-за bidirectional `@OneToOne` с общим PK. С KIS-4093 неактуально: связи заявка–транспорт нет, есть `route_id`.

## Дублирующийся грузополучатель: root и transport — разные правила

Историческое: до KIS-4093 `consignee_id/consignee_address` существовали и в `shipping_order`, и в `shipping_order_transport`; transport-версия писалась без проверки роли/клиента и с адресом из тела запроса, но не читалась ни одним потребителем (TN-отчёт, рейс, manifest брали корень). **Закрыто KIS-4093:** поле одно — в `shipping_order`, правила — в [корне](shipping-order-root-as-is.md).

## Outbound: transport становится «мёртвым» отдельным writer-ом

Историческое: строки `SHIPPING_ORDER_TRANSPORT` в [`OutboundConfigService`](../../../web-layer/src/main/java/ru/korusconsulting/alis/config/outbound/OutboundConfigService.java) были закомментированы, сервис transport outbound не создавал; при `accept` корня `SHIPMENT_TRANSPORT_MANIFEST` подтягивал transport как sibling-строку. **Сейчас:** активна только `addConfig(EntityType.SHIPPING_ORDER, MessageType.SHIPMENT_TRANSPORT_MANIFEST)`; `ShippingOrderService.getListOfEntitiesToOutbound` для этого типа добавляет сам корень (если `VEHICLE` и есть `route`) и активные ж/д вагоны заявки.

## Проверка статуса при update: разделяемая (и потенциально неточная) проверка

[`OrderServiceUtils.checkOrderStatusForUpdate`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/OrderServiceUtils.java) разрешает update только в `DRAFT`/`ON_REVIEW`, а для `ON_REVIEW` проверяет право `RECEIVING_ORDER_SEND_TO_ACCEPT` — и для заявок вывоза. Дефект остаётся актуальным для корня и дочерних сервисов вывоза (transport-путь удалён); см. [корень](shipping-order-root-as-is.md#неподтверждённое-и-вопросы-для-тз).

## Неподтверждённое и вопросы для ТЗ

1. ~~Дублирование `consignee` между root и transport~~ — закрыто KIS-4093 (поле только в `shipping_order`).
2. ~~Path/body ID на `PUT /shippingordertransport/{id}`~~, ~~судьба закомментированных outbound-веток transport~~, ~~повторная выгрузка manifest после update transport~~ — неактуально: endpoint и сервис удалены.
3. `OPEN_QUESTION` [АНАЛИТИК] `checkOrderStatusForUpdate` проверяет право поставки для вывоза — перенесено в [корень](shipping-order-root-as-is.md#неподтверждённое-и-вопросы-для-тз).
4. `OPEN_QUESTION` [ОКРУЖЕНИЕ] Для заявок, у которых до KIS-4093 уже был `route_id`, перевозчик/машина/водитель из transport отброшены миграцией. Нужно ли сверить на проде, не было ли расхождений transport vs route до миграции.
5. `OPEN_QUESTION` [ОКРУЖЕНИЕ] Применение KIS-4093 на средах (`DATABASECHANGELOG`) не проверялось.

## Связанные документы

- [Корень заявки на вывоз](shipping-order-root-as-is.md)
- [Жизненный цикл рейса](../business-rules/route-lifecycle-as-is.md)
- [Правила вывоза](../business-rules/shipping-orders.md)
- [Валидация заявок](../business-rules/order-validation.md)
- [Транспорт заявки на поставку (тоже удалён KIS-4093)](receiving-order-transport-as-is.md)
- [API заявок](../api/order-api.md)

## Уточнение текущей модели транспорта 11.11.2026

Авто manifest теперь использует корневую заявку и её Route (carrier/clientVehicle/clientDriver), а ЖД — дочерние вагонные задачи. Root DTO больше не назначает route как обычное редактируемое поле заявки; назначение/снятие идёт операциями рейса. Backfill создаёт Route только для заявок без него и с прежним transport; при уже существующем route данные не переносятся в него автоматически. [Полный порядок backfill](receiving-order-transport-as-is.md).

MХ-1 получает Waybill из ReceivingOrder.waybill; M-7/packing-list и ТН перестают читать удалённую transport-таблицу. Java/Jasper и SQL не запускались; endpoint-удаление и схема подтверждены исходниками, применённость на окружении — нет.
