# Движения КТК: основная запись и meta-представление

Срез 3d3899d5d, 11.11.2026; AS_IS / SOURCE_CONFIRMED. Главный коммит b9d7c085b. Исходники SQL/DAO/predicate просмотрены, runtime и Java-тесты не запускались.

## Почему у движения две модели чтения

ContainerMovement — одна запись движения. orderNumber/orderStatus вычисляются @Formula из shipping_order для LOAD_FINISH либо receiving_order для UNLOAD_FINISH. Meta view не заменяет основную таблицу: она разворачивает code/name-поля для фильтров и сортировки.

container_movement_meta_view — UNION ALL двух веток с inner join соответствующей заявки по order_id и event_code. Ветка shipping использует ShippingOrderContainer/Item, receiving — только прямые ReceivingOrderContainer/Item. WaybillContainer/Product в этой SQL-view не участвуют. ЕТСНГ присоединяется LEFT JOIN, поэтому движение без items может иметь NULL ETSNG, а с несколькими items — несколько rows с одним id/movement_id.

Следовательно, объявленный JPA @Id во view не доказывает уникальности результата SQL. Использовать её как универсальный список движений без учёта размножения нельзя. Иные event_code или отсутствующая связанная заявка в эту view не попадают.

## Page и сортировка

ContainerMovementDaoService.getPage читает основную ContainerMovement с её predicate, offset/limit и count, а не возвращает все строки meta view. Специальная сортировка:

| Alias | SQL/JPA expression |
|---|---|
| client / client.code / clientcode | MIN(client_code) meta rows данного movement |
| etsngcodes / etsngcode | MIN при ASC, MAX при DESC |
| order / order.number / ordernumber | Formula orderNumber |
| orderstatus | Formula orderStatus |

У специальной сортировки NULLS FIRST для ASC и NULLS LAST для DESC. Прочие поля передаются общему order-specifier. Это не лексикографическая сортировка всего массива ЕТСНГ и не гарантия стабильного tie-break по id, если его нет в запросе.

## Различие predicates

Основной predicate использует фильтры client/ETSNG через существование связанной receiving/shipping заявки и direct items; тип/номер транспорта, event/date, number/status и active проверяются отдельно. Meta predicate применяет поддержанные части фильтра к колонкам view: container/client/ETSNG — ID/наборы/коды, event/type/date/number/status и active. Это отдельная реализация, не автоматическая передача всех полей вложенного ClientFilter/ContainerFilter.

При active-фильтре meta дополнительно проверяет сумму (+1 для active=true, -1 иначе) по documentId>0 и выбирает максимальный eventDateTime активной строки по containerId/documentId. Это сложнее простого active=true. Повторные rows из items участвуют в агрегате view; влияние на баланс и равенство времён требует runtime-теста. Значение documentId=NULL также требует проверки SQL-null семантики.

Входной filter имеет active=true по умолчанию. Сброс/передача другого SearchBoolean меняет условия; нельзя трактовать это как физическое удаление/восстановление движения. Неполный client predicate и отсутствие Waybill-ветки могут давать разные наборы ЕТСНГ в detail и meta: [поиск ЖД-ЕТСНГ](../business-rules/backend-behavior-changes-oct-nov-2026.md) описывает отдельный mapper path.

## Открытые проверки

Требуются сравнение page/meta/detail на одном наборе с несколькими items, client isolation, NULL documentId/status и одинаковые timestamps, ЖД-поставка с товарами только в Waybill, explain/indexes и стабильность пагинации. Здесь это source-level риски, не воспроизведённые дефекты. Бизнес-статус/владелец ContainerOwner не является значением active у ContainerMovement.

## Источники

- [view_container_movement_meta.sql](../../../db-layer/src/main/resources/db/changelog/rerunnable/view_container_movement_meta.sql)
- [ContainerMovement.java](../../../db-layer/src/main/java/ru/korusconsulting/alis/model/containermovement/ContainerMovement.java)
- [ContainerMovementMetaView.java](../../../db-layer/src/main/java/ru/korusconsulting/alis/model/containermovement/ContainerMovementMetaView.java)
- [ContainerMovementDaoService.java](../../../db-layer/src/main/java/ru/korusconsulting/alis/service/containermovement/ContainerMovementDaoService.java)
- [ContainerMovementPredicate.java](../../../db-layer/src/main/java/ru/korusconsulting/alis/predicate/containermovement/ContainerMovementPredicate.java)
- [ContainerMovementMetaViewPredicate.java](../../../db-layer/src/main/java/ru/korusconsulting/alis/predicate/containermovement/ContainerMovementMetaViewPredicate.java)
