# Физическая модель outbound_data

Срез backend `3d3899d5d`, 11.11.2026; `AS_IS / SOURCE_CONFIRMED` по цепочке SQL и JPA. Применённая БД не проверялась. Таблица хранит очередь/журнал исходящих сообщений, включая [снимок отмены заявки](../integrations/order-cancellation-outbound-as-is.md).

| Колонка | SQL-тип по миграциям | NULL | DEFAULT | Назначение |
|---|---|---|---|---|
| id | uuid, PK | нет | нет | UUID строки |
| root_object_id | uuid | нет | нет | ID предметного объекта; исходный FK на outbound_config удалён |
| message_type | varchar(255) | нет | нет | Имя MessageType |
| entity_type | varchar(100) | нет | нет | Имя EntityType |
| created_at | timestamp without time zone | нет | нет | Аудит создания |
| created_by | varchar(50) | нет | нет | Автор создания |
| updated_at | timestamp without time zone | да | нет | Аудит изменения |
| updated_by | varchar(50) | да | нет | Автор изменения |
| success | boolean | да | нет | null — нет результата, false — ошибка, true — успех |
| message_id | uuid | да | нет | UUID из тела ответа Datareon |
| response_code | integer | да | нет | Код ответа, записываемый при успешной обработке |
| error_message | text | да | нет | Текст ошибки |
| attempts | integer | нет | 0 | Счётчик вызовов updateAttempt, включая успешную обработку; при ошибке postExport может увеличиться дважды за одну отправку |
| last_attempt_at | timestamp | да | нет | Время последней попытки |
| payload | text | да | нет | Сериализованный JSON снимка отмены; не универсальная гарантия хранения тела каждого исходящего сообщения |

`payload` добавлен ALTER TABLE без NOT NULL, DEFAULT или backfill. Старые строки остаются с NULL; для обычных сообщений наличие payload не требуется этой моделью. Cancellation exporter требует непустой корректный JSON. JPA задаёт String с columnDefinition="text"; публичный OutboundDataDto payload не раскрывает.

Уточнение 13.11.2026: `BaseExportService` вызывает `updateAttempt` перед `postExport` в успешной ветке и снова в `catch Throwable`. После успешного HTTP и ошибки postExport это два увеличения в одной итерации; итог сохранения зависит также от состояния транзакции. Поэтому attempts нельзя безусловно приравнивать к числу физических HTTP-запросов. [Движок экспорта](../business-rules/route-chain-package-export-as-is.md#общий-движок-baseexportservice--outbounddata).

Первичная миграция создала root_object_id с FK на outbound_config; миграция 20240816 удаляет FK. Поэтому полиморфная ссылка на предметный объект не защищена этим FK. В найденных миграциях outbound_data нет дополнительных UNIQUE/CHECK или явных вторичных индексов; PK подразумевает индекс первичного ключа PostgreSQL. Это вывод по исходникам, не по live schema.

## Эволюция схемы

- [v1.0.0_20240719_ALG-345_create_tables_outbound_config_and_outbound_data.sql](../../../db-layer/src/main/resources/db/changelog/v.1.0.0/v1.0.0_20240719_ALG-345_create_tables_outbound_config_and_outbound_data.sql)
- [v1.0.0_20240816_ALG-328_alter_table_outbound_data.sql](../../../db-layer/src/main/resources/db/changelog/v.1.0.0/v1.0.0_20240816_ALG-328_alter_table_outbound_data.sql)
- [v1.0.0_20240830_ALG-643_insert_item_outbound_config.sql](../../../db-layer/src/main/resources/db/changelog/v.1.0.0/v1.0.0_20240830_ALG-643_insert_item_outbound_config.sql)
- [v1.0.0_20250505_KIS-1059_alter_table_outbound_data.sql](../../../db-layer/src/main/resources/db/changelog/v.1.0.0/v1.0.0_20250505_KIS-1059_alter_table_outbound_data.sql)
- [v.1.35.0_20260929_align_outbound_data_attempts_with_integer.sql](../../../db-layer/src/main/resources/db/changelog/v.1.35.0/v.1.35.0_20260929_align_outbound_data_attempts_with_integer.sql)
- [v.1.35.0_20261021_order_cancel_payload.sql](../../../db-layer/src/main/resources/db/changelog/v.1.35.0/v.1.35.0_20261021_order_cancel_payload.sql)
- [cumulative.yml](../../../db-layer/src/main/resources/db/changelog/v.1.35.0/cumulative.yml)

В 20250505 добавлены attempts SMALLINT NOT NULL DEFAULT 0 и last_attempt_at; уже неуспешным строкам выставлены attempts=5 и now(). В 20260929 attempts преобразован в INTEGER с сохранением прежних ограничений/default. В 20261021 добавлен payload; файл подключён в cumulative v.1.35.0. Миграции переименования типов сообщений/сущностей меняют данные, а не структуру колонок.
