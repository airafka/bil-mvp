# `receiving_order_container_item`: содержимое КТК поставки, физическая модель AS-IS (часть 6)

> **Сверено:** backend `3d3899d5d` (12.11.2026) · **Основание:** `SOURCE_CONFIRMED` — исходный код, миграции и тесты (тесты не запускались); БД и стенд не проверялись.

Это **source-level реконструкция** (controller/request DTO/mapper/service/JPA, Liquibase, test sources), а не осмотр применённой БД. С прошлой сверки (`22fac945`) схема и расчёты не менялись; удалён upsert-endpoint (`4696ed25`), mapper переведён на `MapStructConfig` (KIS-4604). Parent КТК и отдельные его FK/weight описаны в [модели `receiving_order_container`](receiving-order-container-as-is.md); stored root totals и competing writers — в [модели `receiving_order`](receiving-order-root-as-is.md). Здесь поля одной item-строки не смешиваются с parent container или WaybillProduct.

## HTTP → DTO → service

[`ReceivingOrderContainerItemController`](../../../web-layer/src/main/java/ru/korusconsulting/alis/controller/receivingordercontainer/ReceivingOrderContainerItemController.java) объявляет `POST /receivingordercontaineritem/`, `PUT /receivingordercontaineritem/{id}`, `DELETE /receivingordercontaineritem/{id}` и read-пути (`/all` без `@Secure`, `/page`, `/{id}`, meta); create/write/delete имеют source-level `@Secure` `ReceivingOrder.ReceivingOrderContainerItem`. Upsert-with-delete `POST /receivingordercontaineritem/{receivingOrderId}` удалён 09.09.2026 (`4696ed25`). Deployed mappings/roles не проверены. [`CreationDto`](../dto/catalog/receivingordercontainer/ReceivingOrderContainerItemCreationDto.md) требует `receivingOrder.id`, `receivingOrderContainer.id` (`@NotNull @Valid`, [`IdDto.id`](../../../wms-layer/src/main/java/ru/korusconsulting/wms/dto/IdDto.java) тоже `@NotNull`) и `wightGross BigDecimal @NotNull`. `etsngCode`, `description`, `price`, `wightNet`, `quantityPlace` optional. Для денежных и количественных полей **нет** Bean Validation `@Positive/@PositiveOrZero`, precision/scale, проверки `wightNet ≤ wightGross` или связи price×quantity; SQL CHECK такого сочетания тоже не найден. [`UpdateDto`](../dto/catalog/receivingordercontainer/ReceivingOrderContainerItemUpdateDto.md) наследует поля и добавляет UUID `id` **без `@NotNull`**.

[`ReceivingOrderContainerItemMapper.modelCreation`](../../../web-layer/src/main/java/ru/korusconsulting/alis/mapper/receivingordercontainer/ReceivingOrderContainerItemMapper.java) задаёт новый UUID и `deleted=false`; generated MapStruct/SQL INSERT не инспектировались. [`ReceivingOrderContainerItemService.preAdd`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/receivingordercontainer/ReceivingOrderContainerItemService.java) загружает указанную заявку и проверяет status/permission strategy; `prepareModelToAdd` отдельно загружает root, parent Container row и optional ETСНГ. **Не найден** server check, что `receivingOrderContainer.receivingOrder.id == request receivingOrder.id`; SQL имеет два отдельных FK, не composite consistency constraint. Поэтому cross-parent insert по существующим ID может пройти FK source validation, а пересчёты ниже затем используют разные root/parent IDs. Реальный исход требует прямого HTTP/DB теста.

`PUT /{id}` handler не объявляет `@PathVariable id` и вызывает [`BaseService.update(updateDto)`](../../../wms-layer/src/main/java/ru/korusconsulting/wms/service/BaseService.java): target ищется по **body `UpdateDto.id`**, URL ID не сверяется. `preUpdate` проверяет статус **existing root**. `prepareModelToUpdate` может заменить `receivingOrderContainer` по ID, но **не** перепривязывает existing `receivingOrder` из request DTO; отдельно копирует описание, цену, массы и число мест. При переносе item между контейнерами post-update пересчитывает **только новый parent** (`existingModel.receivingOrderContainer.id` уже заменён); старый parent weight по этому source path не обновляется. Если parent имеет `container=null` (неизвестный номер КТК), parent-weight calculation разыменовывает `orderContainer.getContainer().getWeight()` без null guard и может завершиться до сохранения всех пересчётов. SQL/HTTP runtime и rollback не проверены.

## SQL/JPA колонки и миграции

[`ReceivingOrderContainerItem`](../entities/catalog/entities/receivingordercontainer/ReceivingOrderContainerItem.md) наследует audit-поля `BaseEditable`, имеет собственный UUID PK, три `@ManyToOne` references и soft-delete. Initial [`ALG-576 CREATE`](../../../db-layer/src/main/resources/db/changelog/v.1.0.0/v1.0.0_20240822_ALG-576_add_table_receiving_order_container_item.sql) и later source changes дают:

| Поле / источник | SQL source contract на текущем checkout | Реализация/история |
|---|---|---|
| `id`, `deleted`, audit | `id UUID PRIMARY KEY NOT NULL`; `deleted BOOLEAN NOT NULL DEFAULT false`; `created_at/by NOT NULL`, `updated_at/by NULL` | Mapper создаёт UUID/false; `Deletable` и [`BaseService.remove`](../../../wms-layer/src/main/java/ru/korusconsulting/wms/service/BaseService.java) делают soft-delete. Audit не приходит из request. |
| `receivingOrder.id` | `receiving_order_id UUID NOT NULL REFERENCES receiving_order(id)` | Request required; update существующую ссылку не меняет. Не гарантирует совпадение с parent container order. |
| `receivingOrderContainer.id` | `receiving_order_container_id UUID NOT NULL REFERENCES receiving_order_container(id)` | Request required; update может перенести item на другой parent. Нет source FK/UNIQUE связи с `receiving_order_id`. |
| `etsngCode.id` | `etsng_code_id UUID NULL REFERENCES etsng_code(id)` | Initial ALG-576 NOT NULL; [`KIS-2906`](../../../db-layer/src/main/resources/db/changelog/v.1.33.0/v.1.33.0_20260205_KIS-2906_remove_not_null_constrains_for_etsng_code.sql) снял. Service делает optional DAO lookup и при update умеет очистить null. |
| `description` | `description VARCHAR(1000) NULL` | Initial NOT NULL; [`KIS-282`](../../../db-layer/src/main/resources/db/changelog/v.1.0.0/v1.0.0_20250306_KIS-282_drop_not_null.sql) снял. DTO не ограничивает длину; SQL conversion/error mapping не проверялись. |
| `price` | `price NUMERIC(15,2) NULL` | Initial NOT NULL; [`KIS-2003`](../../../db-layer/src/main/resources/db/changelog/v.1.30.1/v.1.30.1_20251112_KIS-2003_refactoring_excel_template.sql) снял. Service агрегирует price как значение строки, не как price×quantityPlace. |
| `wightGross` | `wight_gross NUMERIC(15,3) NOT NULL DEFAULT 0` | KIS-2003 добавил колонку, унаследовано ошибочное написание `wight`, не `weight`. DTO `@NotNull`, JPA builder default0, SQL default0 для INSERT без явного значения — три разные границы; отрицательное значение DTO/SQL не запрещают. |
| `wightNet`, `quantityPlace` | `wight_net`, `quantity_place NUMERIC(15,3) NULL` | KIS-2003 добавил; service сохраняет напрямую, но не использует их для root/parent gross и не проверяет диапазон. |

По просмотренным source SQL references к item таблице **нет** отдельного active-row UNIQUE, CHECK (`wight_net ≤ wight_gross`, положительность, parent/root match) или non-PK index; PostgreSQL PK создаёт свой индекс, но фактический набор constraints/indexes/defaults и applied migrations требуют `pg_catalog`/`DATABASECHANGELOG`. FK на ETСНГ optional не заменяет описания груза в Waybill. [`KIS-3631 migration`](../../../db-layer/src/main/resources/db/changelog/v.1.34.0/v.1.34.0_20260330_KIS-3631_migrate_receiving_order_data_to_waybill.sql) копировал active item `etsng_code_id`/`description` в WaybillProduct; `price`, `wightGross/Net`, `quantityPlace` этим SQL не переносились в одноимённые product-поля. Текущая item таблица не была удалена этим changeset.

## Порядок persisted calculations и конфликт источников

После add [`ReceivingOrderContainerItemService.postAdd`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/receivingordercontainer/ReceivingOrderContainerItemService.java) вызывает **сначала root**, затем **parent** calculation; update post-functions и soft remove используют тот же порядок. Это две сохранённые записи через DAO внутри вызываемого service flow:

1. Root `receiving_order.total_goods_price = sum(price)` и `total_weight = sum(wightGross)` по **всем active item-строкам с `item.receiving_order_id` данной заявки**; null price/gross игнорируются, сумма начинается с нуля. Root weight **не включает tare** контейнера.
2. Parent `receiving_order_container.weight = parent.container.weight + sum(wightGross)` по **active item-строкам данного parent ID** (`ReceivingOrderContainerItemFilter.byOrderContainer`). Это gross КТК с тарой. Для parent `container=null` этот method не имеет защиты.

Таким образом, cross-parent row может попасть в root totals одной заявки и parent weight другой, потому что два расчёта фильтруют **разные FK**. При parent transfer старый parent остаётся со старым weight до другого write/backfill. К тому же [`ReceivingOrderGoodService`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/receivingordergood/ReceivingOrderGoodService.java) записывает **тот же** root `total_goods_price` как сумму `ReceivingOrderGood.totalPrice`, а [`ReceivingOrderContainerService`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/receivingordercontainer/ReceivingOrderContainerService.java) записывает **тот же** `total_weight` как сумму gross parent weights. Следовательно, последний пересчитавший сервис определяет stored root value в данном operation sequence; единое source-level authoritative правило для всех сценариев не установлено. Detailed order response может ещё переопределить totalWeight по WaybillProduct, см. [корень](receiving-order-root-as-is.md).

```mermaid
flowchart TD
    D[Item DTO: root ID, parent ID, price, wightGross/Net, places] --> M[Mapper: new UUID]
    M --> S[Item service: root status, reference lookups, row save]
    S --> I[(receiving_order_container_item)]
    I --> R[Filter active items by item.receiving_order_id]
    R --> RT[(receiving_order.total_goods_price and total_weight)]
    I --> P[Filter active items by parent ID]
    P --> PT[(receiving_order_container.weight: tare plus gross items)]
    G[ReceivingOrderGoodService] --> RT
    C[ReceivingOrderContainerService] --> RT
```

[`ReceivingOrderContainerItemServiceIntegrationTest`](../../../web-layer/src/integrationTest/java/ru/korusconsulting/alis/service/receivingordercontainer/ReceivingOrderContainerItemServiceIntegrationTest.java) source проверяет **только root goods price** после add/update/remove; root/parent weight, cross-parent ID, parent transfer, unknown parent null, negative quantity и path/body mismatch здесь не проверены. [`ReceivingOrderContainerItemListServiceTest`](../../../web-layer/src/test/java/ru/korusconsulting/alis/service/receivingordercontainer/ReceivingOrderContainerItemListServiceTest.java) проверяет grouping/list Waybill enrichment, не физические constraints. Тесты **не запускались**. Influencing commits: `11de1385` (initial table, 2024-08), `13918fb6` (nullable description, 2025-03), `3ea221c0` (weights/places/nullable price, 2025-11), `4b733baf` (nullable ETСНГ, 2026-02), `4696ed25` (удаление upsert endpoint, 2026-09); история файлов не равна applied DB audit.

## Целевая сверка бизнес-изменений 11.11.2026

Поиск ЕТСНГ движения UNLOAD_FINISH разделён по транспорту; у ЖД-ветки требуется проверка отсутствующего scope заявки. [Алгоритм](../business-rules/backend-behavior-changes-oct-nov-2026.md).
