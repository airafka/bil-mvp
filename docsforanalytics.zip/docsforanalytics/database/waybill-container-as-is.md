# `waybill_container`: КТК в накладной, физическая модель AS-IS (часть 11)

> **Сверено:** backend `3d3899d5d` (12.11.2026) · **Основание:** `SOURCE_CONFIRMED` — исходный код, миграции и тесты (тесты не запускались); БД и стенд не проверялись.

Это **source-level модель** (controller/service/JPA, integration handlers, Liquibase, test sources), а не снимок применённой БД. С прошлой сверки (`22fac945`) добавлены колонка `owner_container_id` → `client` и endpoint назначения владельцев (KIS-4716), статус КТК в регистре (KIS-4661); импорт больше не перезаписывает глобальный Container (KIS-4664); `grouped_waybill` удалён (KIS-4690). Родительский вагон описан в [физической модели `waybill_railway_carriage`](waybill-railway-carriage-as-is.md), корень — в [физической модели `waybill`](waybill-root-as-is.md), источник товарных весов — в [физической модели `waybill_product`](waybill-product-as-is.md).

## Граница данных: глобальный КТК, snapshot накладной и операционный владелец

[`WaybillContainer`](../../../db-layer/src/main/java/ru/korusconsulting/alis/model/waybillcontainer/WaybillContainer.java) — участие физического КТК в конкретном вагоне конкретной накладной. Это не тот же объект, что глобальный [`Container`](../entities/catalog/entities/container/Container.md), и не запись текущего операционного владельца.

| Уровень | Основные данные | Кто меняет |
|---|---|---|
| `container` | уникальный номер `code`, тип, ISO-тип, тара `weight`, грузоподъёмность, размер и другие глобальные характеристики | Waybill importer делает find-or-create по номеру; с 03.09.2026 (`1c97f92d`, KIS-4664) существующий Container **не изменяется**; есть отдельный CRUD/справочные потоки. |
| `waybill_container` | WRC, строковый `owner`, `length`, gross `weight`, `net_weight`, номера подачи/отправки | Snapshot первого импорта накладной; обычного update API нет. |
| `waybill_container.owner_container_id` | выбранный собственник КТК (`Client`) для этой поставки | С 22.09.2026 (KIS-4716): подставляется `receiving_order.default_container_owner_id` при link/bulk-привязке накладной (только пустым), задаётся Excel-шаблоном из строки КТК заявки и вручную через `PUT /receivingorder/{receivingOrderId}/waybill-containers/owners`. Источник владельца для регистра при accept/приёмке. |
| `container_owner` | текущий Client-владелец физического Container, статус (`EXPECTED`/`ON_TERMINAL`/`RESERVED_OUT`/`DEPARTED`) и история | `ContainerStatusService`: accept поставки ставит `EXPECTED` с владельцем из `owner_container_id` (WC) / `owner_container_id_new` (ROC); приёмка (`TOS_RECEIVING_RESULT`) — `ON_TERMINAL`, сохраняя уже записанного владельца. Подробно — [остатки и владелец КТК](../business-rules/container-remains-and-owner-as-is.md). |
| `waybill_container.status` | `UPLOADED`, `FINISHED`, потенциально `CANCELED`, либо `NULL` | ALIS outbound и TOS inbound. |

В требованиях нельзя использовать `WaybillContainer.owner`, `WaybillContainer.ownerContainer`, `Container.owner` и `ContainerOwner.client` как взаимозаменяемые поля: первое — строковый snapshot ЭТРАН, второе — выбранный в ALIS собственник для поставки, третье — строка глобального справочника, четвёртое — операционный регистр.

## SQL-контракт `waybill_container`

Initial table создана migration [`KIS-2273`](../../../db-layer/src/main/resources/db/changelog/v.1.33.0/v.1.33.0_20260127_KIS-2273_add_waybill_tables.sql); v1.34 добавила gross weight, status и net weight.

| Java-поле | SQL source | Обязательность / ограничение | Семантика |
|---|---|---|---|
| `id` | `UUID PRIMARY KEY` | NOT NULL через PK | UUID entity lifecycle. |
| `waybillRailwayCarriage` | `waybill_railway_carriage_id UUID` | `NOT NULL REFERENCES waybill_railway_carriage ON DELETE CASCADE` | Родительское участие вагона. |
| `container` | `container_id UUID` | `NOT NULL REFERENCES container(id)`; `ON DELETE` не задан | Глобальный физический КТК. |
| `supplyRequestNumber`, `sendingRequestNumber` | nullable `INTEGER` | Нет CHECK | Номера заявки из ЭТРАН. |
| `owner` | nullable `VARCHAR` | Нет FK/CHECK | Строковый snapshot собственника. |
| `ownerContainer` | `owner_container_id UUID` | nullable, `REFERENCES client(id)` ([KIS-4716](../../../db-layer/src/main/resources/db/changelog/v.1.35.0/v.1.35.0_20260921_KIS-4716_add_owner_client_columns.sql)) | Выбранный собственник КТК; существующие строки при миграции не заполнялись (`NULL`). JPA `@ManyToOne(LAZY)`. |
| `length` | nullable `NUMERIC(16,3)` | Нет CHECK | Длина из накладной. |
| `weight` | nullable `NUMERIC(15,3)` | Нет CHECK | Gross weight `weight_gross`, записывается as-is. Не путать с `container.weight` — тарой. |
| `netWeight` | nullable `NUMERIC(16,3)` | `CHECK (net_weight > 0)` | Net weight snapshot. Ноль и отрицательное значение отклонит БД, DTO/service это заранее не проверяют. |
| `excluded` | `BOOLEAN NOT NULL DEFAULT FALSE` | С 10.11.2026 | Исключение вагонов/КТК основной при досылке; scoped reads/counts/exports учитывают флаг, но не каждый прямой DAO read. |
| `status` | nullable `VARCHAR` | Нет DEFAULT/CHECK | При создании null, затем enum name. |
| audit | `created_at TIMESTAMP NOT NULL DEFAULT ...`, `created_by VARCHAR(50) NOT NULL` | Только create audit | Entity наследует `BaseCreatable`, update audit отсутствует даже при изменении status. |

В просмотренной migration chain нет явных индексов по обоим FK и нет `UNIQUE(waybill_railway_carriage_id, container_id)`. Поэтому один физический КТК можно повторить внутри WRC или нескольких WRC одной поставки. Repository возвращает `Optional` по паре WRC+Container и по паре ReceivingOrder+Container; при дублях такие single-result запросы способны завершиться ошибкой множественного результата.

## Создание и справочный upsert

### Datareon / ЭТРАН

При первом `waybill_identifier` [`WaybillDatareonService`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/datareon/WaybillDatareonService.java):

1. находит WRC по `carriage_number` среди только что построенных строк; при повторном номере берётся первая;
2. находит глобальный Container по `container_number`; существующий **не изменяется** (до 03.09.2026 перезаписывались грузоподъёмность, тара, тип и ISO-тип); новый создаётся с ISO-типом по identifier и типом из входа;
3. создаёт WaybillContainer со snapshot-полями (`owner_container_id` не заполняется);
4. отдельным проходом привязывает каждое ЗПУ к первой строке с тем же номером Container.

Грузоподъёмность нового Container сохраняется как пришла (умножение на 1000 удалено 03.09.2026), тара — из входного `weight`, gross snapshot — из `weight_gross` без преобразования. Единицы не закреплены SQL constraint.

Повтор не заменяет Container/WC/ЗПУ, но с 10.11.2026 обновляет root/status, связи и товары; обработка досылочной исключает КТК совпавших вагонов основной через excluded=true. Внутри первого payload нет проверки duplicate pair. `waybill_container` и `waybill_zpu` списки обрабатываются через `.stream()` без нормализации null; nested Bean Validation из root controller не каскадирует, поэтому фактические ошибки могут быть NPE/parse/not-found, а не единым validation response.

### Railway Excel

[`ReceivingOrderRailwayCarriageParser`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/parsing/order/parser/impl/ReceivingOrderRailwayCarriageParser.java) берёт уже созданный `ReceivingOrderContainer.container`, ищет WC по WRC+Container и при отсутствии создаёт две обязательные ссылки и `owner_container_id` = владелец строки `ReceivingOrderContainer`. Snapshot-поля и status остаются null; ЗПУ в этот Waybill path не создаются. Find-then-insert не защищён DB UNIQUE/lock.

### Legacy migration

[`KIS-3631 data migration`](../../../db-layer/src/main/resources/db/changelog/v.1.34.0/v.1.34.0_20260330_KIS-3631_migrate_receiving_order_data_to_waybill.sql) переносит только active `receiving_order_container` с известным Container, вагоном и накладной. В WC записываются ссылки и create audit; `empty`, customs clearance, danger class и остальные snapshot-поля теряются. `seal_numbers` разворачиваются отдельными строками `waybill_zpu`; пустые значения пропускаются. `NOT EXISTS` используется только внутри миграции и не создаёт постоянную уникальность.

## `waybill_zpu`

[`WaybillZpu`](../entities/catalog/entities/waybillzpu/WaybillZpu.md) хранит обязательный FK на WC, nullable SQL `zpu`, nullable `zpu_type` и create audit. FK имеет `ON DELETE CASCADE`; есть индекс только по `waybill_container_id`. Уникальности `(waybill_container_id, zpu)` и проверки непустого номера нет, поэтому inbound способен сохранить null/дубли, хотя legacy migration их фильтрует.

JPA-коллекция `WaybillContainer.zpu` загружается `EAGER`, но cascade/orphan removal на entity не заданы. Добавление выполняется отдельным DAO после сохранения WC; удаление вместе с WC обеспечивает именно FK БД.

## Status lifecycle и TOS

Найденные writers:

- успешный экспорт receiving railway route chain package ставит всем WRC и WC всех поставок рейса `UPLOADED`;
- `CARRIAGE_ARRIVED`, если `taskId` оказался WC, ставит ему `FINISHED` и может установить первое фактическое время, но не закрывает заявку;
- `TOS_RECEIVING_RESULT` по WC ставит `FINISHED`, обновляет услуги/движения и переводит ReceivingOrder в `DONE`, только если объединённый непустой список WC+ReceivingOrderContainer целиком имеет `FINISHED` и статусный переход разрешён;
- при переводе в `DONE` вызывается `ContainerStatusService.markReceived`: регистр `container_owner` получает `ON_TERMINAL`; клиент существующей записи сохраняется (выставлен ещё при accept из `owner_container_id`), новая запись получает владельца из WC/ROC. До 21.09.2026 (KIS-4661) здесь `ContainerOwnerService` переводил КТК на клиента заявки.

Accept поставки (`ContainerStatusService.reserveForReceivingOrder`) требует для каждого КТК заявки (WC и ROC с известным Container) заполненного собственника и одинакового собственника, если КТК встречается в нескольких строках; иначе accept отклоняется («Не заполнен собственник КТК» / «Для КТК указаны разные собственники»).

TOS передаёт `qty`, но у WaybillContainer нет `actualQuantity`: handler только логирует значение и теряет его. Integration test явно закрепляет текущее отсутствие поля.

Status transition map для WC отсутствует: route export без проверки способен записать `UPLOADED` поверх другого значения, а inbound — `FINISHED`; optimistic version/update audit нет. Фактический порядок обычно задаётся процессом, но БД и service не предотвращают регрессию или last-write-wins race.

## Read API, DTO и вычисляемые поля

[`WaybillContainerController`](../../../web-layer/src/main/java/ru/korusconsulting/alis/controller/waybillcontainer/WaybillContainerController.java) публикует только page и meta endpoints с `Permission.WAYBILL`; create/update/get/delete маршрутов нет. Единственный write-endpoint — `PUT /receivingorder/{receivingOrderId}/waybill-containers/owners` ([`ReceivingOrderController`](../../../web-layer/src/main/java/ru/korusconsulting/alis/controller/receivingorder/ReceivingOrderController.java), `RECEIVING_ORDER` WRITE) со списком [`WaybillContainerOwnerUpdateDto`](../../../web-layer/src/main/java/ru/korusconsulting/alis/dto/waybillcontainer/WaybillContainerOwnerUpdateDto.java) `{id @NotNull, ownerContainer: IdDto|null}`: [`WaybillContainerService.setOwners`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/waybillcontainer/WaybillContainerService.java) проверяет статус заявки (`DRAFT`/`ON_REVIEW`, иначе 403), уникальность ID (иначе `IllegalArgumentException` — в `ExceptionAdvice` отдельного обработчика нет, т.е. HTTP 500), принадлежность WC накладным этой заявки (иначе 404), загружает Client по ID; `null` очищает владельца. Проверки «владелец связан с клиентом заявки» нет.

| Ответ | Поля и источники | Ограничения |
|---|---|---|
| [`WaybillContainerDto`](../dto/catalog/waybillcontainer/WaybillContainerDto.md) | id/create audit, полный глобальный `ContainerDto`, snapshot owner, ЗПУ как id+code | Не отдаёт WRC, length, supply/sending numbers, gross/net weight и status. |
| [`WaybillContainerViewDto`](../dto/catalog/waybill/WaybillContainerViewDto.md) через `POST /receivingorder/{id}/waybill-containers/page` | global number/type/tare/lifting capacity; WC gross/owner/status; `ownerContainer` (`IdCodeDto`) и `containerStatus` из регистра (KIS-4661/4716); ЗПУ; ETSNG products Waybill | `netWeight` берётся **не из `wc.netWeight`**, а как сумма `WaybillProduct.netWeight` всей накладной и повторяется для каждого её КТК. `zpuType` — только первый non-null тип, хотя номеров может быть несколько. |
| Legacy carriage preview | global Container, WC gross и ETSNG | Net weight также сумма products всей Waybill; null gross заменяется нулём. |

`WaybillContainerFilter.deleted=false` не действует: WC не реализует soft-delete, а predicate не использует поле. Основной predicate поддерживает global/snapshot/status/ЗПУ/search и (с KIS-4716) `ownerContainer` по Client. Поле `etsngCode` удалено из generic `WaybillContainerFilter`. `container_count` в `waybill_view` (как раньше в `grouped_waybill`) считает физические строки WC при `wc.excluded=false` и `wrc.excluded=false`, включая допустимые схемой дубли среди этих строк.

## Удаление и каскады

Прямого HTTP DELETE WC нет. Физическое удаление WRC либо Waybill каскадно удаляет WC, затем `waybill_zpu`; глобальный Container, ContainerOwner и ReceivingOrderContainer автоматически не удаляются. Особый post-remove cleanup ReceivingOrderContainer выполняется сервисом только при compatibility DELETE WRC и имеет описанный в [части 10](waybill-railway-carriage-as-is.md#удаление-и-каскады) риск порядка flush/subquery. Удаление Waybill и прямой DAO remove такого callback не гарантируют.

```mermaid
flowchart TD
    I[Datareon first Waybill import] --> G[Find or create global Container, existing unchanged]
    L[Link/bulk or owners API or Excel] -->|owner_container_id| W
    I --> W[(waybill_container snapshot)]
    G -->|NOT NULL FK| W
    R[(waybill_railway_carriage)] -->|NOT NULL, ON DELETE CASCADE| W
    W --> Z[(waybill_zpu)]
    E[Railway route package export] -->|UPLOADED| W
    A[CARRIAGE_ARRIVED or TOS_RECEIVING_RESULT] -->|FINISHED| W
    A --> Q[TOS qty logged but not persisted]
    A --> D{All WC plus ROC FINISHED?}
    D -->|Yes and transition allowed| O[ReceivingOrder DONE and container_owner ON_TERMINAL]
    X[Delete Waybill or WRC] -->|DB cascade| W
    W -->|DB cascade| Z
```

## Проверки, пробелы и история

`WaybillDatareonServiceIntegrationTest` проверяет создание одной WC только по количеству. Inbound integration tests проверяют `FINISHED`, незавершение заявки при второй незавершённой WC, услуги и movement; Статусы регистра покрыты `ContainerStatusServiceIntegrationTest` (KIS-4661), смена владельца — `ContainerOwnerServiceIntegrationTest`. Не найдены прямые tests для SQL net-weight CHECK, duplicate pair/single-result, WC/ZPU cascade, read mapper с `wc.netWeight`, status regression, null inbound lists, Excel snapshot loss и `setOwners` (дубли ID, чужой WC, статус заявки). Тесты в этом подэтапе **не запускались**.

Основные повлиявшие commits: `feb37a42` (initial Waybill/WC/ZPU schema и import, 2026-02-13), `ce939d57`/`443ae69a` (KIS-3631 migration/status/read compatibility, 2026-03/04), `c4c21382` и `9460879a` (net weight/entity и receiving integration, 2026-04), `00629653` (TOS update fix, 2026-05), `0ee0d12d` (global container ID в grouped response, 2026-05), `cd8ab542` (scoped meta/filtering, 2026-08), `1c97f92d` (KIS-4664: импорт не перезаписывает Container, 2026-09), `9a05f552` (KIS-4661: статусы регистра, 2026-09), `3bcf0113` (KIS-4716: `owner_container_id`, owners API, 2026-09). История Git не подтверждает применённую схему или deployed порядок событий.

## Уточнение целевой сверки 11.11.2026

С 10.11.2026 добавлена excluded BOOLEAN NOT NULL DEFAULT FALSE; запросы по поставке проверяют excluded контейнера и вагона. [Миграция и исключения](../business-rules/waybill-supplementary-as-is.md).
