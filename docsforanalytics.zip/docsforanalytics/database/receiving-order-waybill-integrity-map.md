# ReceivingOrder ↔ Waybill: сводная физическая карта AS-IS (часть 15)

> **Сверено:** backend `3d3899d5d` (12.11.2026) · **Основание:** `SOURCE_CONFIRMED` — исходный код, миграции и тесты (тесты не запускались); БД и стенд не проверялись.

Сводка по детальным физическим моделям частей 1–14. Это **source-level карта для проверки ТЗ**, а не снимок применённой БД. Она не заменяет паспорта таблиц: здесь сведены направления FK, уникальность, удаление, write ownership и места, где база не обеспечивает предметную целостность.

## Охват и исправление инвентаризации

Контур содержит `receiving_order`, **14 связанных физических таблиц**, включая `waybill_connection_type`, и одну обычную read-view `waybill_view`. До 24.09.2026 в контур входила 14-я таблица `receiving_order_transport` (удалена KIS-4093, поля перенесены в корень и `route`), до 14.09.2026 вместо `waybill_view` была materialized `grouped_waybill` (KIS-4690). `waybill_container` и `waybill_zpu` — две физические таблицы одного документа части 11.

| Часть | Объект | Детальная модель |
|---|---|---|
| 1 | `receiving_order` | [корень поставки](receiving-order-root-as-is.md) |
| 2 | ~~`receiving_order_transport`~~ (удалена 24.09.2026) | [история, DEPRECATED](receiving-order-transport-as-is.md) |
| 3 | `receiving_order_good` | [товарная строка](receiving-order-good-as-is.md) |
| 4 | `receiving_order_cargo` | [грузовое место](receiving-order-cargo-as-is.md) |
| 5 | `receiving_order_container` | [КТК поставки](receiving-order-container-as-is.md) |
| 6 | `receiving_order_container_item` | [содержимое КТК](receiving-order-container-item-as-is.md) |
| 7 | `receiving_order_requested_service` | [дополнительная услуга](receiving-order-requested-service-as-is.md) |
| 8 | `receiving_order_blackbox` | [груз без товарной детализации](receiving-order-blackbox-as-is.md) |
| 9 | `waybill` | [корень накладной](waybill-root-as-is.md) |
| 10 | `waybill_railway_carriage` | [вагон накладной](waybill-railway-carriage-as-is.md) |
| 11 | `waybill_container`, `waybill_zpu` | [КТК и ЗПУ накладной](waybill-container-as-is.md) |
| 12 | `waybill_product` | [груз накладной](waybill-product-as-is.md) |
| 13 | `waybill_special_mark`, `waybill_tariff_mark` | [отметки накладной](waybill-marks-as-is.md) |
| Справочник связи | `waybill_connection_type` | [45/47, parent и excluded](../business-rules/waybill-supplementary-as-is.md) |
| 14 | `waybill_view` (до 14.09.2026 — ~~`grouped_waybill`~~) | [текущий паспорт](waybill-view-as-is.md); [история materialized-модели](grouped-waybill-as-is.md) |

## ER-карта физического владения

```mermaid
erDiagram
    RECEIVING_ORDER ||--o{ RECEIVING_ORDER_GOOD : "receiving_order_id"
    RECEIVING_ORDER ||--o{ RECEIVING_ORDER_CARGO : "receiving_order_id"
    RECEIVING_ORDER_GOOD ||--o{ RECEIVING_ORDER_CARGO : "receiving_order_good_id"
    RECEIVING_ORDER ||--o{ RECEIVING_ORDER_CONTAINER : "receiving_order_id"
    RECEIVING_ORDER ||--o{ RECEIVING_ORDER_CONTAINER_ITEM : "receiving_order_id"
    RECEIVING_ORDER_CONTAINER ||--o{ RECEIVING_ORDER_CONTAINER_ITEM : "receiving_order_container_id"
    RECEIVING_ORDER ||--o{ RECEIVING_ORDER_REQUESTED_SERVICE : "receiving_order_id"
    RECEIVING_ORDER ||--o{ RECEIVING_ORDER_BLACKBOX : "receiving_order_id"
    RECEIVING_ORDER o|--o{ WAYBILL : "nullable receiving_order_id"
    WAYBILL ||--o{ WAYBILL_RAILWAY_CARRIAGE : "ON DELETE CASCADE"
    WAYBILL_RAILWAY_CARRIAGE ||--o{ WAYBILL_CONTAINER : "ON DELETE CASCADE"
    WAYBILL_CONTAINER ||--o{ WAYBILL_ZPU : "ON DELETE CASCADE"
    WAYBILL ||--o{ WAYBILL_PRODUCT : "ON DELETE CASCADE"
    WAYBILL ||--o{ WAYBILL_SPECIAL_MARK : "ON DELETE CASCADE"
    WAYBILL ||--o{ WAYBILL_TARIFF_MARK : "ON DELETE CASCADE"
    CLIENT ||--o{ RECEIVING_ORDER : "default_container_owner_id"
    CLIENT o|--o{ RECEIVING_ORDER_CONTAINER : "owner_container_id"
    CLIENT o|--o{ WAYBILL_CONTAINER : "owner_container_id"
    WAYBILL o|--o{ WAYBILL : "nullable waybill_parent_id"
    WAYBILL_CONNECTION_TYPE o|--o{ WAYBILL : "nullable connection type FK"
    WAYBILL ||--|| WAYBILL_VIEW : "plain view, one row per waybill"
```

`receiving_order_cargo` и `receiving_order_container_item` намеренно показаны с двумя parent-ссылками: SQL гарантирует существование каждого ID отдельно, но не совпадение их корневой заявки. `waybill_view` — обычная view без хранения: строка на каждую `waybill` (фильтр `MIGRATED` — в Java predicate). Собственники КТК (KIS-4716) — FK на `client`, без связи с клиентом заявки.

## Матрица ключей и ограничений

| Physical object | Parent/reference key | Доказанная уникальность | Soft-delete | Physical delete / cascade |
|---|---|---|---|---|
| `receiving_order` | UUID PK; client/contract/terminal area и другие FK | `id`; `number` source-level не UNIQUE | Нет | Публичная операция физического удаления не описана; children с default FK мешают delete |
| `receiving_order_good` | root, ClientGood, nullable Batch | Только UUID PK; root+good+batch не UNIQUE | Да | FK без cascade; soft row сохраняет ссылки |
| `receiving_order_cargo` | root + Good + nullable global Cargo/package | Только UUID PK; root и Good не образуют composite guard | Да | FK без cascade; JPA `@OneToOne` root не подтверждён SQL UNIQUE |
| `receiving_order_container` | root + nullable global Container и справочники | Только UUID PK; прежний root+container UNIQUE удалён | Да | FK без cascade; удаление service дополнительно soft-delete items |
| `receiving_order_container_item` | root + parent Container + nullable ETSNG | Только UUID PK; parent/root match и active duplicate не защищены | Да | FK без cascade; row может ссылаться на parent другой заявки |
| `receiving_order_requested_service` | root + TermOfRequestedService | Только UUID PK; root+term не UNIQUE | Да | FK без cascade; system-managed row тоже физически остаётся после soft-delete |
| `receiving_order_blackbox` | root + global Cargo | Только UUID PK; root+cargo не UNIQUE | Да (`deleted` SQL nullable) | FK без cascade; nullable deleted row выпадает из `deleted=false` |
| `waybill_connection_type` | UUID PK, INTEGER code, name | code UNIQUE | Нет | FK из waybill без cascade |
| `waybill` | nullable root; stations/payer; identifier; nullable parent и connection type | `waybill_identifier INTEGER UNIQUE`; number и receiving link не UNIQUE | Нет | Root delete operation не опубликована; linked Waybill FK может блокировать physical ReceivingOrder delete |
| `waybill_railway_carriage` | Waybill + global RailwayCarriage | Только UUID PK; Waybill+carriage не UNIQUE | Нет | Delete Waybill каскадирует WRC; delete WRC каскадирует WC/ZPU |
| `waybill_container` | WRC + global Container | Только UUID PK; WRC+container не UNIQUE | Нет | `ON DELETE CASCADE` только от WRC; global Container FK без cascade |
| `waybill_zpu` | WaybillContainer | Только UUID PK; parent+zpu не UNIQUE | Нет | `ON DELETE CASCADE` от WC |
| `waybill_product` | Waybill + ETSNG + nullable DangerProduct | Только UUID PK; содержательная строка не UNIQUE | Нет | `ON DELETE CASCADE` от Waybill; справочные FK без cascade |
| `waybill_special_mark` | Waybill | Только UUID PK; mark/info не UNIQUE и могут быть null | Нет | `ON DELETE CASCADE` от Waybill |
| `waybill_tariff_mark` | Waybill | Только UUID PK; code/name/note не UNIQUE и могут быть null | Нет | `ON DELETE CASCADE` от Waybill |

Вывод для ТЗ: кроме `waybill_identifier` и уникального кода типа связи, почти все предметные «не должно быть дубля» правила существуют только в service-коде либо отсутствуют. Проверка `find-then-insert` без DB UNIQUE не защищает от конкурентных дублей.

## Два параллельных контейнерных контура

`ReceivingOrderContainer` и `WaybillContainer` — не одна таблица и не parent/child:

| Контур | Physical path | Что хранит |
|---|---|---|
| Legacy/операционный ReceivingOrder | `receiving_order → receiving_order_container → receiving_order_container_item` | Выбранный/неизвестный КТК, массив ЗПУ, товарные строки, цены/веса, soft-delete, TOS actual |
| ЭТРАН/ЖД Waybill | `receiving_order ← waybill → WRC → WC → ZPU` | Накладная, физический вагон/КТК, snapshot, task status, отдельные пломбы; physical delete |

После KIS-3631 у `receiving_order_container` нет прямого FK на вагон. Сопоставление двух контуров выполняется прикладным чтением через общий глобальный `Container.id` и цепочку Waybill, а не constraint. Поэтому нельзя выводить принадлежность ReceivingOrderContainer конкретной WRC только из physical receiving row.

Legacy migration копировала часть старых receiving railway/container/item данных в Waybill tables, но исходные receiving container/item таблицы не удалены. Поля переносятся неполно: например, item price/weights/places не становятся одноимёнными WaybillProduct values.

## Владельцы записи и конкурирующие write paths

| Объект/поля | Основные writers AS-IS | Особенности |
|---|---|---|
| `receiving_order` business fields/status | ReceivingOrderService, lifecycle endpoints, inbound actions, route operations | Часть полей immutable в JPA/service; status меняется отдельными actions, не generic update |
| root stored totals | Good, Cargo, Container, ContainerItem, RequestedService, Blackbox services; отдельные migrations/actions | Одни и те же totals имеют разные формулы и могут зависеть от последнего writer |
| Good | Direct/list services; WMS пишет actual quantity | List self-call transaction boundary не подтверждена |
| Cargo | Direct service; auto-create из Good; copy | Пересчитывает часть root totals и cargo-place services |
| ReceivingOrderContainer | Direct service, Excel parser, copy; TOS actual/status | Direct service и Excel используют разные validation/total paths |
| ContainerItem | Direct/list service, Excel/parser paths | Одновременно меняет parent gross и root goods price/weight по другой формуле |
| RequestedService | Direct service, required DAO insert при root create, cargo/container auto-reprice, WMS/TOS actual | Required/auto paths не всегда пересчитывают root stored totals |
| Blackbox | Direct/list service, copy, Excel DAO | Direct меняет counter, Excel его не меняет; repeated delete способен повторить decrement |
| Waybill root/children | Datareon first create; Excel parser и KIS-3631 migration для части модели | Datareon repeat обновляет status/type/связи/category и частично upsert-ит товары; вагонный/контейнерный состав не заменяет; sync досылки ставит excluded у основной |
| Waybill task statuses | Route/manifest exporters, `CARRIAGE_ARRIVED`, TOS receiving | WRC/WC status lifecycle не является soft-delete |
| ReceivingOrder ↔ Waybill link | Single relink/unlink и bulk replacement endpoints/migration | Проверяет DRAFT/ON_REVIEW текущей заявки; bulk не проверяет статус прежней заявки и client ownership, неизвестные Waybill IDs пропускает |

## Aggregate authority: одного источника нет

```mermaid
flowchart LR
    G[ReceivingOrderGood] -->|distinct item; sum totalPrice| R[(ReceivingOrder stored totals)]
    C[ReceivingOrderCargo] -->|row counts; sum cargo weight| R
    RC[ReceivingOrderContainer] -->|container count; sum parent gross| R
    I[ContainerItem] -->|sum item price; gross without tare| R
    S[RequestedService] -->|active count; sum price without VAT| R
    B[Blackbox direct] -->|increment or decrement cargo count| R
    EX[Blackbox Excel] -. inserts rows without counter update .-> R
    W[WaybillProduct live read] -->|overrides detailed totalWeight| D[ReceivingOrderDetailedDto]
    R --> D
    WV[waybill_view live rows with parent overlay] --> GD[StationPair / Payer / Date / Waybill hierarchy]
    WL[Live products and excluded counts] --> GD
```

Критические значения для требований нужно называть полностью:

- `receiving_order.total_weight` — stored колонка с несколькими writers;
- `ReceivingOrderDetailedDto.totalWeight` — может быть заново вычислен по `WaybillProduct.weight`;
- `receiving_order_container.weight` — gross parent = tare + item gross в item path;
- `waybill_container.weight/net_weight` — отдельный snapshot, не те же колонки;
- `waybill_view.container_count` — число физических WC rows при excluded=false у WC и WRC, не stored root `total_container_quantity`;
- `total_goods_price` — Good path суммирует `good.totalPrice`, Item path суммирует `item.price`.

Без указания endpoint/event, physical column и момента чтения формулировка «общий вес/количество/стоимость заявки» неоднозначна.

## Удаление и каскады

Большинство mutable receiving-коллекций (`Good`, `Cargo`, `Container`, `ContainerItem`, `RequestedService`, `Blackbox`) используют soft-delete, но их FK физически остаются; таблица `receiving_order_transport` удалена, её прежняя shared-PK модель историческая. В просмотренных CREATE/ALTER для этих parent links `ON DELETE CASCADE` не задан, поэтому physical delete корня/справочника обычно должен встретить FK NO ACTION, пока ссылки не удалены физически. Исторический JPA cascade shared transport не описывает текущую схему.

Waybill-side children, напротив, физические и образуют cascade tree:

`waybill → WRC → WC → ZPU`, а также `waybill → Product/SpecialMark/TariffMark`.

Удаление WRC не удаляет Waybill или глобальный RailwayCarriage, но удаляет его WC/ZPU. Compatibility cleanup затем пытается soft-delete matching ReceivingOrderContainer; результат зависит от ORM flush order и не подтверждён integration test. Удаление глобальных RailwayCarriage/Container/ETSNG/DangerProduct при существующих FK не каскадируется.

## Что база не проверяет за сервис

- Contract, ClientGood, Batch, Cargo, Container и справочники не обязательно принадлежат клиенту/договору заявки только потому, что их FK существуют.
- `receiving_order_cargo.receiving_order_id` может не совпадать с root товарной строки.
- `receiving_order_container_item.receiving_order_id` может не совпадать с root parent container.
- Одна physical Waybill может быть связана только с одной ReceivingOrder, но bulk API способен перепривязать её без проверки прежнего owner/status.
- Duplicate Good/Cargo/Container/Item/Service/Blackbox и WRC/WC/ZPU/Product/marks rows в большинстве случаев допускаются схемой.
- Числовые формулы, положительность, net≤gross, сумма цен и единицы измерения в основном не закреплены CHECK constraints.
- Soft-deleted receiving rows продолжают занимать ID/FK и могут участвовать в нестандартных direct-ID/read/join paths.
- Обычная waybill_view читает актуальные committed таблицы; два запроса страницы не гарантируют общий снимок при любой изоляции. Refresh-модель grouped_waybill удалена.

## Чек-лист проверки будущего ТЗ

1. Назвать authoritative physical table/column и response DTO, а не только бизнес-термин.
2. Указать writer: HTTP endpoint, Excel, Datareon action, migration или автоматический пересчёт.
3. Разделить create, update, repeat/idempotency и concurrent create.
4. Проверить parent ownership не только отдельными FK, но и composite business consistency.
5. Явно решить, нужен DB UNIQUE/CHECK/index или достаточно service validation.
6. Указать soft-delete либо physical delete и требуемый cascade для каждого child.
7. Для totals определить формулу, единицы, округление и момент пересчёта всех write paths.
8. Для Waybill children определить snapshot versus live global reference.
9. Для read views указать источник category/overlay/counts, единицу пагинации и согласованность нескольких запросов страницы.
10. Добавить negative и concurrency tests на расхождение parent IDs, дубль и позднюю ошибку транзакции.

## Проверки, история и границы достоверности

Сводка сопоставлена со всеми 14 детальными документами, их SQL/JPA/service/test sources и текущей навигацией. Актуальные строки и диаграммы обновлены 12.11.2026: удалённые transport/materialized объекты не входят в текущую матрицу, учтены category, досылочные и проверки статуса связи.

Крупные изменения контура: `11de1385` (исходные receiving children), `be2fd261` (delivery/blackbox), `feb37a42` (Waybill aggregate и grouped view), `ce939d57`/`443ae69a` (KIS-3631 migration и новая receiving↔Waybill модель), `19cb1665`/`229c7d86` (refresh lifecycle), `4ff9dac6` (DangerProduct), `4e55d447` (актуальный Waybill input mapping), `42eee4ee` (Waybill filters/meta). Точные commits отдельных полей остаются в паспортах частей 1–14.

Тесты в этом подэтапе не запускались. Не проверены applied Liquibase chain/`pg_catalog`, реальные данные и дубли, runtime roles/client restrictions, generated MapStruct, transaction boundaries, cascade/flush order и внешние Datareon/1С/ЭТРАН contracts. До такой проверки карта пригодна для анализа и ревью ТЗ, но не должна выдаваться за production schema dump.
