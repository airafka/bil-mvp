# `waybill`: корень накладной ЭТРАН и связь с поставкой, физическая модель AS-IS (часть 9)

> **Сверено:** backend `3d3899d5d` (12.11.2026) · **Основание:** `SOURCE_CONFIRMED` — исходный код, миграции и тесты (тесты не запускались); БД и стенд не проверялись.

Это **source-level модель** (integration/controller/service/JPA, Liquibase, test sources), не снимок применённой БД. Полное поведение внешнего payload, справочных upserts, пользовательских read endpoints и ошибок описано в [Waybill и входящий ЭТРАН: актуальный AS-IS](../business-rules/waybill-etran-as-is.md); здесь фокус на корневой таблице, её ключах/nullable/FK и write paths. Дочерние уровни раскрыты отдельно: [вагон](waybill-railway-carriage-as-is.md), [КТК и ЗПУ](waybill-container-as-is.md), [груз](waybill-product-as-is.md), [специальные и тарифные отметки](waybill-marks-as-is.md). Весь контур с ReceivingOrder — в [сводной ER/integrity-карте](receiving-order-waybill-integrity-map.md). Materialized view `grouped_waybill` удалён 14.09.2026 (KIS-4690), его заменила обычная view `waybill_view` — см. [раздел ниже](#read-model-и-источник-полей) и [историческую модель](grouped-waybill-as-is.md).

С прошлой сверки (`22fac945`) изменились: колонка `creation_source` + CHECK (KIS-4626), `delivery_deadline` → `DATE`, удаление `grouped_waybill` и async refresh, проверка статуса заявки и подстановка владельцев КТК при link/relink/unlink/bulk (KIS-4716).

## Как создаётся и обновляется корень

Основной create/update source — `POST /datareon/waybill` в [`DatareonController`](../../../web-layer/src/main/java/ru/korusconsulting/alis/controller/datareon/DatareonController.java). Он принимает [`WaybillIntegrationDto`](../dto/catalog/datareon/inbound/WaybillIntegrationDto.md) и вызывает transactional [`WaybillDatareonService.handleInboundWaybill`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/datareon/WaybillDatareonService.java).

| Вход | Декларативная обязательность | Фактическая роль |
|---|---|---|
| `waybill` | root `@NotNull`, но без `@Valid` | Nested `@NotNull` не каскадирует из controller validation; service обращается к полям напрямую. |
| `waybill_identifier` | nested `@NotNull`, фактически не каскадирует | `Integer.valueOf` и единственный lookup key; SQL `NOT NULL UNIQUE`. `MessageId` и `Version` не участвуют в дедупликации. |
| `waybill_status`, `waybill_number`, станции | nested annotations + runtime mapping | Status/number и оба station FK обязательны в SQL; станции ищутся/создаются по ESR. |
| Семь дат | DTO nullable | При первом create service без null-check вызывает `atZone(Europe/Moscow)` для шести дат и `toLocalDate()` для `delivery_deadline` (с 14.09.2026 — только дата, без перевода зоны), хотя SQL разрешает null. |
| `products`, `containers`, остальные child lists | DTO nullable | Validator/mapper вызывает `.size()`/`.stream()` без единой нормализации; фактические требования строже паспорта DTO. |

Алгоритм root upsert имеет две разные ветки:

1. `waybill_identifier` преобразуется в Integer, до lookup разрешаются danger products из входных товаров.
2. Если identifier не найден, service проверяет сочетание products/containers, создаёт станции/плательщика, сохраняет полный Waybill с `creation_source='ETRAN'` и затем все child rows в одной транзакции. Существующие в каталоге вагон/КТК с тем же номером с 03.09.2026 (`90f71f39` KIS-4665, `1c97f92d` KIS-4664) **не обновляются** данными накладной (только find-or-create) — см. [вагон](waybill-railway-carriage-as-is.md) и [КТК](waybill-container-as-is.md).
3. Если identifier найден, обновляются status, непустой type, связи досылочной, категория и товары по ЕТСНГ/GNG; вагонный/контейнерный состав не заменяется. См. [сверку досылочных от 11.11.2026](../business-rules/waybill-supplementary-as-is.md).
4. До 14.09.2026 (`978ba888`, KIS-4690) после commit публиковался event и асинхронно обновлялся materialized `grouped_waybill`; теперь read-модель — обычная view, refresh-шага нет.

**Второй create path — Excel-шаблон ЖД-поставки** ([`ReceivingOrderRailwayCarriageParser`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/parsing/order/parser/impl/ReceivingOrderRailwayCarriageParser.java), лист `ETRAN`): для каждого кода ищет Waybill по `number` (`findByNumber`); если не найден — создаёт `Waybill` с `creation_source='MANUAL'`, `status='MANUAL'`, `number`, `shipmentType`, станциями из файла; затем **привязывает** найденную/созданную накладную к текущей заявке, перезаписывая связь с другой заявкой без проверки. При этом `waybillIdentifier` не задаётся, а колонка `waybill_identifier` — `NOT NULL` без default/sequence: по исходникам INSERT ручной накладной должен падать на `NOT NULL` (`INFERENCE`, тестов парсера нет; см. открытые вопросы в [integrity-карте](receiving-order-waybill-integrity-map.md#открытые-вопросы)). CHECK `waybill_creation_source_waybill_identifier` ожидает для `MANUAL` identifier `< 1 000 000 000`, но генератора таких значений в коде нет.

SQL UNIQUE защищает identifier, но source использует `find-then-insert`, не database upsert/row lock. Два первых конкурентных пакета способны столкнуться на constraint. Повторы существующей накладной меняют status по last-write-wins; optimistic `@Version` нет. Status — произвольный String без enum/CHECK и без проверенной transition map.

## Связь с `receiving_order`: link, relink, unlink и bulk replace

[`Waybill.receivingOrder`](../entities/catalog/entities/waybill/Waybill.md) — nullable N:1: одна накладная может быть связана максимум с одной поставкой, одна поставка — с несколькими накладными. ETRAN-импорт эту связь не задаёт. Ею управляют scoped endpoints поставки (`PUT /receivingorder/{id}/waybills`), compatibility [`ReceivingOrderEtranInvoiceController`](../../../web-layer/src/main/java/ru/korusconsulting/alis/controller/receivingorderetraninvoice/ReceivingOrderEtranInvoiceController.java) и Excel-шаблон ЖД-поставки (см. выше). Логика — в [`WaybillService`](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/waybill/WaybillService.java):

| Операция | Request | Изменение таблицы |
|---|---|---|
| Link (`POST /receivingorderetraninvoice/`) | [`WaybillLinkRequestDto`](../dto/catalog/waybill/WaybillLinkRequestDto.md) `waybillId`, `orderId` | Загружает Waybill и ReceivingOrder, проверяет статус заявки, устанавливает `receiving_order_id`, затем у `waybill_container` этой накладной с пустым владельцем ставит `owner_container_id = receiving_order.default_container_owner_id`. DTO/controller не имеют Bean Validation. |
| Relink (`PUT /receivingorderetraninvoice/{id}`) | path old Waybill ID + тот же DTO | При разных IDs проверяет статус заявки старой накладной, очищает её FK, затем выполняет Link для `dto.waybillId`. |
| Unlink (`DELETE /receivingorderetraninvoice/{id}`) | path Waybill ID | Проверяет статус текущей заявки, устанавливает `receiving_order_id=NULL`; Waybill, children и проставленные владельцы КТК не меняются. |
| Bulk replace (`PUT /receivingorder/{id}/waybills`, `POST /receivingorderetraninvoice/{receivingOrderId}`) | [`WaybillSelectionDto`](../dto/catalog/waybill/WaybillSelectionDto.md) | Проверяет статус заявки; `waybillIds @NotNull`: выбранным IDs массово присваивается заявка, у остальных ранее связанных с ней FK очищается; пустой список очищает все. Затем — подстановка владельцев КТК, как у Link. |

С 22.09.2026 (`3bcf0113`, KIS-4716) все четыре операции вызывают `OrderServiceUtils.checkOrderStatusForUpdate`: заявка должна быть в `DRAFT` или `ON_REVIEW` (для `ON_REVIEW` — право `RECEIVING_ORDER_SEND_TO_ACCEPT`), иначе `AccessDeniedException` → HTTP 403. До этого статус не проверялся. [`WaybillRepository`](../../../db-layer/src/main/java/ru/korusconsulting/alis/model/waybill/WaybillRepository.java) выполняет bulk JPQL updates без row locks: неизвестные IDs молча пропускаются, а Waybill другой поставки перепривязывается (статус **той** заявки не проверяется). Статус Waybill и принадлежность клиенту не проверяются; `ReceivingOrderService.reject` отдельно очищает все links отклонённой заявки. `POST /receivingorderetraninvoice/all` в source не имеет `@Secure`; runtime security/gateway не проверены.

Корень Waybill не реализует soft-delete и не содержит `deleted`. Пользовательского endpoint физического удаления корня в просмотренных controllers нет. Generic DAO test физического `remove` существует, а child FK initial SQL используют `ON DELETE CASCADE`; вызов DAO удаления из другого кода потенциально удалит агрегат, но это не опубликованная Waybill business operation.

## SQL source: текущий состав `waybill`

Initial [`KIS-2273`](../../../db-layer/src/main/resources/db/changelog/v.1.33.0/v.1.33.0_20260127_KIS-2273_add_waybill_tables.sql) создаёт table без `IF NOT EXISTS`. [`Waybill`](../../../db-layer/src/main/java/ru/korusconsulting/alis/model/waybill/Waybill.java) не задаёт `@Table/@Column` names, поэтому snake_case ниже подтверждён Liquibase, а не одной JPA naming convention.

| Группа Java-полей | SQL source contract | Семантика / writer |
|---|---|---|
| `id`, audit | `id UUID PRIMARY KEY`; `created_at TIMESTAMP NOT NULL DEFAULT UTC current timestamp`, `created_by VARCHAR(50) NOT NULL`, update audit nullable | UUID `@PrePersist`; auditing. DB default есть только у created_at. |
| `status`, `number`, `waybillIdentifier` | `status VARCHAR NOT NULL`, `number VARCHAR NOT NULL`, `waybill_identifier INTEGER NOT NULL UNIQUE` | Status/number из inbound (Excel — `status='MANUAL'`); identifier — AS ЭТРАН business key. `number` **не UNIQUE**. Read-модель исключает `status='MIGRATED'` (`Waybill.MIGRATED_STATUS`), но writer такого статуса в коде и миграциях не найден. |
| `creationSource` (`WaybillCreationSource`) | `creation_source VARCHAR(20) NOT NULL`, `CHECK (creation_source IN ('ETRAN','MANUAL'))`, `CHECK ((creation_source='MANUAL' AND waybill_identifier < 1000000000) OR (creation_source='ETRAN' AND waybill_identifier >= 1000000000))` | [`KIS-4626`](../../../db-layer/src/main/resources/db/changelog/v.1.35.0/v.1.35.0_20260909_KIS-4626_add_waybill_creation_source.sql) (коммит `978ba888`, 14.09.2026): существующие строки размечены по порогу identifier ≥ 10⁹ → `ETRAN`, иначе `MANUAL`. ETRAN-импорт пишет `ETRAN`, Excel — `MANUAL`. Входящая из ЭТРАН накладная с identifier < 10⁹ будет отвергнута CHECK (`INFERENCE`: допущение, что ЭТРАН-идентификаторы всегда ≥ 10⁹, в коде не проверяется). |
| `type`, `shipmentType`, `shipmentSpeed`, `formType` | nullable unbounded `VARCHAR` | Inbound snapshot strings, без CHECK/enum. |
| Шесть business dates (`waybill_created_at`, `submitted_at`, `approved_at`, `accepted_at`, `cargo_accepted_at`, `departure_at`) | nullable `TIMESTAMP` | LocalDateTime интерпретируется как Moscow time и преобразуется к Instant; колонка без time zone. |
| `deliveryDeadline` (`LocalDate`) | `delivery_deadline DATE NULL` | До 14.09.2026 — `TIMESTAMP`/`Instant`; [миграция](../../../db-layer/src/main/resources/db/changelog/v.1.35.0/v.1.35.0_20260911_KIS-4626_change_waybill_delivery_deadline_to_date.sql) `USING delivery_deadline::DATE` отбросила время по хранимому значению `TIMESTAMP`; если оно хранилось в UTC, даты с временем 00:00–03:00 МСК сдвинулись на сутки назад (`INFERENCE`: зона записи JDBC не проверялась). Импорт берёт дату из входного LocalDateTime без перевода зоны. Read-модель считает по ней `overdueDays` относительно «сегодня» в зоне из заголовка `X-Timezone`. |
| `departureCountry/Route`, `destinationCountry/Route` | nullable `VARCHAR` | Snapshot входного сообщения. |
| `departureStation`, `destinationStation` | два UUID `NOT NULL REFERENCES railway_station(id)` | Lookup/create по ESR; в source нет `ON DELETE` и отдельных root indexes. |
| shipper/consignee name/address | nullable `VARCHAR` | Snapshot, не FK на Client. |
| shipper/consignee TGNL/OKPO | nullable `INTEGER` | Парсинг входных strings; диапазон ограничен Integer. |
| `payer` | `payer_id UUID NULL REFERENCES payer(id)` | [`KIS-3482`](../../../db-layer/src/main/resources/db/changelog/v.1.34.0/v.1.34.0_20260330_KIS-3482_add_payer_table.sql) добавил FK; старые `payer VARCHAR`/`payer_code INTEGER` затем удалены. |
| payment/ownership/responsible | nullable `VARCHAR`; `planned_railway_carriages INTEGER NULL` | Snapshot/payment и план вагонов. |
| `waybillCategory` | `waybill_category VARCHAR(10) NOT NULL CHECK (waybill_category IN ('Inbound', 'Outbound', 'Archive'))` | Сохранённая категория: resolver при импорте/изменении связей и статуса заявки; [приоритеты и удаляющий backfill](waybill-view-as-is.md#persisted-категория-накладной-91ad166bf). |
| `waybillParent`, `waybillParentIdentifier`, `waybillConnectionType` | nullable UUID FK на waybill; nullable INTEGER identifier; nullable UUID FK на waybill_connection_type | Индексы по parent ID и identifier; без CHECK против циклов. [Связи 45/47](../business-rules/waybill-supplementary-as-is.md). |
| `receivingOrder` | `receiving_order_id UUID NULL REFERENCES receiving_order(id)` | [`KIS-3631`](../../../db-layer/src/main/resources/db/changelog/v.1.34.0/v.1.34.0_20260330_KIS-3631_add_receiving_order_id_to_waybill.sql); link API/migration, не inbound create. |

В просмотренной source chain нет UNIQUE для `number`, UNIQUE/CHECK для связи с ReceivingOrder, status transition constraint или явных non-unique indexes по station/payer/receiving_order FK. PostgreSQL автоматически индексирует PK/UNIQUE identifier, но не создаёт индексы на referencing FK columns. Applied indexes/constraints нужно проверять через `pg_catalog`.

## История миграции старой receiving-модели

Порядок v1.34 cumulative:

1. Создаёт `payer`, добавляет nullable `waybill.payer_id`.
2. [`KIS-3481`](../../../db-layer/src/main/resources/db/changelog/v.1.34.0/v.1.34.0_20260330_KIS-3481_migrate_payer_data.sql) создаёт default `Без плательщика`, переносит distinct payer_code и заполняет FK.
3. Удаляет старые Waybill `payer`/`payer_code` после drop materialized view.
4. Добавляет nullable `receiving_order_id`.
5. [`KIS-3631 data migration`](../../../db-layer/src/main/resources/db/changelog/v.1.34.0/v.1.34.0_20260330_KIS-3631_migrate_receiving_order_data_to_waybill.sql) связывает active старые `receiving_order_etran_invoice` с Waybill по `etran_invoice.code = waybill.number`, переносит children с ограниченными наборами полей.
6. [`KIS-3631 drop`](../../../db-layer/src/main/resources/db/changelog/v.1.34.0/v.1.34.0_20260330_KIS-3631_drop_receiving_order_etran_railway_tables.sql) делает `DROP TABLE ... CASCADE` старых receiving ETRAN/railway tables.

Поскольку `waybill.number` не уникален, number-based migration не доказывает однозначность соответствия. Update заполняет только Waybill с null receiving FK; конфликтующие старые связи, duplicate numbers и фактический результат требуют проверки данных до/после changeset. DO-блоки пропускают шаги, если legacy tables уже отсутствуют; это делает скрипт технически терпимым к другому состоянию, но не подтверждает полноту ранее перенесённых данных.

## Read model и источник полей

`GET /waybill/{id}` возвращает [`WaybillDetailedDto`](../dto/catalog/waybill/WaybillDetailedDto.md) (с `creationSource` и `deliveryDeadline` как `date`), а import — [`WaybillShortDto`](../dto/catalog/waybill/WaybillShortDto.md). Detailed DTO раскрывает root snapshot/stations/payer, но не receivingOrder и не children.

Вкладки «Входящие/Исходящие/Архив» (`POST /waybill/incoming|outgoing|archive/page`, ответ `Page<WaybillStationPairGroupDto>`) с 14.09.2026 читают обычную view [`waybill_view`](../../../db-layer/src/main/resources/db/changelog/rerunnable/view_waybill.sql) (rerunnable, `runOnChange`; JPA `@Immutable` [`WaybillView`](../../../db-layer/src/main/java/ru/korusconsulting/alis/model/waybill/WaybillView.java)): одна строка на `waybill` с `receiving_order_id`/номером/статусом заявки (`LEFT JOIN receiving_order`), числом вагонов и КТК и строкой ЕТСНГ для сортировки; `departure_at` = `COALESCE(departure_at, created_at)`. Данные всегда актуальны (нет refresh/staleness). Тип вкладки задаёт WaybillViewPredicate по сохранённой `waybill_category`: INCOMING → Inbound, OUTGOING → Outbound, ARCHIVE → Archive; станции/статус заявки не пересчитываются на каждом read. Всегда исключается `status='MIGRATED'`. Группировку строят DAO/service: страница пар станций → плательщик → дата → накладные с одноуровневыми children. SQL overlay использует станции/плательщика/дату основной, counts исключают excluded WRC/WC. [Полный паспорт waybill_view](waybill-view-as-is.md) описывает total, timezone и точные источники полей. Пикер `POST /waybill/for-receiving-order/page` читает live `waybill` (входящие ЕСР, без заявки или с этой заявкой); с 14.10.2026 (`059d5f5a`, KIS-4861) из него убрано исключение накладных со статусом «Работа с документом окончена».

`WaybillDaoService.findByNumber` возвращает `Optional<Waybill>`, хотя SQL разрешает duplicate number; при фактическом дубле single-result repository query способен завершиться non-unique-result error. Для ETRAN-импорта authoritative lookup — identifier, а number применяется в legacy data migration и Excel-шаблоне ЖД-поставки (поиск/создание `MANUAL`); в ТЗ эти ключи нельзя считать взаимозаменяемыми.

```mermaid
flowchart TD
    P[POST /datareon/waybill] --> K[Parse integer waybill_identifier]
    K --> F{Identifier exists?}
    F -->|No| N[Create root plus all child rows in one transaction]
    F -->|Yes| S[Update status, type, links, category and upsert products]
    N --> W[(waybill)]
    S --> W
    W --> U[UNIQUE waybill_identifier]
    W --> C[Child FK with ON DELETE CASCADE]
    XL[Railway Excel upload] --> XM[Find by number or create MANUAL]
    XM --> W
    XM --> R
    L[Link/relink/bulk API: order status check] --> R[Set nullable receiving_order_id and default container owners]
    X[Unlink or ReceivingOrder reject] --> Z[Clear receiving_order_id]
    R --> W
    Z --> W
    W --> V[waybill_view: plain view, always current]
```

[`WaybillDatareonServiceIntegrationTest`](../../../web-layer/src/integrationTest/java/ru/korusconsulting/alis/service/datareon/WaybillDatareonServiceIntegrationTest.java) source покрывает создание root+основных children, справочные типы/danger classification и повтор с обновлением status; с 10.11.2026 также добавлены сценарии связей и обновления грузов. [`WaybillDaoServiceTest`](../../../db-layer/src/integrationTest/java/ru/korusconsulting/alis/service/waybill/WaybillDaoServiceTest.java) покрывает физический DAO CRUD, identifier/number lookup, filters и bulk receiving links. Не найдены прямые tests nested validation/null dates/lists, duplicate number lookup, concurrent same identifier, link client ownership, unknown bulk IDs/reassignment, legacy migration conflicts, Excel-создания `MANUAL` накладной и CHECK `creation_source`. Тесты **не запускались**.

Influencing commits: `feb37a42` (initial Waybill tables/import, 2026-02), `ce939d57`/`443ae69a` (payer/receiving link, migration and current v1.34 chain, 2026-03/04), `84598b3a` (inbound response, 2026-05), `4ff9dac6` (danger classification, 2026-07), `4e55d447` (source-provided carriage/container classifications, 2026-08), `978ba888`/`17978487` (KIS-4690/4626: `creation_source`, `delivery_deadline` DATE, `waybill_view` вместо `grouped_waybill`, 2026-09), `3bcf0113` (KIS-4716: проверка статуса и владельцы КТК при link, 2026-09), `059d5f5a` (KIS-4861, 2026-10). Commit history не доказывает применённость migration chain на среде.

## Уточнение целевой сверки 11.11.2026

С 10.11.2026: nullable waybill_parent_id (FK на waybill), waybill_parent_identifier INTEGER и waybill_connection_type_id (FK); индексы по parent_id и parent_identifier, справочник 45/47. [Миграция и алгоритм](../business-rules/waybill-supplementary-as-is.md).

## Целевая сверка read model 11.11.2026

[Полная текущая read model](waybill-view-as-is.md): пары станций, pager totals, timezone, parent overlay и counts.
