# waybill_view: модель чтения и группировка накладных

Сверено на 3d3899d5d, 11.11.2026. AS_IS / SOURCE_CONFIRMED по SQL/JPA/DAO/service/controller и исходникам тестов. Это обычная view, не materialized snapshot; SQL не выполнялся, Java-тесты не запускались.

## Строка представления

База — одна Waybill.id. Агрегаты вагонов, контейнеров и товаров сначала группируются отдельно по waybill_id, затем присоединяются: join этих трёх агрегатов сам по себе не перемножает количества. Вагонный count учитывает wrc.excluded=false, контейнерный — оба wc.excluded=false и wrc.excluded=false. При отсутствии children COALESCE даёт 0. products_sort_value — STRING_AGG «код имя» ЕТСНГ с порядком по code/name; это текстовый ключ сортировки, не список уникальных товарных строк.

Для дочерней накладной view накладывает поля основной:

| Поле | Источник |
|---|---|
| departure_station_id / destination_station_id | COALESCE(parent field, child field) |
| payer_id | Если parent существует — parent.payer_id даже при NULL, иначе child.payer_id |
| departure_at | COALESCE(parent.departure_at, parent.created_at, child.departure_at, child.created_at) |
| number, identifier, type, created time, status, category | Собственная накладная |
| receiving_order_id / number / status | Собственная связь с receiving order |
| counts и products_sort_value | Собственные children |

Это одноуровневый SQL overlay, не рекурсивное наследование всей накладной. Category хранится в Waybill и обновляется writer-ами; чтение view само её не пересчитывает. Семантика parent/children и excluded — [досылочные](../business-rules/waybill-supplementary-as-is.md).

## Страница — пары станций

WaybillViewDaoService.getHierarchyPage сначала фильтрует view и выбирает уникальные StationPair (departureStationId,destinationStationId). Порядок групп фиксирован: названия/коды/UUID отправления, затем назначения; применяется offset/limit страницы. totalElements — count distinct пар, **не количество накладных**.

Затем для выбранных пар повторно выбираются все подходящие накладные без отдельной пагинации внутри группы: fetch joins stations, payer, products/ETSNG; задаются group ordering, пользовательская сортировка строк, затем departureAt/id. Service строит StationPair → Payer (NULL отдельной группой) → дата отправления → Waybill DTO. Даты внутри плательщика сортируются по возрастанию. Счётчики уровней считают исходные rows и суммы child counts; после вложения досылочных число корней может быть меньше waybillCount.

Фильтрация и grouping могут оставить досылочную без основной в текущем наборе — она остаётся корнем. Null departureAt опасен для atZone, хотя SQL использует created_at fallback; применённые ограничения исходных таблиц требуют отдельной проверки.

## Часовая зона и просрочка

Hierarchy endpoints требуют X-Timezone (ZoneId). Группировка departureAt идёт по atZone(timezone).toLocalDate. today — LocalDate.now(timezone). overdueDays непустой только у непривязанной к ReceivingOrder накладной и только при deliveryDeadline<today; равный today срок даёт NULL. Значение — ChronoUnit.DAYS между LocalDate, не длительность в часах. Ошибки/отсутствие заголовка и смена суток требуют HTTP-теста; серверная зона не подставляется этим методом вместо переданного timezone.

## Фильтры, сортировка и meta

WaybillViewPredicate всегда исключает MIGRATED_STATUS через status.ne. При nullable повреждённом status SQL трёхзначная логика может исключить NULL — это не отдельная явная IS NULL-ветка. Type INCOMING/OUTGOING/ARCHIVE мапится в persisted category INBOUND/OUTBOUND/ARCHIVE, не заново в станции/статус заявки.

Фильтры покрывают identifier, number, createdAt, shipmentType/status, payer/stations, продукты, counts, LocalDate deliveryDeadline, creationSources, receiving order, include/exclude status и destination ESR. Пустые заданные коллекции creationSources/statuses дают false; NULL означает отсутствие этого условия. Поиск search (приоритет) либо previewSearch — OR по номеру, shipmentType/status, строке createdAt и code/name ЕТСНГ. Продуктовый отдельный фильтр также ищет code/name.

BETWEEN createdAt с одинаковыми границами расширяется до [start,start+1 день); это отдельное правило и не означает «до конца дня пользователя». products sorting использует products_sort_value, продуктовая meta группирует отображение code+name и IDs накладных. Dropdown stations/payers фильтруется по INCOMING; ID/count и сортировка уникальных справочников считаются отдельными запросами.

Service вызывает filterEnrichService.addUserRestriction; одно наличие вызова не подтверждает client isolation для всех полей WaybillFilter. Прямое чтение и выбор документов для поставки — отдельные пути. Снятый status exclusion кандидатов поставки описан в [общем AS-IS](../business-rules/waybill-etran-as-is.md).

## Эволюция и проверка

978ba888c удалил grouped_waybill и его DTO/API, async refresh event; добавил обычную view и создание ETRAN/MANUAL с SQL CHECK порога identifier. 179784874 перенёс overdueDays в service/timezone, добавил products_sort_value и сортировку. Поздние category/parent/excluded изменения учтены в текущем описании. Исходники WaybillServiceIntegrationTest покрывают hierarchy, пагинацию, timezone/overdue и поздние children; тесты не запускались.

Открытые проверки: NULL станций/дат и согласованность total с inner joins, одновременное обновление состава между двумя SQL-запросами страницы, актуальность persisted category у связей, runtime permissions и query performance. Наличие live view не означает атомарного снимка нескольких запросов при любой изоляции БД.

## Persisted категория накладной (91ad166bf)

WaybillCategory сохраняет через converter точные строки Inbound/Outbound/Archive и использует их же в JSON через @JsonValue; INBOUND/OUTBOUND/ARCHIVE — Java enum-имена. Неизвестное непустое значение БД converter отвергает IllegalArgumentException. WaybillView читает сохранённую категорию, а WaybillType INCOMING/OUTGOING/ARCHIVE только выбирает соответствующую категорию в predicate.

Текущий resolver сначала возвращает категорию parent (добавлено позднее), затем Archive для receivingOrder=DONE. Для остальных приоритет последовательно такой: destination=648400→Inbound, departure=648400→Outbound, destination=648908→Inbound, departure=648908→Outbound. Поэтому маршрут 648400→648908 классифицируется как Outbound, обратный — Inbound. Если ни одна ветка не подходит, выбрасывается IllegalStateException; fallback-категории нет.

Пересчёт вызывается при импорте/повторном импорте, link/relink/unlink и через ReceivingOrderListener BEFORE_COMMIT при смене статуса поставки. В listener пересчёт расположен до route-null guard и вне try/catch синхронизации рейса: отсутствие route его не отменяет, ошибка категории не подавляется этим catch. Это сохранённый атрибут, не вычисление категории на каждом чтении view; произвольные DAO/SQL-изменения станций или parent не гарантируют пересчёт.

Миграция сначала заполняет категорию по DONE/станциям, затем физически удаляет все Waybill с NULL category и только после этого включает NOT NULL/CHECK. UPDATE требует обе связанные станции через FROM/WHERE, поэтому строка без станции может остаться NULL даже при DONE и попасть в DELETE. Действие описано по SQL; миграция не запускалась. Ранний backfill не включает появившееся позднее parent-first правило.

Источники: [resolver](../../../db-layer/src/main/java/ru/korusconsulting/alis/model/waybill/WaybillCategoryResolver.java), [converter](../../../db-layer/src/main/java/ru/korusconsulting/alis/model/waybill/WaybillCategoryConverter.java), [ReceivingOrderListener](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/receivingorder/ReceivingOrderListener.java), [миграция категории](../../../db-layer/src/main/resources/db/changelog/v.1.35.0/v.1.35.0_20260930_KIS-4795_add_waybill_category.sql).

## Завершение сверки 978ba888c: writers, mapper и тесты

Datareon writer задаёт creationSource=ETRAN; Excel ReceivingOrderRailwayCarriageParser задаёт MANUAL. deliveryDeadline преобразуется через toLocalDate, без прежнего atZone(MSK).toInstant. WaybillDetailedDto отражает LocalDate и format=date; тестовые factories обновлены. Старый publishWaybillIntegrationPacketProcessed и событие refresh удалены вместе с grouped projection, а не заменены ещё одним async refresh.

WaybillMapper удаляет grouped/archive mappings и resolvePayerDisplay, добавляет StationDto mapping. Helper товаров возвращает пустой список для NULL, пропускает NULL product и допускает NULL ЕТСНГ code/name. Нельзя переносить прежнее представление payer из archive DTO на текущую иерархию. IdNumberDto.of добавлен для отображения связи заявки.

Исходный новый WaybillServiceIntegrationTest содержит четыре сценария: полная station-pair/payer/date иерархия, пагинация трёх station pairs без обрезания строк группы, исключение MIGRATED из строк/counts, overdue только для непривязанной просроченной накладной. В первоначальном тесте today взят из SQL CURRENT_DATE; timezone-поведение добавлено позднее и описано выше. Datareon integration fixtures помечают ETRAN и ограничивают идентификаторы порогом 1e9. Удалённый GroupedWaybillDaoServiceTest не считается покрытием нового DAO. Все эти исходники просмотрены без выполнения PostgreSQL/HTTP/Java tests.

## Исходные файлы

- [view_waybill.sql](../../../db-layer/src/main/resources/db/changelog/rerunnable/view_waybill.sql)
- [WaybillView.java](../../../db-layer/src/main/java/ru/korusconsulting/alis/model/waybill/WaybillView.java)
- [WaybillViewDaoService.java](../../../db-layer/src/main/java/ru/korusconsulting/alis/model/waybill/WaybillViewDaoService.java)
- [WaybillViewPredicate.java](../../../db-layer/src/main/java/ru/korusconsulting/alis/model/waybill/WaybillViewPredicate.java)
- [WaybillService.java](../../../web-layer/src/main/java/ru/korusconsulting/alis/service/waybill/WaybillService.java)
- [WaybillController.java](../../../web-layer/src/main/java/ru/korusconsulting/alis/controller/waybill/WaybillController.java)
- [WaybillServiceIntegrationTest.java](../../../web-layer/src/integrationTest/java/ru/korusconsulting/alis/service/waybill/WaybillServiceIntegrationTest.java)
